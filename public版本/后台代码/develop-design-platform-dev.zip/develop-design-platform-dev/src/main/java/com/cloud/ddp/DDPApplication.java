package com.cloud.ddp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DDPApplication {
    public static void main(String[] args) {
        SpringApplication.run(DDPApplication.class, args);
    }
}
