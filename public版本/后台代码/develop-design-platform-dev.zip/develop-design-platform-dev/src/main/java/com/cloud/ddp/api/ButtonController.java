package com.cloud.ddp.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.operation.BaseOperation;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.api;
 * 描述：
 * @author wenlu
 * @date 2020年4月20日下午1:18:32
 */

@RestController
@RequestMapping("/button")
@Slf4j
public class ButtonController {
	
	/**
	 * 添加或修改对象节点数据
	 * @param objectName
	 * @param object
	 * @return
	 */
    @PostMapping(value = "/addObjectByNodeName/{objectName}")
    public String addOrUpdateObject(@PathVariable("objectName")String objectName, @RequestBody String object){
    	String result = BaseOperation.addOrUpdateObject(objectName,object,ConfigConstants.FILENAME_BUTTON,ConfigConstants.BUTTON_LIST);
        return result;
        
    }
    
    /**
     * 获取指定对象的数据
     * @return
     */
    @GetMapping(value = "/getByObjectId/{objectId}")
    public String getByObjectId(@PathVariable("objectId")String objectId){
        return BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_BUTTON, ConfigConstants.BUTTON_LIST, ObjectConstants.OBJECT_ID_KEY);
    }
    
    
    
    @GetMapping(value = "/getAllButtonData")
    public String getAllButtonData(){
        return BaseOperation.getNodeList(ConfigConstants.FILENAME_BUTTON, ConfigConstants.BUTTON_LIST);
    }
        
    
   
    
	
}

