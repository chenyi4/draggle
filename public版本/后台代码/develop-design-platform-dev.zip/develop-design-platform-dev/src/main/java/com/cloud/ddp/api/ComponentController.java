package com.cloud.ddp.api;

import com.cloud.ddp.operation.ComponentOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/component")
@Slf4j
public class ComponentController {

    @PostMapping(value = "/addOrUpdateComponent")
    public String addOrUpdateComponent(@RequestBody String componentsString){
        return ComponentOperation.addOrUpdateComponent(componentsString);
    }

    @GetMapping(value = "/findComponentsByObjectId/{objectId}")
    public String findComponentsByObjectId(@PathVariable("objectId")String objectId){
        return ComponentOperation.findComponentsByObjectId(objectId);
    }
    
    
    /**
     * 字段批量显示
     * @param objectId
     * @return
     */
    @GetMapping(value = "/findObjectComponentsByObjectId/{objectId}")
    public String findObjectComponentsByObjectId(@PathVariable("objectId")String objectId){
        return ComponentOperation.findObjectComponentsByObjectId(objectId);
    }
}
