package com.cloud.ddp.api;

import com.cloud.ddp.operation.DataReferenceOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/reference")
@Slf4j
public class DataReferenceController {

    @PostMapping(value = "/addOrUpdate/{objectId}")
    public String createTables(@PathVariable("objectId")String objectId,@RequestBody String refNodeData){
            return DataReferenceOperation.addOrUpdateDataReference(refNodeData,objectId);
    }

    @GetMapping(value = "/deleteRefNode/{objectId}/{refId}")
    public String deleteRefNodeByObjectIdAndRefId(@PathVariable("objectId")String objectId,@PathVariable("refId")String refId){
        return DataReferenceOperation.removeRefDataBackKeyNodeForAPI(objectId,refId);
    }

    @GetMapping(value = "/getRefData/{objectId}")
    public String getRefDataByObjectId(@PathVariable("objectId")String objectId){
        return DataReferenceOperation.getDataReferenceObjectByObjectID(objectId);
    }
}
