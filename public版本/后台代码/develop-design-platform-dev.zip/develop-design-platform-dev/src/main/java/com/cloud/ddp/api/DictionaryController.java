package com.cloud.ddp.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.operation.DictionaryOperation;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.api;
 * 描述：
 * @author wenlu
 * @date 2020年4月20日下午1:18:32
 */

@RestController
@RequestMapping("/defaultDictionary")
@Slf4j
public class DictionaryController {
	
	/**
	 * 添加group节点
	 * @param groupName
	 * @param object
	 * @return
	 */
    @PostMapping(value = "/addDictionaryGroup")
    public String addOrUpdateObject(@RequestBody String object){
        return DictionaryOperation.addDictionaryGroup(object);
    }
    
    
    
    /**
     * 删除字典分组
     * {
		"groupNos":[]
		}
     * @return
     */
    @PostMapping(value = "/deleteDictionaryGroupByNo")
    public String delteObjectById(@RequestBody String object){
    	return DictionaryOperation.deleteDictionaryGroupByNo(object);
    }

    
    /**
     * 获取指定字典分组下的数据    
     * @param groupId
     * @return
     */
    @GetMapping(value = "/getDictionaryByNo/{groupNo}")
    public String getDictionaryById(@PathVariable("groupNo")String groupNo){
       return DictionaryOperation.findDictionaryGroupByNo(groupNo);
    }
	
    
    /**
     * 获取字典列表
     * @return
     */
    @GetMapping(value = "/getAllDictionaryData")
    public String getAllDictionaryData(){
        return BaseOperation.getNodeList(XmlConstants.DICTIONRY, ConfigConstants.DICTIONARY_LIST);
    }
    
    
    /**
	 * 添加字典数据节点
	 * @param groupName
	 * @param object
	 * @return
	 */
    @PostMapping(value = "/addDictionary")
    public String addDictionary(@RequestBody String object){
        return DictionaryOperation.addDictionary(object);
    }
    

    
    
    
}

