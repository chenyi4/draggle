package com.cloud.ddp.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.ddp.operation.EventOperation;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.api;
 * 描述：
 * @author wenlu
 * @date 2020年7月20日上午10:34:10
 */
@RestController
@RequestMapping("/event")
@Slf4j
public class EventController {

    
    /**
     * 获取对象的事件集合
     * @param objectId
     * @return
     */
    @GetMapping(value = "/getEventsByObjectId/{objectId}")
    public String getEventsByObjectId(@PathVariable("objectId")String objectId){
    	return EventOperation.getEventsByObjectId(objectId);
    }
    
    
	/**
	 * 添加事件
	 * @param groupName
	 * @param object
	 * @return
	 */
    @PostMapping(value = "/addOrUpdateObject/{groupCode}/{objectId}")
    public String addOrUpdateObject(@PathVariable("groupCode")String groupCode,@PathVariable("objectId")String objectId,@RequestBody String object){
        return EventOperation.addOrUpdateObject(groupCode,objectId, object);
    }
    
    
    /**
     * 删除事件
     * @return
     */
    @PostMapping(value = "/deleteEvent/{groupCode}/{objectId}")
    public String deleteEvent(@PathVariable("groupCode")String groupCode,@PathVariable("objectId")String objectId,@RequestBody String object){
    	return EventOperation.deleteEvent(groupCode, objectId,object);
    }
    
    /**
     * 前提条件获取
     * @param objectId
     * @return
     */
    @GetMapping(value = "/getObjectFieldsByObjectId/{objectId}")
    public String getObjectFieldsByObjectId(@PathVariable("objectId")String objectId){
        return EventOperation.getObjectFieldsByObjectId(objectId);
    }

    
}

