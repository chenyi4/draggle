package com.cloud.ddp.api;

import com.cloud.ddp.operation.GenerateXMLOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/xml")
@Slf4j
public class GenerateXMLController  {

    @GetMapping(value = "/generate/{objectId}")
    public String generateXMLByObjectId(@PathVariable("objectId")String objectId){
        return GenerateXMLOperation.generateXMLByObjectIdForAPI(objectId);
    }
    
    /**
     * 生成默认字典的xml
     * @return
     */
    @GetMapping(value = "/generate/defaultDictionary")
    public String generateXMLDefaultDictionary(){
        return GenerateXMLOperation.generateXMLDefaultDictionaryForAPI();
    }
    
    /**
     * 生成表数据的xml
     * @return
     */
    @GetMapping(value = "/generate/allTableXml")
    public String generateXMLTables(){
        return GenerateXMLOperation.generateXMLTables();
    }
    
    
    
    
}
