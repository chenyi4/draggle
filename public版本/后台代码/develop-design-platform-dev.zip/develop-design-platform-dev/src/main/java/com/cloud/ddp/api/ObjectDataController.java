package com.cloud.ddp.api;

import com.cloud.ddp.operation.ModuleOperation;
import com.cloud.ddp.operation.ObjectOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/object")
@Slf4j
public class ObjectDataController {
    @PostMapping(value = "/addObjectByGroupName/{groupName}")
    public String addOrUpdateObject(@PathVariable("groupName")String groupName, @RequestBody String object){
        return ObjectOperation.addOrUpdateObject(groupName,object);
    }

    @GetMapping(value = "/updatePageKey/{groupName}/{objectId}/{pageKey}")
    public String updatePageKeyByGroupNameAndObjectId(@PathVariable("groupName")String groupName,@PathVariable("objectId")String objectId,@PathVariable("pageKey")String pageKey){
        return ObjectOperation.updatePageKeyByGroupNameAndObjectId(groupName,objectId,pageKey);
    }

    @GetMapping(value = "/getObjectTree")
    public String getAllObjects(){
        return ObjectOperation.getAllObjects();
    }

    @GetMapping(value = "/getGroupList")
    public String getGroupList(){
        return ObjectOperation.getGroupList();
    }

    @GetMapping(value = "/getObjectTypeList")
    public String getObjectTypeList(){
        return ObjectOperation.getObjectTypeList();
    }
    
    /**
     * 删除菜单
     * @return
     */
    @GetMapping(value = "/deleteObjectById/{objectId}")
    public String delteObjectById(@PathVariable("objectId")String objectId){
    	return ObjectOperation.removeObjectNodeByObjectIdForApi(objectId);
    }
    
    /**
     * 
     * @param objectId
     * @param object 
     * {
     	"pageKey":"", //页面标识
    	"objectName":"", //对象名称
    	"groupName":""  //对应服务
		}
     * @return
     */
    @PostMapping(value = "/copyObject/{objectId}")
    public String copyObject(@PathVariable("objectId")String objectId,@RequestBody String object){
        return ModuleOperation.copyObject(objectId, object);
    }

    
}
