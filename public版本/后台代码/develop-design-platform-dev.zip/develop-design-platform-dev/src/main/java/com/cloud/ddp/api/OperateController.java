package com.cloud.ddp.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.operation.OperateOperation;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.api;
 * 描述：
 * @author wenlu
 * @date 2020年4月20日下午1:18:32
 */

@RestController
@RequestMapping("/operate")
@Slf4j
public class OperateController {
	    
    
    /**
     * 获取功能按钮详情
     * @param objectId
     * @param operateCode
     * @return
     */
    @GetMapping(value = "/getByObjectId/{objectId}/{operateCode}")
    public String getByObjectIdAndCode(@PathVariable("objectId")String objectId,@PathVariable("operateCode")String operateCode){
        return OperateOperation.findObjectByNodeId(objectId,operateCode);

    }
    
    
    
    /**
     * 获取指定Object-id功能集合
     * @return
     */
    @GetMapping(value = "/getByObjectId/{objectId}")
    public String getByObjectId(@PathVariable("objectId")String objectId){
        return OperateOperation.findObjectByNodeId(objectId);

    }
       
    /**
     * 删除对应按钮操作
     * @param objectId
     * @param operateCode
     * @return
     */
    @GetMapping(value = "/deleteObjectByCode/{objectId}/{operateCode}")
    public String deleteByObjectId(@PathVariable("objectId")String objectId,@PathVariable("operateCode")String operateCode){
    	return OperateOperation.deleteOperateByCode(objectId, operateCode);
    }	

    
    
    /**
     * 添加或更新节点
     * @param operateType
     * @param object
     * @return
     */
    @PostMapping(value = "/addObjectByNodeName/{operateCode}")
    public String addOrUpdateObject(@PathVariable("operateCode")String operateCode, @RequestBody String object){
    	return OperateOperation.addOrUpdateObject(operateCode, object);
    }
    
    
    /**
     * 获取所有的操作按钮集合                      
     * @return
     */
    @GetMapping(value = "/getAllOperateData")
    public String getAllOperateData(){
        return BaseOperation.getNodeList(ConfigConstants.FILENAME_OPERATE, ConfigConstants.OPERATE_LIST);
    }

    
    /**
     * 根据type查询operate集合
     * @return
     */
    @GetMapping(value = "/getOperateListByType/{objectType}")
    public String getOperateListByType(@PathVariable("objectType")String objectType){
    	return BaseOperation.getNodeList(ConfigConstants.FILENAME_OPERATE, ConfigConstants.OPERATE_LIST, ConfigConstants.OBJECT_TYPE,objectType);
    }
	
}

