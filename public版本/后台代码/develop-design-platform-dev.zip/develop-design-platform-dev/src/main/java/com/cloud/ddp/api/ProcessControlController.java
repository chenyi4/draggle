package com.cloud.ddp.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.ddp.operation.ProcessControlOperation;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/processControl")
@Slf4j
public class ProcessControlController {
	
	
	/**
	 * 获取所有pageKey list
	 * @return
	 */
 	@GetMapping(value = "/getAllPageKeys/{objectId}")
    public String getAllPageKeys(@PathVariable("objectId")String objectId){
       return ProcessControlOperation.getPageKeys(objectId);
    }
 	
 	
 	 /**
 	  * 生成table_relationship
 	  * @param object
 	  * @return
 	  */
 	 @PostMapping(value = "/addOrUpdateRelations/{objectId}")
     public String addOrUpdateRelationShips(@PathVariable("objectId")String objectId,@RequestBody String object){
         return ProcessControlOperation.addRelationShips(objectId,object);
     }
 	 
 	 
 	 /**
 	  * 获取已绑定的pageKeys
 	  * @param objectId
 	  * @return
 	  */
 	@GetMapping(value = "/getBindPageKeys/{objectId}")
 	 public String getBindPageKeys(@PathVariable("objectId")String objectId){
 		 return ProcessControlOperation.getBindPageKeys(objectId);
 	 }
 	 
 	 
 	 
    
    
}

