package com.cloud.ddp.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cloud.ddp.operation.RunSystemOperation;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.api;
 * 描述：
 * @author wenlu
 * @date 2020年7月10日下午1:26:21
 */
@RestController
@RequestMapping("/runSys")
@Slf4j
public class RunSystemController {

	/**
	 * 发布生成代码
	 * @param objectName
	 * @param object
	 * @return
	 */
    @GetMapping(value = "/release")
    public String releaseCode(){
    	return RunSystemOperation.executeExe();
    	
    }
    
    @GetMapping(value = "/runSystem")
    public String  runSystem(){
    	return RunSystemOperation.runSystem();
    } 
    
    
    @PostMapping(value = "/publishFile")
    public String  publishFile(@RequestParam MultipartFile file,@RequestParam String pageKey,@RequestParam String groupName){
    	return RunSystemOperation.upload(file,pageKey,groupName);
    } 
}

