package com.cloud.ddp.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.operation.SearchOperation;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.api;
 * 描述：
 * @author wenlu
 * @date 2020年4月20日下午1:18:32
 */

@RestController
@RequestMapping("/searchOrder")
@Slf4j
public class SearchOrderController {
	
	/**
	 * 
	 * @param groupName
	 * @param object
	 * @return
	 */
    @PostMapping(value = "/addObjectByNodeName")
    public String addOrUpdateObject(@RequestBody String object){
    	return SearchOperation.addOrUpdateObject(object, ConfigConstants.FILENAME_SEARCH_ORDER);
    }
    
    
    /**
     * 获取对象信息
     * @param objectId 
     * @return
     */
    @GetMapping(value = "/getObjectById/{objectId}")
    public String getObjectById(@PathVariable("objectId")String objectId){
       return BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_SEARCH_ORDER, ConfigConstants.SEARCH_ORDER_LIST, ObjectConstants.OBJECT_ID_KEY);
    }
    
    
    
    
}

