package com.cloud.ddp.api;

import com.cloud.ddp.operation.TableOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/table")
@Slf4j
public class TableDataController {

    @GetMapping(value = "/getTableById/{tableId}")
    public String getTableByTableId(@PathVariable("tableId")String tableId){
       return TableOperation.findTableByTableId(tableId);
    }

    @PostMapping(value = "/addTables/{groupName}/{objectId}/{pagekey}")
    public String createTables(@PathVariable("pagekey")String pagekey,@PathVariable("objectId")String objectId,@PathVariable("groupName")String groupName,@RequestBody String tables){
        return TableOperation.addOrUpdateTablesByPageKey(pagekey,objectId,groupName,tables);
    }

    @GetMapping(value = "/getTablesByObjectId/{objectId}")
    public String getTablesByPagekey(@PathVariable("objectId")String objectId){
        return TableOperation.getTableListByObjectIDForAPI(objectId);
    }

    @PostMapping(value = "/checkTableNameExistence")
    public String checkTableNameExistence(@RequestBody String table){
        return TableOperation.checkTableNameExistence(table);
    }

    @GetMapping(value = "/getAllTablesData")
    public String getAllTablesData(){
        return TableOperation.getAllTableList();
    }
    
    @GetMapping(value = "/getDefaultTableFields")
    public String getDefaultTableFields(){
        return TableOperation.getDefaultTableFields();
    }
    
}
