package com.cloud.ddp.constants;

public class ComponentConstants {
    public static final String COMPONENT_FILE_NAME = "form-components";
    public static final String OBJECT_COMPONENT_FILE_NAME = "object-components";

    public static final String OBJECTS_KEY = "objects";
    public static final String COMPONENT_LIST_KEY = "component-list";
    public static final String COMPONENT_ID_KEY = "componentId";
    public static final String CHILDREN_KEY = "children";
    
    public static final String COMPONENT_TYPE_FRAME = "1";
    public static final String COMPONENT_TYPE_TAB = "3";
    public static final String COMPONENT_TYPE_INPUT = "4";
    public static final String COMPONENT_TYPE_TABLE = "6";
    
    public static final String COMPONENT_TYPE = "component-type";
    public static final String NAME = "name";
    public static final String TITLE = "title";
    public static final String HASH = "hash";
    public static final String PARENT_HASH = "parent-hash";
    public static final String TABLE_ID_KEY = "tableId";
    public static final String FIELD_ID_KEY = "fieldId";
    public static final String FIELD_NAME_KEY = "field-name";
 
}
