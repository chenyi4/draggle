package com.cloud.ddp.constants;

import com.cloud.ddp.util.PropertyUtil;

public class ConfigConstants {
	
	//定义字符集
    public static final String ENCODING = "UTF-8";
    
    //定义xml属性
    public static final String PROPERTIES_TAG = "properties";
    
    //定义xml属性
    public static final String SUB_NODE_LIST = "subNode";
    
    //定义文件路径
//    public static final String FILE_PATH = "src/main/resources/xml";
    public static String FILE_PATH ;
    
    //定义可执行发布程序路径
    public static String EXE_PATH;
    
    //定义可执行发布程序路径
    public static String GEN_JAR_PATH;
    
    //定义可执行发布程序路径
    public static String PAGES_PATH;

    //定义操作成功code
    public static final String SUCCESS = "200";
    
    //定义操作失败code
    public static final String FAULT = "202";
    
    //定义操作成功返回信息
    public static final String SUCCESS_MSG = "操作成功！";
    
    //定义操作成功失败信息
    public static final String FAULT_MSG = "操作失败！";
    
    //json格式不正确
    public static final String JSON_FORMAT_ERROR = "JSON格式不正确！";
    
    //定义表关联节点
    public static final String TABLE_ASSOCIATION = "table-association";
    
    //定义字段list
    public static final String FIELD_LIST = "field-list";
    
    //定义字段button list
    public static final String BUTTON_LIST = "button-list";
    
    //定义字段push list
    public static final String PUSH_LIST = "push-list";
    
    //定义字段searchOrder list
    public static final String SEARCH_ORDER_LIST = "search-order-list";
    
   //定义字段pushDown list
    public static final String PUSH_DOWN_LIST = "push-list";
    
    //定义dictionary list
    public static final String DICTIONARY_LIST = "dictionary-list";
    
    //定义operate list
    public static final String OPERATE_LIST = "operate-list";
    
    //定义back list
    public static final String BACK_LIST = "back-list";
    
    //定义dictionary list
    public static final String DEFAULT_DICTIONARY = "DefaultDictionary";
    //常量0
    public static final String TEXT_ZERO = "0";
    //常量1
    public static final String TEXT_ONE = "1";
    //常量1
    public static final String TEXT_TWO = "2";
    //上查下查文件名
    public static final String FILENAME_SEARCH_ORDER = "searchOrder";
    
    //button文件名
    public static final String FILENAME_BUTTON = "button";
    
    //button文件名
    public static final String FILENAME_BUTTON_TEMPLATE = "button-template";
    
  //back文件名
    public static final String FILENAME_BACK = "back";
    
    //operate文件名
    public static final String FILENAME_OPERATE = "operate";
    
    //pushDown文件名
    public static final String FILENAME_PUSH_DOWN = "push-down";
    
    //字典文件名
    public static final String FILENAME_DICTIONARY = "dictionary";
    
    
    //operate文件名
    public static final String FILENAME_TABLE_RELATION = "table-relation";
    
    //event文件名
    public static final String FILENAME_EVENT = "event";

    //event文件名
    public static final String FILENAME_EVENT_GROUPS = "event-group";
    
    public static final String PRIMARY_KEY_ID = "primary-id";

    public static final String OBJECT_TYPE = "object-type";
    
    
    //button 按钮code定义
    //上查
    public static final String BUTTON_UPSEARCH ="upSearch";
    //下查
    public static final String BUTTON_SUBSEARCH ="subSearch";
    //列表
    public static final String BUTTON_SEARCH ="search";
    //查看
    public static final String BUTTON_VIEW ="view";
    //保存
    public static final String BUTTON_SAVE ="save";
    //修改
    public static final String BUTTON_CHANGE ="change";
    //审核
    public static final String BUTTON_AUDIT ="audit";
    //反审核
    public static final String BUTTON_UNAUDIT ="unaudit";
    //审核驳回
    public static final String BUTTON_REJECT ="reject";
    //提交
    public static final String BUTTON_SUBMIT ="submit";
    //复制
    public static final String BUTTON_COPY ="copy";
    //撤销
    public static final String BUTTON_UNSUBMIT ="unsubmit";
    //启用
    public static final String BUTTON_ENABLE ="enable";
    //启用
    public static final String BUTTON_UNABLE ="unable";    
    //附件
    public static final String BUTTON_UPLOAD ="upload";
    //启用
    public static final String BUTTON_PRINT ="print";
    //引入
    public static final String BUTTON_IMPORT ="import";
    //引出
    public static final String BUTTON_EXPORT ="export";
    //过滤
    public static final String BUTTON_FILTER ="filter";
    //过滤
    public static final String BUTTON_REFRESH ="refresh";
    //上移下移
    public static final String BUTTON_POSITION ="position";
    //新增
    public static final String BUTTON_ADD ="add";
    //删除
    public static final String BUTTON_DELETE ="delete";
    //配置
    public static final String BUTTON_CONFIGURATION ="configuration";
    //退出
    public static final String BUTTON_QUIT ="quit";
    //下推
    public static final String BUTTON_PUSH ="push";
    //选单
    public static final String BUTTON_SELECT_OREDER ="searchOrder";
    
    //button type定义
    //普通功能按钮
    public static final String BUTTON_TYPE_CONFIG ="config";
    //普通功能按钮
    public static final String BUTTON_TYPE_PAGE ="page";
    //上查下查按钮
    public static final String BUTTON_TYPE_SEARCHORDER ="searchOrder";
    //上推下推按钮
    public static final String BUTTON_TYPE_PUSHDOWN ="pushDown";
    
    
    //表字段定义
    public static final String VALUE_N = "n";
    public static final String VALUE_Y = "y";
    
    
    //表字段定义
    public static final String NAME_PUSH_DOWN = "下推";
    public static final String NAME_SELECT_ORDER = "选单";
    
    //操作类型定义
    public static final String OPERATE_TYPE_CREATE = "create";
    public static final String OPERATE_TYPE_UPDATE = "update";



    static {
        try {
            FILE_PATH = (String) PropertyUtil.getProperty(SystemConstants.XML_FILE_PATH_KEY);
            EXE_PATH = (String) PropertyUtil.getProperty(SystemConstants.EXE_PROGRAM_PATH_KEY);
            PAGES_PATH = (String) PropertyUtil.getProperty(SystemConstants.PLATFORM_PAGES_PATH_KEY);
            GEN_JAR_PATH = (String) PropertyUtil.getProperty(SystemConstants.JAR_PROGRAM_PATH_KEY);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
