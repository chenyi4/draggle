package com.cloud.ddp.constants;

public class DataReferenceConstants {
    public static final String DATA_REFERENCE_FILE = "back";
    public static final String BACK_LIST_KEY = "back-list";
    //对应object id
    public static final String PRIMARY_ID_KEY = "object-id";
    public static final String NODE_NAME_KEY = "name";
    public static final String REFERENCE_LIST_KEY = "reference-list";
    public static final String REF_ID_KEY = "ref-id";
    public static final String REF_NAME_KEY = "ref-name";
    public static final String REF_KEY_KEY = "ref-key";
    public static final String REF_TYPE_KEY = "ref-type";
}
