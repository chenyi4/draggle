package com.cloud.ddp.constants;

public class DictionaryConstants {
    public static final String DICTIONARY_GROUP_NO = "group-no";
    public static final String DICTIONRY_GROUP_NO = "group-no";
    public static final String DICTIONRY_GROUP_NO_LIST_KEY = "groupNos";
    public static final String DICTIONRY_KEYS = "dictionary-keys";
}
