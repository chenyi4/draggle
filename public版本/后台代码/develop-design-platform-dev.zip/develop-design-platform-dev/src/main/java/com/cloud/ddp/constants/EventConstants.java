package com.cloud.ddp.constants;

public class EventConstants {
    public static final String DATA_KEY = "data";

    public static final String PRIMARY_ID = "primary-id";
    
    public static final String EVENTS = "events";
    
    public static final String EVENT_LIST = "event-list";
    
    public static final String EVENT_GROUP_CODE = "event-group-code";
    
    public static final String EVENT_INCREMENT_INDEX = "event-increment-index";
    
    public static final String EVENT_GROUP_NAME = "event-group-name";
    
    public static final String EVENT_GROUPS = "event-groups";
    
    public static final String FUNCTIONS = "functions";
    
    
}
