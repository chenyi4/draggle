package com.cloud.ddp.constants;

public class IncrementConstants {
    //increment json file name
    public static final String  INCREMENT_JSON_FILE_NAME = "increment";

    //project id increment key
    public static final String PROJECT_ID_INCREMENT_KEY = "project-id-increment-index";

    //project array key
    public static final String PROJECT_ARRAY_KEY = "projects";

    public static final String PROJECT_ID_KEY = "project-id";

    //object id increment key
    public static final String MODULE_INCREMENT_INDEX_KEY = "object-increment-index";

    //component id increment key
    public static final String COMPONENT_INCREMENT_INDEX_KEY = "component-increment-index";

    //table id increment key
    public static final String TABLE_INCREMENT_INDEX_KEY = "table-increment-index";

    // ref id increment key
    public static final String REFERENCE_INCREMENT_INDEX_KEY = "reference-increment-index";

    //table field array key
    public static final String TABLE_FIELD_ARRAY_KEY = "tables";

    public static final String TABLE_ID_KEY = "table-id";

    public static final String FIELD_INCREMENT_INDEX = "field-increment-index";
}
