package com.cloud.ddp.constants;

public class ObjectConstants {
    public static final String OBJECT_FILE_NAME = "object";
    public static final String OBJECT_GROUP_LIST_FILE_NAME = "object-group-list";
    public static final String OBJECT_TYPE_LIST_FILE_NAME = "object-type-list";

    public static final String DATA_KEY = "data";
    public static final String GROUP_NAME_KEY = "group-name";
    public static final String GROUP_NAME_CHN_KEY = "group-name-chn";
    public static final String OBJECT_LIST_KEY = "object-list";
    public static final String OBJECT_ID_KEY = "object-id";
    public static final String OBJECT_NAME_KEY = "object-name";
    public static final String OBJECT_TYPE_KEY = "object-type";
    public static final String PAGE_KEY_KEY = "page-key";
    public static final String CODE_RULE_KEY = "code-rule";
    public static final String IS_DEFAULT_KEY = "is-default";
    
    public static final String GROUP_NAME = "group-name";
    public static final String SERVICE_NAME_SHORT = "service-name-short";
}
