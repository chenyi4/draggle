package com.cloud.ddp.constants;

public class ProjectInfoKeyConstants {
    //project info json file name
    public static final String  PROJECT_INFO_JSON_FILE_NAME = "project-list";


    /**  project info key **/
    public static final String PROJECT_LIST_KEY = "project-list";
    public static final String PROJECT_ID_KEY = "project-id";
    public static final String PROJECT_NAME_KEY = "project-name";

}
