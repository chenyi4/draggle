package com.cloud.ddp.constants;

public class SystemConstants {
    public static final String SYSTEM_WORKSPACE_KEY = "system-workspace";

    public static final String XML_FILE_PATH_KEY = "xml-file-path";
    
    public static final String EXE_PROGRAM_PATH_KEY = "exe-program-path";
    
    public static final String JAR_PROGRAM_PATH_KEY = "jar-program-path";
    
    public static final String PLATFORM_PAGES_PATH_KEY = "platform-pages-path";
}
