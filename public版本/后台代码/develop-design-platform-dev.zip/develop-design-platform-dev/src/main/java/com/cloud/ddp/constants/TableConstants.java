package com.cloud.ddp.constants;

public class TableConstants {
    public static final String TABLE_DATA_FILE = "table";

    public static final String TABLES_KEY = "tables";

    public static final String TABLE_ID_KEY = "table-id";

    public static final String TABLE_NAME_KEY = "table-name";

    public static final String PAGE_KEY_KEY = "page-key";

    public static final String OBJECT_ID_KEY = "object-id";

    public static final String FIELD_LIST_KEY = "field-list";

    public static final String FIELD_ID_KEY = "field-id";

    public static final String FIELD_NAME = "field-name";
    
    public static final String IS_MAIN_TABLE = "is-main-table";
    
    public static final String TABLE_ASSOCIATION = "table-association";
    
    public static final String REF_TABLE_ID = "ref-table-id";
    
    public static final String DATA_KEY = "data";
    
    public static final String IS_TREE = "is-tree";

    
}
