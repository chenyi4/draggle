package com.cloud.ddp.constants;

public class XmlConstants {
	/**
	 * 生成xml文件夹名配置
	 */
	
	//生成表数据文件夹
	 public static final String FOLDER_NAME_ALLXMLFILES = "allXmlFiles";
	 
	 //生成数据引用
	 public static final String FOLDER_NAME_BACK = "back";
	 
	 //生成功能按钮数据
	 public static final String FOLDER_NAME_BUTTON = "button";
	 
	 //生成上查下查数据
	 public static final String FOLDER_NAME_SEARCHORDER = "searchOrder";
	 
	 //生成上推下推数据
	 public static final String FOLDER_NAME_PUSHDOWN = "pushDown";
	 
	 //生成默认字典数据
	 public static final String FOLDER_NAME_DICTIONARY = "dictionary";
	
	
	/**
	 * 定义查找带回xml配置key
	 */
    public static final String TARGET_ENTITY = "targetEntity";

    public static final String FILED = "filed";

    public static final String BACK_LIST_FILED = "BackListFiled";
    
    public static final String BACK_LIST = "backList";

    public static final String SQL = "sql";

    public static final String TARGET = "target";

    public static final String PARAM = "param";

    public static final String SOURCE_ENTITY = "sourceEntity";

    public static final String TYPE = "type";
    
    public static final String CON_BACK_FILED = "ConBackFiled";
    
    public static final String NAME = "name";
    
    public static final String COLUMN = "column";
    
    public static final String MODEL = "model";
    
    public static final String BACK_PAGE = "backPage";
    
    public static final String WHERE = "where";
    
    
    /**
     * 定义button xml 配置Key
     */

    public static final String FUN = "fun";
    
    public static final String STATUS = "status";
    
    public static final String FUNS = "funs";  
    
    public static final String DATA = "Data";  
    
    public static final String VALIDATE = "Validate";
    
    public static final String DATASET = "DataSet";
    
    public static final String EXECUTION = "execution";
    
    public static final String EXECUTIONSQL = "executionSql";

    public static final String DATAWRITEBACK = "DataWriteBack";

    public static final String TARGETTABLE = "targetTable";

    public static final String OPERATE = "operate";
    
    public static final String TABLE = "table";
    
    public static final String COUNTNUM = "countNum";

    public static final String COUNTSQL = "countSql";

    public static final String TARGETKEY = "targetKey";
    
    public static final String SOURCEKEY = "sourceKey";
    
    /**
     * 定义 默认字典 xml 配置key
     */
    public static final String GROUP_NAME = "groupName";
    
    public static final String GROUP_NO = "groupNo";
    
    public static final String I18N_KEY = "i18n_key";  
    
    public static final String DICTIONRY = "dictionary";  
    
    public static final String DICTIONARY_GROUP = "dictionaryGroup";  
    
    public static final String DICTIONARYS = "Dictionarys";  

    /**
     * 定义pushDown xml配置key
     */
    public static final String PAGE_KEY = "pageKey";  
    
    public static final String PUSH_FILED = "PushFiled";  
    
    public static final String PUSH = "push";  

    public static final String LOCATION = "location";  
    
    public static final String METHOD = "method";  
    
    public static final String PARAMETER = "parameter";  

    public static final String BASICTYPE = "basictype";
    
    /**
     * searchOrder xml配置key
     */
    public static final String SEARCHORDER = "searchOrder";
    
    public static final String KEY = "key";
    
    public static final String UPKEY = "upKey";
    
    
    /**
     * table xml 配置key
     */
    
    public static final String JDBC_TYPE = "jdbcType";  
    
    public static final String PROPERTY = "property";  
    
    public static final String IS_DETAIL = "is_detail";  

    public static final String DEFAULT_VALUE = "default_value";  
    
    public static final String IS_REQUIRED = "is_required";  
    
    public static final String IS_PERMISSION_NEED = "is_permission_need";  
    
    public static final String LENGTH = "length";
    
    public static final String FORMAT = "fomart";
    
    public static final String TAB_NUM = "tab_num";
    
    public static final String TAB_NAME = "tab_name";

    public static final String RESULTMAP = "resultMap";
    
    public static final String FOREIGN_KEY = "foreignKey";  
    
    public static final String DETAIL_ONE_KEY = "detailOneKey";  
    
    public static final String DETAIL_ONE_TO_ONE_KEY = "detailOneToOneKey";  
    
    public static final String GENERAL_ONE_TO_ONE_KEY = "generalOneToOneKey";  
    
    public static final String DETAIL_KEY = "detailKey";  

    public static final String DETAIL_NAME = "detailName";  
    
    public static final String COLUMN_ID = "columnId";  
    
    public static final String GENERAL_MODEL = "generalModel";  

    public static final String GENERAL_NAME = "generalName";

    public static final String GENERAL_KEY = "generalKey";
    
    public static final String DETAIL_MODEL = "detailModel";
    
    public static final String TABLE_NAME = "table_name";
    
    public static final String PAGE_KEY_WITH_LINE = "page_key";

    public static final String PAGE_KEY_CH = "page_key_CH";
    
    public static final String SERVER_NAME = "server_name";
    
    public static final String PRIMARY_KEY = "primaryKey";  
}
