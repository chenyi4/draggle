package com.cloud.ddp.operation;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.transform.SearchOrderTransform;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;
import com.cloud.ddp.vo.BaseObject;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年4月22日上午9:41:13
 */
@Slf4j
public class BaseOperation extends ResultWrapper{

	/**
	 * 获取json路径
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	 public static String getObjectJSONFilePath(String fileName) throws Exception {
	        String workspacePath = SystemConfigManagement.getWorkspacePath();
	        String incrementJsonFilePath = workspacePath.concat("/").concat(fileName).concat(".json");
	        return incrementJsonFilePath;
	    }
	
	 public static JSONObject getObjectsDataFromName(String fileName) throws Exception {
	        return FileUtil.readJSONObjectFromFile(getObjectJSONFilePath(fileName));
	    }

    public static JSONObject getObjectsDataFromPath(String filePath) throws Exception {
        return FileUtil.readJSONObjectFromFile(filePath);
    }
	 /**
     * 获取指定json文件中指定节点的数据（用于设计平台前端使用）
     * @param nodeId  指定节点ID
     * @param fileName  指定文件名称
     * @param arrKey
     * @param nodeKey
     * @return
     */
    public static String findObjectByNodeId(String nodeId,String fileName,String arrKey,String nodeKey) {
        try {
            JSONObject nodeData = FileUtil.readJSONObjectFromFile(getObjectJSONFilePath(fileName));
            JSONObject nodeJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(nodeData, arrKey, nodeKey, nodeId);
            if (nodeJSONObject == null) {
                return noData();
            } else {
                return ok(JSONUtils.convertKeyToCamelStyle(nodeJSONObject));
            }
        }catch (Exception e){
            log.error(e.getMessage());
            return error();
        }
    }
    
    
	 /**
     * 获取指定json文件中指定节点的数据(key不转换驼峰法)
     * @param nodeId  指定节点ID
     * @param fileName  指定文件名称
     * @param arrKey
     * @param nodeKey
     * @return
     */
    public static String findByNodeIdNoCovertKey(String nodeId,String fileName,String arrKey,String nodeKey) {
        try {
            JSONObject nodeData = FileUtil.readJSONObjectFromFile(getObjectJSONFilePath(fileName));
            JSONObject nodeJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(nodeData, arrKey, nodeKey, nodeId);
            if (nodeJSONObject == null) {
                return noData();
            } else {
                return ok(nodeJSONObject);
            }
        }catch (Exception e){
            log.error(e.getMessage());
            return error();
        }
    }

    
    
    

    /**
     * 获取指定json文件中所有节点集合（用于设计平台前端使用）
     * @param fileName
     * @param arrKey
     * @return
     * @throws Exception
     */
    public static String getNodeList(String fileName,String arrKey){        
        try {
			JSONObject tableData = FileUtil.readJSONObjectFromFile(getObjectJSONFilePath(fileName));
			JSONArray array = JSONUtils.findJSONArrayByKey(tableData,arrKey);
			if(array == null){
                return noData();
			}else{
			    return ok(JSONUtils.convertKeyToCamelStyle(array));
			}
        }catch (Exception e){
            log.error(e.getMessage());
            return error(e.getMessage());
        }
    }
    
    /**
     * 获取指定json文件节点集合
     * @param fileName
     * @param arrKey
     * @return
     */
    public static JSONArray getNodeListNoCovert(String fileName,String arrKey){
    	JSONArray array = null;
		try {
			JSONObject tableData = FileUtil.readJSONObjectFromFile(getObjectJSONFilePath(fileName));
			return array = JSONUtils.findJSONArrayByKey(tableData,arrKey);
			
		} catch (Exception e) {
            log.error(e.getMessage());
		}
		return array;
    }
    
    
    
    /**
     * 获取对应节点下指定key的集合
     * @param fileName
     * @param arrKey
     * @param key
     * @return
     */
    public static String getNodeList(String fileName,String arrKey,String key,String value){
    	try {
			JSONObject tableData = FileUtil.readJSONObjectFromFile(getObjectJSONFilePath(fileName));
			JSONArray array = getSubNodeList(JSONUtils.findJSONArrayByKey(tableData,arrKey), key, value);
			if(array == null){
                return noData();
			}else{
			    return ok(JSONUtils.convertKeyToCamelStyle(array));
			}
        }catch (Exception e){
            log.error(e.getMessage());
            return error(e.getMessage());
        }
    }
    
   
    
    public static JSONArray getSubNodeList(JSONArray array,String key,String value){
    	if(array == null){
    		return null;
    	}
    	JSONArray datas = null;
    	
    	for (Object object : array) {
			if(object instanceof JSONObject){
				JSONObject o = (JSONObject) object;
				if(o.getString(key).equals(value)){
					if(datas == null){
						datas = new JSONArray();
					}
					datas.add(o);
				}
			}
		}
    	return datas;
    }
  
    
    
    /**
     * 获取指定json文件中所有节点集合(key不转换驼峰法)
     * @param fileName
     * @param key
     * @return
     * @throws Exception
     */
    public static String getNodeListNoCovertKey(String fileName,String key){
    	 try {
 			JSONObject tableData = FileUtil.readJSONObjectFromFile(getObjectJSONFilePath(fileName));
 			JSONArray array = JSONUtils.findJSONArrayByKey(tableData,key);
 			if(array == null){
                return noData();
 			}else{
 			    return ok(array);
 			}
         }catch (Exception e){
             log.error(e.getMessage());
             return error(e.getMessage());
         }
    }
    
    
    /**
     * 添加或更新对象数据
     * @param groupName
     * @param object
     * @return
     */
    public static String addOrUpdateObject(String nodeName,String object,String fileName,String arrKey) {
        JSONObject objectJSON = JSONObject.parseObject(object);
        objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
        //如果object id不存在，则执行添加操作
        if(!objectJSON.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(objectJSON.getString(ObjectConstants.OBJECT_ID_KEY))){
            try {
                String objectId = getIncrementIndexByKey(null,ObjectConstants.OBJECT_ID_KEY,fileName,arrKey);
                objectJSON.put(ObjectConstants.OBJECT_ID_KEY,objectId);
                addObject(arrKey,objectJSON,fileName);
            } catch (Exception e) {
                log.error(e.getMessage());
                return error();
            }
        }
        //如果object id存在，则执行更新操作
        else{
            try {
                updateObject(arrKey,objectJSON,fileName);
            } catch (Exception e) {
                log.error(e.getMessage());
                return error();
            }
        }
        
        return ok(JSONUtils.convertKeyToCamelStyle(objectJSON));
    }
    
    
    
    /**
     * 新创建的object，object id是刚生成的
     * @param groupName
     * @param object
     * @throws Exception
     */
    private static void addObject(String arrKey,JSONObject object,String fileName)throws Exception{
        if(!object.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(object.getString(ObjectConstants.OBJECT_ID_KEY))){
            throw new Exception("object id 不能为空");
        }
        String objectsFilePath = getObjectJSONFilePath(fileName);
        JSONObject objects = getObjectsDataFromPath(objectsFilePath);
        JSONArray objectListArray = JSONUtils.findJSONArrayByKey(objects, arrKey);
        objectListArray.add(object);
        objects.put(arrKey,objectListArray);
        FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
    }
    
    
    
    /**
     * 获取指定项目下  form id,component id,table id; 并自动增加，最后将最新值写入文件
     * @param incrementIndexKey
     * @return
     */
    public static String getIncrementIndexByKey(String objectId,String incrementIndexKey,String fileName,String arrKey) throws Exception {
        String incrementJsonFilePath = getObjectJSONFilePath(fileName);
        JSONObject incrementJSONObject = FileUtil.readJSONObjectFromFile(incrementJsonFilePath);
        JSONArray projectArray = JSONUtils.findJSONArrayByKey(incrementJSONObject,arrKey);
        
        //查询最大index
        List<BaseObject> cardetails = JSONArray.parseArray(projectArray.toJSONString(), BaseObject.class);
        String indexStr = "1";
        Optional<BaseObject> op = cardetails.stream().filter(o -> o.getPrimaryId() != null).max(Comparator.comparing(BaseObject :: getPrimaryId));
        if(CollectionUtils.isEmpty(cardetails)){
        	return indexStr;
        }
        BaseObject obj = op.get();
        if(obj != null){
            int index = Integer.valueOf(obj.getPrimaryId()).intValue() + 1;
            indexStr = String.valueOf(index);
        }
        return indexStr;
    }

    /**
     * 根据object id 和 group name 更新对象信息
     * @param groupName
     * @param object
     * @throws Exception
     */
    private static void updateObject(String arrKey,JSONObject object,String fileName) throws Exception{
        if(!object.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(object.getString(ObjectConstants.OBJECT_ID_KEY))){
            throw new Exception("primary id 不能为空");
        }
        String objectsFilePath = getObjectJSONFilePath(fileName);
        JSONObject objects = getObjectsDataFromPath(objectsFilePath);
        JSONArray objectListArray = JSONUtils.findJSONArrayByKey(objects, arrKey);
        JSONUtils.removeDataByKeyValueFromArray(objectListArray,ObjectConstants.OBJECT_ID_KEY,object.getString(ObjectConstants.OBJECT_ID_KEY));
        objectListArray.add(object);
        objects.put(arrKey,objectListArray);
        FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
    }    
    
    
    
    /**
     * 根据object id 和 group name 更新对象信息
     * @param groupName
     * @param object
     * @throws Exception
     */
    public static String deleteObject(String arrKey,String objectId,String fileName){
       
        try {
			String objectsFilePath = getObjectJSONFilePath(fileName);
			JSONObject objects = getObjectsDataFromPath(objectsFilePath);
			JSONArray objectListArray = JSONUtils.findJSONArrayByKey(objects, arrKey);
			JSONUtils.removeDataByKeyValueFromArray(objectListArray,ObjectConstants.OBJECT_ID_KEY,objectId);
			FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
		} catch (IOException e) {
			e.printStackTrace();
			log.error("保存文件异常"+e.getMessage());
			return error("删除失败");
		} catch (Exception e) {
			e.printStackTrace();
			log.error("删除节点失败"+e.getMessage());
			return error("删除失败");
		}
        return ok("删除成功！");
    }    
    
 
}

