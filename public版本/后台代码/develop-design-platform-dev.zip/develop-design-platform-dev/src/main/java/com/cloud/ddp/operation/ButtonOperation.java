package com.cloud.ddp.operation;

import java.io.IOException;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;


/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年6月4日上午10:09:25
 */
@Slf4j
public class ButtonOperation extends ResultWrapper{
	
	
	
	/**
	 * 获取指定对象数据
	 * @param objectId
	 * @return
	 * @throws Exception
	 */
	public static JSONObject findObjectByObjectId(String objectId) throws Exception{
        JSONObject nodeData = FileUtil.readJSONObjectFromFile(BaseOperation.getObjectJSONFilePath(ConfigConstants.FILENAME_BUTTON));
        JSONObject nodeJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(nodeData, ConfigConstants.BUTTON_LIST, ObjectConstants.OBJECT_ID_KEY, objectId);
        return nodeJSONObject;
	}
	
	
	/**
	 * 加载默认数据
	 * @return
	 * @throws Exception 
	 */
	public static JSONObject loadButtonTemplate(){
		JSONObject nodeData = null;
		try {
			String path = BaseOperation.getObjectJSONFilePath(ConfigConstants.FILENAME_BUTTON_TEMPLATE);
			nodeData = FileUtil.readJSONObjectFromFile(path);
		} catch (Exception e) {
			log.error("加载按钮模板数据失败"+e.getMessage());
		}
		return nodeData;
	}
	
	
}

