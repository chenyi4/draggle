package com.cloud.ddp.operation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ComponentConstants;
import com.cloud.ddp.constants.IncrementConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.TableConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

@Slf4j
public class ComponentOperation extends ResultWrapper {


    /**
     * 新增或更新对象的组件
     * @param component
     * @return
     * @throws Exception
     */
    public static String addOrUpdateComponent(String component) {
        JSONObject componentJSON = JSONObject.parseObject(component);
//        componentJSON = (JSONObject) JSONUtils.convertKeyToLowerCaseAndAddHyphen(componentJSON);
        componentJSON.put(ObjectConstants.OBJECT_ID_KEY, componentJSON.getString("ObjectId"));
        componentJSON.remove("ObjectId");

        if (!componentJSON.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(componentJSON.getString(ObjectConstants.OBJECT_ID_KEY)) || Integer.valueOf(componentJSON.getString(ObjectConstants.OBJECT_ID_KEY)).intValue() <= 0) {
            return error("object id 参数不正确");
        }
        try{
            String objectId = componentJSON.getString(ObjectConstants.OBJECT_ID_KEY);
            String filePath = BaseOperation.getObjectJSONFilePath(ComponentConstants.COMPONENT_FILE_NAME);
            JSONObject components = FileUtil.readJSONObjectFromFile(filePath);
            JSONArray objectsArray = components.getJSONArray(ComponentConstants.OBJECTS_KEY);
            JSONUtils.removeDataByKeyValueFromArray(objectsArray, ObjectConstants.OBJECT_ID_KEY, objectId);
            processComponentsID(componentJSON);
            objectsArray.add(componentJSON);
            FileUtil.writeJSONObjectIntoFile(filePath, components);
            
            log.info("add Object Component");
            saveObjectComponents(component);
            
            return ok(CaseConversionUtils.covertLowerCaseAndToUpperKey(componentJSON, ObjectConstants.OBJECT_ID_KEY));
        }catch (Exception e){
            log.error(e.getStackTrace().toString());
            return error("添加或更新组件异常");
        }
    }

    /**
     * 根据object id查询对象的组件列表
     * @param objectId
     * @return
     */
    public static String findComponentsByObjectId(String objectId) {
        JSONObject components = null;
        try {
            components = FileUtil.readJSONObjectByFileName(ComponentConstants.COMPONENT_FILE_NAME);
            JSONObject componentJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(components,ComponentConstants.OBJECTS_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
            if(componentJSONObject != null) {
                componentJSONObject.put(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(ObjectConstants.OBJECT_ID_KEY), componentJSONObject.getString(ObjectConstants.OBJECT_ID_KEY));
                componentJSONObject.remove(ObjectConstants.OBJECT_ID_KEY);
                //重新赋值Name
                componentJSONObject = updateOrDeleteComponent(componentJSONObject);
                
                return ok(componentJSONObject);
            }else{
                return noData();
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }
    }

    /**
     * 处理组件ID，给没有ID的组件添加上ID
     * @param component
     */
    private static void processComponentsID(JSONObject component) throws Exception {
        JSONArray componentArray = component.getJSONArray(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(ComponentConstants.COMPONENT_LIST_KEY));
        Integer componentIndex = Integer.valueOf(IncrementOperation.getIncrementIndexByKeyWithoutWriteBackToFile("1", IncrementConstants.COMPONENT_INCREMENT_INDEX_KEY));
        log.info("Component Index begin value is " + String.valueOf(componentIndex));
        componentIndex = processComponentsID(componentArray,componentIndex);
        if(componentIndex != null) {
            componentIndex = componentIndex - 1;
            log.info("更新后的 component index : " + String.valueOf(componentIndex));
            IncrementOperation.updateIncrementIndexByKey("1", IncrementConstants.COMPONENT_INCREMENT_INDEX_KEY, String.valueOf(componentIndex));
        }
    }

    private static Integer processComponentsID(JSONArray componentArray,Integer componentIndex){
//        if(componentArray == null ||componentArray.size() == 0){
//            log.error("组件数组为空");
//            return null;
//        }
        for(int i=0; i < componentArray.size(); i++){
            JSONObject componentObject = componentArray.getJSONObject(i);
            if(componentObject == null){
                continue;
            }
            if(componentObject.containsKey(ComponentConstants.COMPONENT_ID_KEY) && StringUtils.isNotBlank(componentObject.getString(ComponentConstants.COMPONENT_ID_KEY))  && Integer.valueOf(componentObject.getString(ComponentConstants.COMPONENT_ID_KEY)).intValue() > 0){
                continue;
            }
            componentObject.put(ComponentConstants.COMPONENT_ID_KEY,String.valueOf(componentIndex));
            log.info("Component Index is " + String.valueOf(componentIndex));
            componentIndex += 1;
            if(componentObject.containsKey(ComponentConstants.CHILDREN_KEY)){
                JSONArray children = componentObject.getJSONArray(ComponentConstants.CHILDREN_KEY);
                componentIndex = processComponentsID(children,componentIndex);
            }
        }
        return componentIndex;
    }
    
    
    
    /**
     * 根据object id查询对象的组件列表
     * @param objectId
     * @return
     */
    public static String findObjectComponentsByObjectId(String objectId) {
        JSONObject components = null;
        try {
            components = FileUtil.readJSONObjectByFileName(ComponentConstants.OBJECT_COMPONENT_FILE_NAME);
            JSONObject componentJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(components,ComponentConstants.OBJECTS_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
            if(componentJSONObject != null) {
            	
            	//重新赋值Name
            	componentJSONObject = setComponentName(componentJSONObject);
            	
                return ok(JSONUtils.convertKeyToCamelStyle(componentJSONObject));
            }else{
                return noData();
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }
    }
    
    
    public static JSONObject setComponentName(JSONObject componentJSONObject){
    	JSONArray arr = componentJSONObject.getJSONArray("data");
    	try {
			arr = finComponentName(arr);
			componentJSONObject.put("data", arr);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("更新Name异常"+e.getMessage());
		}
    	return componentJSONObject;
    }
    
    
    public static JSONArray finComponentName(JSONArray arr) throws Exception{
    	if(arr!=null && arr.size()>0){
    		for (Object object : arr) {
				JSONObject o = (JSONObject) object;
				String componentType = o.getString(ComponentConstants.COMPONENT_TYPE);
				if(componentType.equals(ComponentConstants.COMPONENT_TYPE_INPUT)){
					String tableId = o.getString(TableConstants.TABLE_ID_KEY);
					String fieldId = o.getString(TableConstants.FIELD_ID_KEY);
					JSONObject table = null;
					if(StringUtils.isNotBlank(tableId)){
						table = TableOperation.findTableObjectByTableId(tableId);
					}
					JSONObject field = null;
					if(StringUtils.isNotBlank(fieldId) && table!=null){
						field = TableOperation.findFieldObjectByFieldId(table, fieldId);
					}
					
					if(table!=null && field!=null){
						o.put(ComponentConstants.NAME, table.getString("table-name").concat(".").concat(field.getString("field-name")));
					}					
				}else{
					JSONArray childs = o.getJSONArray(ComponentConstants.CHILDREN_KEY);
					finComponentName(childs);
				}
			}
    	}
    	
    	return arr;
    }
    
    
    
    
    
    public static  void saveObjectComponents(String component) {
        JSONObject componentJSON = JSONObject.parseObject(component);
        componentJSON = (JSONObject) JSONUtils.convertKeyToLowerCaseAndAddHyphen(componentJSON);
        try{
            String objectId = componentJSON.getString(ObjectConstants.OBJECT_ID_KEY);
            JSONArray componetList = componentJSON.getJSONArray(CaseConversionUtils.replaceUpperCaseAndUnderLine(ComponentConstants.COMPONENT_LIST_KEY));
            
            JSONObject components = FileUtil.readJSONObjectByFileName(ComponentConstants.OBJECT_COMPONENT_FILE_NAME);
            log.info("read object component info from json  ");
            JSONObject json = addOrUpdateObjectComponents(objectId, componetList, components);
            log.info("add batch fields ");
            FileUtil.writeJSONObjectIntoFile(getObjectComponentJSONFilePath(), json);
            
        }catch (Exception e){
            log.error(e.getStackTrace().toString());
            log.error("添加 object component 批量字段数据异常！");
        }

    }
    
    
    
    
    
    public static JSONArray findComponentFields(JSONArray arr,JSONArray data,JSONArray components){
    	
    	if(!CollectionUtils.isEmpty(arr)){
        	for (Object object : arr) {
				JSONObject o = (JSONObject) object;
				String componentType = o.getString(CaseConversionUtils.replaceUpperCaseAndUnderLine(ComponentConstants.COMPONENT_TYPE));
				if(StringUtils.isBlank(componentType) || componentType.equals(ComponentConstants.COMPONENT_TYPE_FRAME) || componentType.equals(ComponentConstants.COMPONENT_TYPE_INPUT)){
					continue;
				}
				if(componentType.equals(ComponentConstants.COMPONENT_TYPE_TAB)){
					JSONObject component = new JSONObject();
					component.put(ComponentConstants.COMPONENT_ID_KEY, o.getString(ComponentConstants.COMPONENT_ID_KEY));
					component.put(ComponentConstants.COMPONENT_TYPE, ComponentConstants.COMPONENT_TYPE_TAB);
					component.put(ComponentConstants.NAME, o.getString(ComponentConstants.NAME));
					component.put(ComponentConstants.TITLE, o.getString(ComponentConstants.TITLE));
					component.put(ComponentConstants.HASH, o.getString(ComponentConstants.HASH));
					data.add(component);
					
					JSONArray child = new JSONArray();
					component.put(ComponentConstants.CHILDREN_KEY, buildTree(components,child,o.getString(ComponentConstants.HASH),null));
					
					continue;
					
				}else if(componentType.equals(ComponentConstants.COMPONENT_TYPE_TABLE)){
					String parentHash = o.getString("parent-hash");
					JSONObject componet = findTabByHash(data, parentHash);
					JSONArray parentChildern = componet.getJSONArray(ComponentConstants.CHILDREN_KEY);
					JSONArray list = o.getJSONArray(ComponentConstants.CHILDREN_KEY);
					for (Object ot : list) {
						JSONObject t = (JSONObject) ot;
						String hash = t.getString(ComponentConstants.HASH);
						String title = t.getString(ComponentConstants.TITLE);
						componet.put(ComponentConstants.CHILDREN_KEY, buildTree(components,parentChildern,hash,title));
					}
					
				}else{
					JSONArray children = o.getJSONArray(ComponentConstants.CHILDREN_KEY);
					if(children!=null && children.size()>0){
						findComponentFields(children,data,components);
					}
					
				}
			}
        }
    	return data;
    }
    
    
    /**
     * 查询input类型的组件
     * @param arr
     * @param data
     * @return
     */
    public static JSONArray findInputComponents(JSONArray arr){
    	JSONArray data = new JSONArray();
    	for (Object object : arr) {
			JSONObject o = (JSONObject) object;
			String componentType = o.getString(CaseConversionUtils.replaceUpperCaseAndUnderLine(ComponentConstants.COMPONENT_TYPE));
			if(componentType.equals(ComponentConstants.COMPONENT_TYPE_INPUT) || o.containsKey(ComponentConstants.NAME)){
				data.add(o);
			}

		}
    	return data;
    }
    
    
    public static JSONArray buildTree(JSONArray components,JSONArray children,String hash,String title){    	 
    	for (Object object : components) {
			JSONObject o = (JSONObject) object;
			String parentHash = o.getString(ComponentConstants.PARENT_HASH);
			
			if(parentHash.equals(hash)){
				JSONObject child = new JSONObject();
				child.put(ComponentConstants.COMPONENT_ID_KEY, o.getString("component-id"));
				child.put(ComponentConstants.COMPONENT_TYPE, ComponentConstants.COMPONENT_TYPE_INPUT);
				child.put(ComponentConstants.NAME, o.getString(ComponentConstants.NAME));
				if(StringUtils.isNotBlank(title)){
					child.put(ComponentConstants.TITLE, title);
				}else{
					child.put(ComponentConstants.TITLE, o.getString(ComponentConstants.TITLE));
				}
				child.put(TableConstants.TABLE_ID_KEY, o.getString(CaseConversionUtils.replaceUpperCaseAndUnderLine(TableConstants.TABLE_ID_KEY)));
				child.put(TableConstants.FIELD_ID_KEY, o.getString(CaseConversionUtils.replaceUpperCaseAndUnderLine(TableConstants.FIELD_ID_KEY)));
				child.put(ComponentConstants.HASH, o.getString(ComponentConstants.HASH));
				child.put(ComponentConstants.FIELD_NAME_KEY, o.getString(ComponentConstants.FIELD_NAME_KEY));
				children.add(child);
			}
			
		}
    	components.removeAll(children);
    	
    	return children;
    }
    
    
    
    
    public static  JSONObject addOrUpdateObjectComponents(String objectId,JSONArray arr,JSONObject objectComponents) throws Exception{    	
    	JSONArray data = new JSONArray();
    	
        JSONObject componentJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(objectComponents,ComponentConstants.OBJECTS_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
        JSONArray objectListArray = JSONUtils.findJSONArrayByKey(objectComponents, ComponentConstants.OBJECTS_KEY);       
    	JSONObject object = new JSONObject();
    	object.put(ObjectConstants.OBJECT_ID_KEY, objectId);
    	object.put("data", findComponentFields(arr,data,findInputComponents(arr)));

    	if(componentJSONObject!=null){
            JSONUtils.removeDataByKeyValueFromArray(objectListArray,ObjectConstants.OBJECT_ID_KEY,objectId);
    	}
		objectListArray.add(object);
		objectComponents.put(ComponentConstants.OBJECTS_KEY,objectListArray);    	
    	return objectComponents;    	
    }
    
    
    
    private static String getObjectComponentJSONFilePath() throws Exception {
        return SystemConfigManagement.getJSONFilePathByFileName(ComponentConstants.OBJECT_COMPONENT_FILE_NAME);
    }
    
    /**
     * 校验字段是否已经修改，已修改的更新，已删除的删除页面字段
     * @return
     */
    private static JSONObject updateOrDeleteComponent(JSONObject componentJSON){
         try{
        	 
             String objectId = componentJSON.getString(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(ObjectConstants.OBJECT_ID_KEY));
             JSONArray componetList = componentJSON.getJSONArray(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(ComponentConstants.COMPONENT_LIST_KEY));
                     
             componetList = findComponentFields(componetList);
             componentJSON.put(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(ComponentConstants.COMPONENT_LIST_KEY), componetList);
             componentJSON.put(ObjectConstants.OBJECT_ID_KEY, objectId);
             componentJSON.remove(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(ObjectConstants.OBJECT_ID_KEY));


             String filePath = BaseOperation.getObjectJSONFilePath(ComponentConstants.COMPONENT_FILE_NAME);
             JSONObject components = FileUtil.readJSONObjectFromFile(filePath);
             JSONArray objectsArray = components.getJSONArray(ComponentConstants.OBJECTS_KEY);
             JSONUtils.removeDataByKeyValueFromArray(objectsArray, ObjectConstants.OBJECT_ID_KEY, objectId);
             objectsArray.add(componentJSON);
             FileUtil.writeJSONObjectIntoFile(filePath, components);
             
         }catch (Exception e){
             log.error(e.getStackTrace().toString());
             log.error("添加 object component 批量字段数据异常！");
         }
    	return componentJSON;
    }
    
    
 public static JSONArray findComponentFields(JSONArray arr) throws Exception{
    	JSONArray data = new JSONArray(arr);
    	if(!CollectionUtils.isEmpty(arr)){
        	for (int i=0;i<arr.size();i++) {
				JSONObject o = arr.getJSONObject(i);
				String componentType = o.getString("componentType");
				if(StringUtils.isNotBlank(componentType) && componentType.equals(ComponentConstants.COMPONENT_TYPE_INPUT)){
					String tableId = o.getString(ComponentConstants.TABLE_ID_KEY);
					String fieldId = o.getString(ComponentConstants.FIELD_ID_KEY);
					
					JSONObject table = TableOperation.findTableObjectByTableId(tableId);
					JSONObject field = null;
					if(table != null){
						field = TableOperation.findFieldObjectByFieldId(table, fieldId);
					}
					if(table == null || field == null){
						o.put(ComponentConstants.NAME, "");
					}else{
						o.put(ComponentConstants.NAME, table.getString("table-name").concat(".").concat(field.getString("field-name")).concat("(").concat(field.getString(ComponentConstants.NAME)).concat(")"));
						data.set(i, o);
					}
					data.set(i, o);
					
				}else{
					continue;
				}
				
			}
        }
    	return data;
    }
 
 
 	public static JSONObject findTabByHash(JSONArray tabs,String parentHash){
 		if(tabs!=null && tabs.size()>0){
 			for (Object object : tabs) {
				JSONObject o = (JSONObject) object;
				String hash = o.getString(ComponentConstants.HASH);
				if(parentHash.equals(hash)){
					return o;
				}
			}
 		}
 		return null;
 	}
}
