package com.cloud.ddp.operation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.DataReferenceConstants;
import com.cloud.ddp.constants.IncrementConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

/**
 * @author Leonard
 * @description 数据引用  back
 */
@Slf4j
public class DataReferenceOperation extends ResultWrapper {

    public static JSONArray getBackKeyListByObjectId(String objectId) throws Exception {
        JSONObject data = FileUtil.readJSONObjectByFileName(DataReferenceConstants.DATA_REFERENCE_FILE);
        JSONObject refObject = JSONUtils.findCertainJSONNodesByValueFromArray(data,DataReferenceConstants.BACK_LIST_KEY,DataReferenceConstants.PRIMARY_ID_KEY,objectId);
        if(refObject == null || !refObject.containsKey(DataReferenceConstants.REFERENCE_LIST_KEY)){
            return null;
        }
        JSONArray refArray = refObject.getJSONArray(DataReferenceConstants.REFERENCE_LIST_KEY);
        return refArray;
    }

    /**
     * 用于API
     * 根据object id查询 back key 列表
     * @param objectId
     * @return
     */
    public static String getBackKeyListByObjectID(String objectId){
        JSONArray refArray = null;
        try {
            refArray = getBackKeyListByObjectId(objectId);
            if(refArray == null || refArray.size() == 0){
                return noData();
            }else{
                return ok(JSONUtils.convertKeyToCamelStyle(refArray));
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }
    }

    /**
     * 根据object id查询数据引用对象
     * @param objectId
     * @return
     */
    public static JSONObject getDataReferenceObjectByObjectId(String objectId) throws Exception {
        JSONObject data = FileUtil.readJSONObjectByFileName(DataReferenceConstants.DATA_REFERENCE_FILE);
        JSONObject refObject = JSONUtils.findCertainJSONNodesByValueFromArray(data,DataReferenceConstants.BACK_LIST_KEY,DataReferenceConstants.PRIMARY_ID_KEY,objectId);
        if(refObject == null){
            return null;
        }
        JSONObject object = ObjectOperation.getObjectByObjectId(objectId);
        if(object == null || !object.containsKey(ObjectConstants.PAGE_KEY_KEY)){
            return null;
        }
        refObject.put(ObjectConstants.PAGE_KEY_KEY,object.getString(ObjectConstants.PAGE_KEY_KEY));
        return refObject;
    }

    /**
     * 用于API
     * 据object id查询数据引用对象
     * @param objectId
     * @return
     */
    public static String  getDataReferenceObjectByObjectID(String objectId){
        JSONObject refObject = null;
        try {
            refObject = getDataReferenceObjectByObjectId(objectId);
            if(refObject == null){
                return noData();
            }else{
                return ok(JSONUtils.convertKeyToCamelStyle(refObject));
            }
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }
    }

    /**
     * 根据object id新增或更新引用配置
     * @param refObjectString
     * @param objectId
     * @return
     */
    public static String addOrUpdateDataReference(String refObjectString,String objectId) {
        if(StringUtils.isBlank(refObjectString) || StringUtils.isBlank(objectId)){
            return error("参数为空");
        }
        String refIndexString = null;
        try {
            refIndexString = IncrementOperation.getIncrementIndexByKeyWithoutWriteBackToFile("1", IncrementConstants.REFERENCE_INCREMENT_INDEX_KEY);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("获取引用主键ID异常");
        }
        String filePath = null;
        try {
            filePath = BaseOperation.getObjectJSONFilePath(DataReferenceConstants.DATA_REFERENCE_FILE);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("获取文件路径异常");
        }

        JSONObject data = null;
        try {
            data = FileUtil.readJSONObjectFromFile(filePath);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("读取引用数据文件异常");
        }
        if(data == null){
            data = new JSONObject();
        }

        JSONArray backListArray = null;
        if(!data.containsKey(DataReferenceConstants.BACK_LIST_KEY) || data.getJSONArray(DataReferenceConstants.BACK_LIST_KEY) == null){
            backListArray = new JSONArray();
            data.put(DataReferenceConstants.BACK_LIST_KEY,backListArray);
        }else{
            backListArray = data.getJSONArray(DataReferenceConstants.BACK_LIST_KEY);
        }


        JSONObject objectDataReference = null;
        try {
            objectDataReference = JSONUtils.findCertainJSONNodesByValueFromArray(backListArray, DataReferenceConstants.PRIMARY_ID_KEY,objectId);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("数据引用配置对象不存在");
        }

        if(objectDataReference == null
                || !objectDataReference.containsKey(DataReferenceConstants.PRIMARY_ID_KEY) || StringUtils.isBlank(DataReferenceConstants.PRIMARY_ID_KEY)
        )
        {
            objectDataReference = new JSONObject();
            objectDataReference.put(DataReferenceConstants.PRIMARY_ID_KEY,objectId);
            objectDataReference.put(DataReferenceConstants.REFERENCE_LIST_KEY,new JSONArray());
            backListArray.add(objectDataReference);
        }

        JSONArray refArray = objectDataReference.getJSONArray(DataReferenceConstants.REFERENCE_LIST_KEY);
        if(refArray == null || refArray.size() == 0){
//            return error("数据引用配置对象为空");
            refArray = new JSONArray();
            objectDataReference.put(DataReferenceConstants.REFERENCE_LIST_KEY,refArray);
        }

        Object param  =  JSONObject.parseArray(refObjectString);
        JSONArray refArrayParam = (JSONArray)JSONUtils.convertKeyToLowerCaseAndAddHyphen(param);
        int refIndex = Integer.valueOf(refIndexString).intValue();

        for(Object obj : refArrayParam){
            JSONObject ref = (JSONObject)obj;
            if(!ref.containsKey(DataReferenceConstants.REF_ID_KEY) || StringUtils.isBlank(ref.getString(DataReferenceConstants.REF_ID_KEY))){
                ref.put(DataReferenceConstants.REF_ID_KEY,String.valueOf(refIndex));
                ++ refIndex;
            }else{
                try {
                    JSONUtils.removeDataByKeyValueFromArray(refArray,DataReferenceConstants.REF_ID_KEY,ref.getString(DataReferenceConstants.REF_ID_KEY));
                } catch (Exception e) {
                    e.printStackTrace();
                    log.error(e.getMessage());
                    return error("删除旧back key节点异常");
                }
            }
            refArray.add(ref);
        }
        try {
            FileUtil.writeJSONObjectIntoFile(filePath,data);
        } catch (IOException e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("保存文件异常");
        }

        refIndex = refIndex - 1;
        try {
            IncrementOperation.updateIncrementIndexByKey("1",IncrementConstants.REFERENCE_INCREMENT_INDEX_KEY,String.valueOf(refIndex));
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("更新引用自增ID异常");
        }
        return ok(JSONUtils.convertKeyToCamelStyle(objectDataReference));
    }


    /**
     * 根据object id 以及 reference id(对应back key)删除对应的数据引用节点
     * @param objectId
     * @param refId
     * @return
     */
    public static void removeRefDataBackKeyNode(String objectId,String refId) throws Exception {
        String filePath = BaseOperation.getObjectJSONFilePath(DataReferenceConstants.DATA_REFERENCE_FILE);

        JSONObject backData = FileUtil.readJSONObjectFromFile(filePath);
        JSONArray backListArray = backData.getJSONArray(DataReferenceConstants.BACK_LIST_KEY);
        JSONObject refObject = JSONUtils.findCertainJSONNodesByValueFromArray(backListArray,DataReferenceConstants.PRIMARY_ID_KEY,objectId);
        if(refObject == null){
            return;
        }
        JSONObject backKeyObject = JSONUtils.findCertainJSONNodesByValueFromArray(refObject,DataReferenceConstants.REFERENCE_LIST_KEY,DataReferenceConstants.REF_ID_KEY,refId);
        if(backKeyObject == null){
            return;
        }
        JSONUtils.removeDataByKeyValueFromArray(refObject.getJSONArray(DataReferenceConstants.REFERENCE_LIST_KEY),DataReferenceConstants.REF_ID_KEY,refId);

        FileUtil.writeJSONObjectIntoFile(filePath,backData);
    }

    public static String removeRefDataBackKeyNodeForAPI(String objectId,String refId){
        try {
            removeRefDataBackKeyNode(objectId,refId);
            return ok("删除成功");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("删除 back key 节点异常");
        }
    }

}
