package com.cloud.ddp.operation;




import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.DictionaryConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年4月22日上午9:41:13
 */
@Slf4j
public class DictionaryOperation extends ResultWrapper{

	/**
	 * 添加字典分组
	 * @param object
	 * @return
	 */
	public static String addDictionaryGroup(@RequestBody String object){
		try {
			JSONObject dataObject = JSONObject.parseObject(object);
			dataObject = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(dataObject);
			String groupNo = dataObject.getString(DictionaryConstants.DICTIONARY_GROUP_NO);
			if(StringUtils.isBlank(groupNo)){
				return error("分组编号不能为空");
			}
			String objectsFilePath = BaseOperation.getObjectJSONFilePath(ConfigConstants.FILENAME_DICTIONARY);
			JSONObject objects = BaseOperation.getObjectsDataFromPath(objectsFilePath);
			JSONArray objectListArray = JSONUtils.findJSONArrayByKey(objects, ConfigConstants.DICTIONARY_LIST);
			if(checkGroupNoIsExist(objectListArray, groupNo)){
				return error("分组编号已经存在");
			}
			
			JSONUtils.removeDataByKeyValueFromArray(objectListArray,DictionaryConstants.DICTIONARY_GROUP_NO,groupNo);
			objectListArray.add(dataObject);
			objects.put(ConfigConstants.DICTIONARY_LIST,objectListArray);
			FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
			return ok(JSONUtils.convertKeyToCamelStyle(objects));
		} catch (IOException e) {
			 e.printStackTrace();
	         log.error(e.getMessage());
	         return error("保存文件异常");
		} catch (Exception e) {
			 e.printStackTrace();
	         log.error(e.getMessage());
	         return error("添加字典分组异常");
		}
		
	}
	
	/**
	 * 删除字典分组
	 * @param objectId
	 * @return
	 */
	public static String deleteDictionaryGroupByNo(String object){
        try {
        	JSONObject jsonObject = JSONObject.parseObject(object);
			String objectsFilePath = BaseOperation.getObjectJSONFilePath(ConfigConstants.FILENAME_DICTIONARY);
			JSONObject nodeData = FileUtil.readJSONObjectFromFile(objectsFilePath);
	        JSONArray objectListArray = JSONUtils.findJSONArrayByKey(nodeData, ConfigConstants.DICTIONARY_LIST);

        	JSONArray groupNos = jsonObject.getJSONArray(DictionaryConstants.DICTIONRY_GROUP_NO_LIST_KEY);
        	for (Object o : groupNos) {
				if(o instanceof String){
					String groupNo = (String) o;
					//判断是否有下级节点
					JSONArray data = BaseOperation.getSubNodeList(objectListArray, DictionaryConstants.DICTIONARY_GROUP_NO, groupNo);
					for (Object json : data) {
						JSONObject key = (JSONObject) json;
						JSONArray childs = key.getJSONArray(DictionaryConstants.DICTIONRY_KEYS);
						if(childs!=null && childs.size()>0){
							return error("分组下面存在子级节点，不能删除");
						}
				        JSONUtils.removeDataByKeyValueFromArray(objectListArray,DictionaryConstants.DICTIONARY_GROUP_NO,groupNo);
					}
				}
			}
	        FileUtil.writeJSONObjectIntoFile(objectsFilePath,nodeData);
		} catch (Exception e) {
			 e.printStackTrace();
	         log.error(e.getMessage());
	         return error();
		}
		return ok("删除成功");
	}
	
	/**
	 * 查询获取指定字典数据   
	 * @param groupNo
	 * @return
	 */
	public static String findDictionaryGroupByNo(String groupNo){
		return BaseOperation.findObjectByNodeId(groupNo, XmlConstants.DICTIONRY, ConfigConstants.DICTIONARY_LIST, DictionaryConstants.DICTIONARY_GROUP_NO);
	}
	
	
	public static String addDictionary(String object){
		try {
			JSONArray arry = JSONArray.parseArray(object);
			JSONObject nodeData = new JSONObject();
			nodeData.put(ConfigConstants.DICTIONARY_LIST, arry);
			nodeData = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(nodeData);
			//校验空值
			String result = checkNullValue(nodeData.getJSONArray(ConfigConstants.DICTIONARY_LIST));
			JSONObject resutlJSON = JSONObject.parseObject(result);
			if(!resutlJSON.getString("code").equals(ConfigConstants.TEXT_ZERO)){
				return result;
			}
			
			//校验重复dictionary no
			if(nodeData != null){
				List<String> nos = checkDictionarys(nodeData.getJSONArray(ConfigConstants.DICTIONARY_LIST));
				if(nos!= null && nos.size()>0){
					String msg = String.join(",", nos);
					return error("存在重复的数据编号"+msg);
				}
				
			}			
	        String objectsFilePath = BaseOperation.getObjectJSONFilePath(ConfigConstants.FILENAME_DICTIONARY);
	        FileUtil.writeJSONObjectIntoFile(objectsFilePath,nodeData);			

			
			log.info("添加字典数据成功"+nodeData);
			return ok(JSONUtils.convertKeyToCamelStyle(nodeData));
		} catch (Exception e) {
			log.error(e.getStackTrace().toString());
			return error("添加字典操作异常"+e.getMessage());
		}
		
	}
	
	/**
	 * 校验分组编号是否存在
	 * @param objectListArray
	 * @param groupNo
	 * @return
	 */
	public static Boolean checkGroupNoIsExist(JSONArray objectListArray,String groupNo){
		Boolean isExist = false;
		
		for (Object object : objectListArray) {
			JSONObject data = (JSONObject) object;
			if(data.getString(DictionaryConstants.DICTIONARY_GROUP_NO).equals(groupNo)){
				isExist = true;
				break;
			}
		}
		return isExist;
	}
	
	
	
	public static List<String> checkDictionarys(JSONArray objectListArray){
		List<String> nos = new ArrayList<String>();
		if(objectListArray == null || objectListArray.size()== 0){
			return null;
		}
		List<String> list = new ArrayList<String>();
		for (Object object : objectListArray) {
			JSONObject o = (JSONObject) object;
			
			//获取字典列表值
			JSONArray dictionaries = o.getJSONArray(DictionaryConstants.DICTIONRY_KEYS);
			if(dictionaries!=null && dictionaries.size()>0){
				for (Object obj : dictionaries) {
					JSONObject child = (JSONObject) obj;
					String no = child.getString("no");
					if(list.contains(no)){
						nos.add(no);
					}else{
						list.add(no);
					}
				}
			}
						
		}
		return nos;
	}
	
	
	public static String checkNullValue(JSONArray objectListArray){
		if(objectListArray == null || objectListArray.size()== 0){
			return null;
		}
		for (Object object : objectListArray) {
			JSONObject o = (JSONObject) object;
			
			//获取字典列表值
			JSONArray dictionaries = o.getJSONArray(DictionaryConstants.DICTIONRY_KEYS);
			if(dictionaries!=null && dictionaries.size()>0){
				for (Object obj : dictionaries) {
					JSONObject child = (JSONObject) obj;
					String no = child.getString("no");
					if(StringUtils.isBlank(no)){
						return error("编号不能为空");
					}
					
					if(StringUtils.isBlank(child.getString("name"))){
						return error("名称不能为空");
					}
					
					if(StringUtils.isBlank(child.getString("value"))){
						return error("值不能为空");
					}
				}
			}
						
		}
		return ok();
	}
	
}

