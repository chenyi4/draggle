package com.cloud.ddp.operation;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.EventConstants;
import com.cloud.ddp.constants.IncrementConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年7月20日上午10:44:34
 */
@Slf4j
public class EventOperation extends ResultWrapper{
	

	/**
	 * 获取对象的事件集合
	 * @return
	 */
	public static String getEventsByObjectId(String objectId){
		JSONObject eventJSON = null;
		JSONObject target = null;
		try {
			eventJSON = getEventsData();
			target = JSONUtils.findCertainJSONNodesByValueFromArray(eventJSON,ObjectConstants.DATA_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
			
			if(target == null){
				target = new JSONObject();
			}
			//拼接事件类型列表
			target.put(EventConstants.EVENT_GROUPS, getEventGroups());
			//拼接函数
			JSONObject eventGroup = getEventGroupsData();
			target.put(EventConstants.FUNCTIONS, eventGroup.getJSONArray("functions"));
			
			return ok(JSONUtils.convertKeyToCamelStyle(target));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取事件异常");
			return error();
		}		
	}
	
	/**
	 * 添加事件
	 * @return
	 */
	public static String addOrUpdateObject(String groupName,String objectId,String object){
		
		if(StringUtils.isBlank(groupName)){
			return error("groupName 参数为空");
		}
		
		if(StringUtils.isBlank(objectId)){
			return error("objectId 为空");
		}
		JSONObject objectJSON = JSONObject.parseObject(object);
		objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
		//获取primary id
		String primaryId = objectJSON.getString(EventConstants.PRIMARY_ID);
		//判断是新增还是修改
		if(StringUtils.isBlank(primaryId)){
            try {
	            addObject(groupName, objectId, objectJSON);

			} catch (Exception e) {
				e.printStackTrace();
				String msg = "新增事件异常！"+e.getMessage();
				log.error(msg);
				return error(msg);
			}
		}else{
			try {
				updateObject(groupName, objectId, objectJSON);
			} catch (Exception e) {
				e.printStackTrace();
				String msg = "更新事件异常！"+e.getMessage();
				log.error(msg);
				return error(msg);

			}
		}
		
		return ok(JSONUtils.convertKeyToCamelStyle(objectJSON));
	}
	
	/**
	 * 删除事件
	 * @return
	 */
	public static String deleteEvent(String groupName,String objectId,String object){
		if(StringUtils.isBlank(groupName)){
			return error("groupName 参数为空");
		}
		
		if(StringUtils.isBlank(objectId)){
			return error("objectId 为空");
		}
		JSONObject objectJSON = JSONObject.parseObject(object);
		objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
		//获取primary id
		String primaryId = objectJSON.getString(EventConstants.PRIMARY_ID);
		if(StringUtils.isBlank(primaryId)){
			return error("event 事件不存在");
		}
        JSONObject objects = null;
		try {
			objects = getEventsData();
			objects = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objects);
	        JSONObject obj = JSONUtils.findCertainJSONNodesByValueFromArray(objects,ObjectConstants.DATA_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
	        if(obj == null){
	        	return error("单据对象不存在");
	        }
	        JSONArray groups = obj.getJSONArray(EventConstants.EVENTS);
	        groups = deleteByPrimaryId(primaryId, groups);
	        
	        obj.put(EventConstants.EVENTS, groups);
	        
	        FileUtil.writeJSONObjectIntoFile(getEventJSONFilePath(),objects);
		} catch (Exception e) {
			e.printStackTrace();
			String msg = "删除事件异常！"+e.getMessage();
			log.error(msg);
			return error(msg);
		}
		
		return ok("删除成功");
	}
	
	
	public static String getObjectFieldsByObjectId(String objectId){
		JSONObject data = new JSONObject();
		String result = ComponentOperation.findObjectComponentsByObjectId(objectId);
		JSONObject objectJSON = JSONObject.parseObject(result);
		if(objectJSON!=null && objectJSON.getString("code").equals(ConfigConstants.TEXT_ZERO)){
			data.put("fields", objectJSON.getJSONObject("data"));
			try {
				JSONObject eventGroup = getEventGroupsData();
				data.put("function", eventGroup.getJSONArray("functions"));
			} catch (Exception e) {
				e.printStackTrace();
				log.error("获取事件类型异常"+e.getMessage());
				return error("获取事件类型异常"+e.getMessage());
			}
			
		}
		return ok(JSONUtils.convertKeyToCamelStyle(data));
	}
	
	
	public static JSONObject getEventsData() throws Exception {
        return FileUtil.readJSONObjectFromFile(getEventJSONFilePath());
    }
	
	 public static String getEventJSONFilePath() throws Exception {
	    return SystemConfigManagement.getJSONFilePathByFileName(ConfigConstants.FILENAME_EVENT);
	 }
	 

	 
	 
	  /**
	     * 新创建的object，object id是刚生成的
	     * @param groupName
	     * @param object
	     * @throws Exception
	     */
	    private static void addObject(String groupCode,String objectId,JSONObject object)throws Exception{
	        JSONObject objects = getEventsData();
	        JSONArray data = objects.getJSONArray(EventConstants.DATA_KEY);
	        
	        String indexStr = objects.getString(EventConstants.EVENT_INCREMENT_INDEX);
	        if(StringUtils.isBlank(indexStr)){
	        	indexStr = "0";
	        }
	        Long index = Long.valueOf(indexStr).longValue() + 1;
	        object.put(EventConstants.PRIMARY_ID, index);
	        
	        objects.put(EventConstants.EVENT_INCREMENT_INDEX, index);
	        JSONObject objectJSON = JSONUtils.findCertainJSONNodesByValueFromArray(objects,ObjectConstants.DATA_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
	        JSONArray events =  new JSONArray();
	        if(objectJSON == null){
	        	objectJSON = new JSONObject();
	        	objectJSON.put(ObjectConstants.OBJECT_ID_KEY, objectId);
	        	objectJSON.put(EventConstants.EVENTS, events);
	        }else{
	        	events = objectJSON.getJSONArray(EventConstants.EVENTS);
	        }
	        JSONObject groupObject = JSONUtils.findCertainJSONNodesByValueFromArray(objectJSON,EventConstants.EVENTS,EventConstants.EVENT_GROUP_CODE,groupCode);
	        
	        JSONArray objectListArray = null;
	        if(groupObject == null){
	        	groupObject = new JSONObject();
	        	groupObject.put(EventConstants.EVENT_GROUP_CODE, groupCode);
	        	groupObject.put(EventConstants.EVENT_GROUP_NAME, getEventGroupNameByCode(groupCode));
	        }else{
	        	objectListArray = groupObject.getJSONArray(EventConstants.EVENT_LIST);
	        }
	        
	        if(objectListArray == null){
	        	objectListArray = new JSONArray();
	        }
	        objectListArray.add(object);
	        groupObject.put(EventConstants.EVENT_LIST,objectListArray);
	        
	        JSONUtils.removeDataByKeyValueFromArray(events, EventConstants.EVENT_GROUP_CODE, groupCode);
	        events.add(groupObject);
	        objectJSON.put(EventConstants.EVENTS, events);
	        
	        JSONUtils.removeDataByKeyValueFromArray(data, ObjectConstants.OBJECT_ID_KEY, objectId);
	        data.add(objectJSON);
	        objects.put(EventConstants.DATA_KEY, data);
	        
	        FileUtil.writeJSONObjectIntoFile(getEventJSONFilePath(),objects);
	    }
	    
	    
	    
	  

	    /**
	     * 根据object id 和 group name 更新对象信息
	     * @param groupName
	     * @param object
	     * @throws Exception
	     */
	    private static void updateObject(String groupCode,String objectId,JSONObject object) throws Exception{
	        JSONObject objects = getEventsData();
	        JSONObject objectJSON = JSONUtils.findCertainJSONNodesByValueFromArray(objects,ObjectConstants.DATA_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
	        JSONArray groups = objectJSON.getJSONArray(EventConstants.EVENTS);
	        
	        String primaryId = object.getString(EventConstants.PRIMARY_ID);
	        //删除对应id的事件
	        deleteByPrimaryId(primaryId, groups);
	        
	        JSONArray eventList = null;
	        JSONObject groupObject = JSONUtils.findCertainJSONNodesByValueFromArray(groups,EventConstants.EVENT_GROUP_CODE,groupCode);
	        if(groupObject == null){
	        	groupObject = new JSONObject();
	        	groupObject.put(EventConstants.EVENT_GROUP_CODE, groupCode);
	        	groupObject.put(EventConstants.EVENT_GROUP_NAME, getEventGroupNameByCode(groupCode));
	        	eventList = new JSONArray();
	        	groups.add(groupObject);
	        }else{
	        	eventList = groupObject.getJSONArray(EventConstants.EVENT_LIST);
	        }
	        eventList.add(object);
	        groupObject.put(EventConstants.EVENT_LIST,eventList);
	        
	        
	        if(groups!= null && groups.size()>0){
	        	for (int i = 0; i < groups.size(); i++) {
					JSONObject group = groups.getJSONObject(i);
					String code = group.getString(EventConstants.EVENT_GROUP_CODE);
					if(StringUtils.isNotBlank(code) && code.equals(groupCode)){
						groups.fluentSet(i, groupObject);
					}
				}
	        }
	        
	        objectJSON.put(EventConstants.EVENTS, groups);
	        
	        FileUtil.writeJSONObjectIntoFile(getEventJSONFilePath(),objects);
	    }
	    
	    
	    private static JSONArray deleteByPrimaryId(String primaryId,JSONArray groups){
	    	JSONArray newGroups = new JSONArray(groups);
	    	if(groups!=null && groups.size()>0){
	    		
	    		for (int i = 0;i<groups.size();i++) {
					JSONObject group = groups.getJSONObject(i);
					
					JSONArray eventList= group.getJSONArray(EventConstants.EVENT_LIST);
					if(eventList == null || eventList.size() == 0){
						continue;
					}
					
					JSONArray newEvents = new JSONArray(eventList);
					for (Object o : eventList) {
						JSONObject event = (JSONObject) o;
						
						String eventId = event.getString(EventConstants.PRIMARY_ID);
						if(StringUtils.isNotBlank(eventId) && primaryId.equals(eventId)){
							newEvents.remove(event);
							break;
						}						
					}
					group.put(EventConstants.EVENT_LIST, newEvents);
					if(newEvents == null || newEvents.size() == 0){
						newGroups.remove(i);
					}
				}
	    	}
	    	 return groups;
	     }
	    
	   /**
	    * 获取所有事件类型
	    * @return
	    */
	    public static JSONArray getEventGroups(){
	    	   JSONArray groups = new JSONArray();
	    	try {
				JSONObject data = getEventGroupsData();
				
				if(data!=null){
					groups =  data.getJSONArray(EventConstants.EVENT_GROUPS);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
				log.error("获取事件类型异常"+e.getMessage());
			}
	    	return groups;
	    }
	    
	    
	    public static JSONObject getEventGroupsData() throws Exception{
			String path = SystemConfigManagement.getJSONFilePathByFileName(ConfigConstants.FILENAME_EVENT_GROUPS);
			return FileUtil.readJSONObjectFromFile(path);
	    }
	    
	    
	    public static String getEventGroupNameByCode(String code) throws Exception{
	    	JSONObject data = getEventGroupsData();
	    	JSONArray groups = data.getJSONArray(EventConstants.EVENT_GROUPS);
	    	if(groups == null || groups.size()== 0){
	    		return null;
	    	}
	    	
	    	for (Object object : groups) {
				JSONObject group = (JSONObject) object;
				String groupCode = group.getString(EventConstants.EVENT_GROUP_CODE);
				String groupName = group.getString(EventConstants.EVENT_GROUP_NAME);
				if(groupCode.equals(code)){
					return groupName;
				}
			}
	    	return null;
	    }

}


    

