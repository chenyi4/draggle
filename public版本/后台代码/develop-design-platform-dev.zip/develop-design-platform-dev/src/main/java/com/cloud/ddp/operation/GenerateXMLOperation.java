package com.cloud.ddp.operation;

import com.cloud.ddp.transform.BackTransform;
import com.cloud.ddp.transform.ButtonTransform;
import com.cloud.ddp.transform.DefaultDictionaryTransform;
import com.cloud.ddp.transform.PushDownTransform;
import com.cloud.ddp.transform.SearchOrderTransform;
import com.cloud.ddp.transform.TableJsonTransform;
import com.cloud.ddp.util.ResultWrapper;
import lombok.extern.slf4j.Slf4j;


@Slf4j
public class GenerateXMLOperation extends ResultWrapper {
    public static void generateXMLByObjectId(String objectId)throws Exception{
        String result = BackTransform.transformJson(objectId);
        log.info(result);
        SearchOrderTransform.transformJson(objectId);
        
        ButtonTransform.transformJson(objectId);
        
        PushDownTransform.transformJson(objectId);
        
        BackTransform.transformJson(objectId);
    }

    public static String generateXMLByObjectIdForAPI(String objectId){
        try {
            generateXMLByObjectId(objectId);
            return ok("表单XML配置文件生成完毕");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("生成xml文件失败");
        }
    }
    
    
    public static String generateXMLDefaultDictionaryForAPI(){
        try {
            DefaultDictionaryTransform.createDictionaryXml();
            return ok("默认字典XML配置文件生成完毕");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("生成xml文件失败");
        }
    }
    
    
    public static String generateXMLTables(){
        try {
            TableJsonTransform.transformAll();
            return ok("生成表数据XML配置文件生成完毕");
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("生成xml文件失败");
        }
    }
}
