package com.cloud.ddp.operation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.IncrementConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


/**
 * ID 标识增量管理相关操作
 */
@Slf4j
public class IncrementOperation {


    /**
     * 从 increment.json获取project id 最新记录
     * @return
     * @throws Exception
     */
    public static String getNewProjectID() throws Exception {
        String incrementJsonFilePath = getIncrementJSONFilePath();
        JSONObject incrementJSONObject = FileUtil.readJSONObjectFromFile(incrementJsonFilePath);

        JSONObject targetObject = JSONUtils.findJSONObjectByChildKey(incrementJSONObject,IncrementConstants.PROJECT_ID_INCREMENT_KEY);
        if(targetObject == null){
            throw new Exception("Project ID increment data does not exist .");
        }

        String projectIdIncrement = targetObject.getString(IncrementConstants.PROJECT_ID_INCREMENT_KEY);
        Integer projectId = Integer.valueOf(projectIdIncrement) + 1;
        projectIdIncrement = String.valueOf(projectId);
        //将最新的project id写入文件
        targetObject.put(IncrementConstants.PROJECT_ID_INCREMENT_KEY,projectIdIncrement);
        FileUtil.writeJSONObjectIntoFile(incrementJsonFilePath,incrementJSONObject);

        return projectIdIncrement;
    }

    /**
     * 获取指定项目下  form id,component id,table id; 并自动增加，最后将最新值写入文件
     * @param incrementIndexKey
     * @return
     */
    public static String getIncrementIndexByKey(String projectId,String incrementIndexKey) throws Exception {
        if(StringUtils.isBlank(projectId)){
            projectId = "1";
        }
        String incrementJsonFilePath = getIncrementJSONFilePath();
        JSONObject incrementJSONObject = FileUtil.readJSONObjectFromFile(incrementJsonFilePath);
        JSONArray projectArray = JSONUtils.findJSONArrayByKey(incrementJSONObject,IncrementConstants.PROJECT_ARRAY_KEY);
        JSONObject incrementInfoOfCertainProject = JSONUtils.findCertainJSONNodesByValueFromArray(projectArray,IncrementConstants.PROJECT_ID_KEY,projectId);
        String indexStr =  incrementInfoOfCertainProject.getString(incrementIndexKey);
        int index = Integer.valueOf(indexStr).intValue() + 1;
        indexStr = String.valueOf(index);
        incrementInfoOfCertainProject.put(incrementIndexKey,indexStr);
        FileUtil.writeJSONObjectIntoFile(incrementJsonFilePath,incrementJSONObject);
        return indexStr;
    }

    public static String getIncrementIndexByKeyWithoutWriteBackToFile(String projectId,String incrementIndexKey)throws Exception{
        if(StringUtils.isBlank(projectId)){
            projectId = "1";
        }
        String incrementJsonFilePath = getIncrementJSONFilePath();
        String indexStr = getIncrementIndexByKey(incrementJsonFilePath,projectId,incrementIndexKey);
        return indexStr;
    }

    private static String getIncrementIndexByKey(String filePath,String projectId,String incrementIndexKey)throws Exception{
        JSONObject incrementJSONObject = FileUtil.readJSONObjectFromFile(filePath);
        JSONArray projectArray = JSONUtils.findJSONArrayByKey(incrementJSONObject,IncrementConstants.PROJECT_ARRAY_KEY);
        JSONObject incrementInfoOfCertainProject = JSONUtils.findCertainJSONNodesByValueFromArray(projectArray,IncrementConstants.PROJECT_ID_KEY,projectId);
        String indexStr =  incrementInfoOfCertainProject.getString(incrementIndexKey);
        log.info("increment index is " + indexStr);
        int index = Integer.valueOf(indexStr).intValue() + 1;
        indexStr = String.valueOf(index);
        return indexStr;
    }

    public static void updateIncrementIndexByKey(String projectId,String incrementIndexKey,String incrementIndexValue) throws Exception {
        if(StringUtils.isBlank(projectId)){
            projectId = "1";
        }
        String incrementJsonFilePath = getIncrementJSONFilePath();
        JSONObject incrementJSONObject = FileUtil.readJSONObjectFromFile(incrementJsonFilePath);
        JSONArray projectArray = JSONUtils.findJSONArrayByKey(incrementJSONObject,IncrementConstants.PROJECT_ARRAY_KEY);
        JSONObject incrementInfoOfCertainProject = JSONUtils.findCertainJSONNodesByValueFromArray(projectArray,IncrementConstants.PROJECT_ID_KEY,projectId);
        incrementInfoOfCertainProject.put(incrementIndexKey,incrementIndexValue);
        FileUtil.writeJSONObjectIntoFile(incrementJsonFilePath,incrementJSONObject);
    }

    /**
     * 从increment.json中根据table id查询对应表中field id的自增量
     * @param tableId
     * @return
     * @throws Exception
     */
    public static String getFieldIdByTableId(String tableId)throws Exception{
        String incrementJsonFilePath = getIncrementJSONFilePath();
        JSONObject incrementJSONObject = FileUtil.readJSONObjectFromFile(incrementJsonFilePath);
        JSONArray projectArray = JSONUtils.findJSONArrayByKey(incrementJSONObject,IncrementConstants.PROJECT_ARRAY_KEY);
        JSONArray tableArray = projectArray.getJSONObject(0).getJSONArray(IncrementConstants.TABLE_FIELD_ARRAY_KEY);
        JSONObject target = JSONUtils.findCertainJSONNodesByValueFromArray(tableArray,IncrementConstants.TABLE_ID_KEY,tableId);
        if(target == null){
            return "1";
        }
        String fieldIdString =  target.getString(IncrementConstants.FIELD_INCREMENT_INDEX);
        if(StringUtils.isNotBlank(fieldIdString)){
            int field = Integer.valueOf(fieldIdString);
            field += 1;
            return String.valueOf(field);
        }else{
            return "1";
        }
    }

    /**
     * 添加或更新表字段ID自增量
     * @param tableId
     * @param fieldId
     * @throws Exception
     */
    public static void addOrUpdateFieldIdByTableId(String tableId,String fieldId) throws Exception {
        String incrementJsonFilePath = getIncrementJSONFilePath();
        JSONObject incrementJSONObject = null;
        try {
            incrementJSONObject = FileUtil.readJSONObjectFromFile(incrementJsonFilePath);
        }catch (Exception e){
            e.printStackTrace();
            throw new Exception(e.getMessage());
        }
        JSONArray projectArray = JSONUtils.findJSONArrayByKey(incrementJSONObject,IncrementConstants.PROJECT_ARRAY_KEY);
        JSONArray tableArray = projectArray.getJSONObject(0).getJSONArray(IncrementConstants.TABLE_FIELD_ARRAY_KEY);
        JSONObject target = JSONUtils.findCertainJSONNodesByValueFromArray(tableArray,IncrementConstants.TABLE_ID_KEY,tableId);
        if(target == null){
            target = new JSONObject();
            tableArray.add(target);
        }
        target.put(IncrementConstants.TABLE_ID_KEY,tableId);
        target.put(IncrementConstants.FIELD_INCREMENT_INDEX,fieldId);

        FileUtil.writeJSONObjectIntoFile(incrementJsonFilePath,incrementJSONObject);
    }

    public static String getIncrementJSONFilePath() throws Exception {
        return SystemConfigManagement.getJSONFilePathByFileName(IncrementConstants.INCREMENT_JSON_FILE_NAME);
    }
}
