package com.cloud.ddp.operation;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.DataReferenceConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.TableConstants;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.GenerateCodeUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年7月6日下午2:11:29
 */
@Slf4j
public class ModuleOperation extends ResultWrapper{
	
	public static String copyObject(String objectId,String json){
		try {
		  String newObjectId = null;
		  JSONObject params = JSONObject.parseObject(json);
		  JSONObject object = ObjectOperation.getObjectByObjectId(objectId);
		  
		  String pageKey = params.getString("PageKey");
		  if(StringUtils.isBlank(pageKey)){
			  return error("pageKey 参数为空");
		  }
		  
		  String objectName = params.getString("ObjectName");
		  if(StringUtils.isBlank(objectName)){
			  return error("objectName 参数为空");
		  }
		  
		  String groupName = params.getString("GroupName");
		  if(StringUtils.isBlank(groupName)){
			  return error("groupName 参数为空");
		  }
		  
		  Boolean isDefault = params.getBoolean("IsDefault");
		  //重新生成pageKey
		  pageKey = pageKey.concat("_copy_").concat(GenerateCodeUtil.generateCode(null));
		  
		  //校验pageKey
		  String msg = checkPageKey(pageKey);
		  if(JSONObject.parseObject(msg).getString("code").equals(ConfigConstants.TEXT_ONE)){
			  return msg;
		  }
		  
		  //复制页面	   
		  object.put(ObjectConstants.OBJECT_NAME_KEY, objectName);
		  object.put(ObjectConstants.PAGE_KEY_KEY, pageKey);
		  object.put(ObjectConstants.IS_DEFAULT_KEY, isDefault);
		  object.remove(ObjectConstants.OBJECT_ID_KEY);
		  String result = ObjectOperation.addOrUpdateObject(groupName, object.toJSONString());
		  if(getResult(result)){
			  JSONObject newObject = JSONObject.parseObject(result).getJSONObject("data");
			  newObject = (JSONObject) JSONUtils.convertKeyToLowerCaseAndAddHyphen(newObject);
			  newObjectId = newObject.getString(ObjectConstants.OBJECT_ID_KEY);
			  log.info("复制object 菜单数据成功,ObjectId:"+newObjectId);
		  }
		  
		  //复制页面渲染文件
		  String component = ComponentOperation.findComponentsByObjectId(objectId);
		  JSONObject componentJSON = JSONObject.parseObject(component).getJSONObject("data");
		  if(componentJSON!=null){
			  componentJSON.put(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(ObjectConstants.OBJECT_ID_KEY),newObjectId);
			  if(getResult(ComponentOperation.addOrUpdateComponent(componentJSON.toJSONString()))){
				  log.info("复制页面渲染文件成功");
			  }
		  }else{
			  log.info("未发现页面文件,不需要复制"); 
		  }
		  
		  
		  //复制表数据
		  String tableDataStr = TableOperation.getTableListByObjectIDForAPI(objectId);
		  JSONObject tableDataJSON = JSONObject.parseObject(tableDataStr);
		  tableDataJSON = (JSONObject) JSONUtils.convertKeyToLowerCaseAndAddHyphen(tableDataJSON);
		  if(tableDataJSON!=null && tableDataJSON.getString("code").equals(ConfigConstants.TEXT_ZERO)){
			  JSONObject data = tableDataJSON.getJSONObject("data");
			  JSONArray tableData = data.getJSONArray("data");
			  if(tableData != null && tableData.size()>0){
				  for (Object table : tableData) {
					JSONObject tableJSON = (JSONObject) table;
					tableJSON.put(TableConstants.TABLE_NAME_KEY, tableJSON.getString(TableConstants.TABLE_NAME_KEY).concat("_").concat(pageKey));
					tableJSON.put(TableConstants.TABLE_ID_KEY, GenerateCodeUtil.generateCode(null));
					tableJSON.put(TableConstants.PAGE_KEY_KEY, pageKey);
				}
				  JSONObject resultJSON = new JSONObject();
				  resultJSON.put("data", tableData);
				  if(getResult(TableOperation.addOrUpdateTablesByPageKey(pageKey, newObjectId, groupName, resultJSON.toJSONString()))){
					  log.info("复制表数据文件成功"); 
				  };
			  }else{
				  log.info("未发现表数据,不需要复制");
			  }
		  }else{
			  log.info("未发现表数据,不需要复制");
		  }
		  

		  
		  
		  //复制查找带回文件
		  JSONObject referenceObject = DataReferenceOperation.getDataReferenceObjectByObjectId(objectId);
		  if(referenceObject!=null){
			  JSONArray refenceList = referenceObject.getJSONArray(DataReferenceConstants.REFERENCE_LIST_KEY);
			  if(getResult(DataReferenceOperation.addOrUpdateDataReference(refenceList.toJSONString(), newObjectId))){
				  log.info("复制数据引用文件成功");
			  }  
		  }else{
			  log.info("无数据引用数据,不需要复制");  //
		  }
		  
		 //复制按钮功能文件
		  String operateStr = OperateOperation.findObjectByNodeId(objectId);
		  JSONObject operate = JSONObject.parseObject(operateStr).getJSONObject("data");
		  operate = (JSONObject) JSONUtils.convertKeyToLowerCaseAndAddHyphen(operate);
		  
		  JSONObject button = operate.getJSONObject("button");

		  if(button!=null){
			  button.put(ObjectConstants.OBJECT_ID_KEY,newObjectId);
			  if(getResult(BaseOperation.addOrUpdateObject(null,button.toJSONString(),ConfigConstants.FILENAME_BUTTON,ConfigConstants.BUTTON_LIST))){
				  log.info("复制功能按钮操作文件成功");
			  }
		  }else{
			  log.info("无功能操作数据,不需要复制");
		  }
		  
		  
		  //复制下推选单文件
		  JSONObject pushDown = operate.getJSONObject("push-down");
		  if(pushDown!=null){
			  pushDown.put(ObjectConstants.OBJECT_ID_KEY,newObjectId);
			  if(getResult(PushDownOperation.addOrUpdateObject(pushDown.toJSONString(), ConfigConstants.FILENAME_PUSH_DOWN))){
				  log.info("复制下推选单文件成功");
			  }
		  }else{
			  log.info("无下推选单数据,不需要复制");
		  }
		  
		  
		  //复制上查下查文件
		  JSONObject searchOrder = operate.getJSONObject("search-order");
		  if(searchOrder!=null){
			  searchOrder.put(ObjectConstants.OBJECT_ID_KEY,newObjectId);
			  if(getResult(SearchOperation.addOrUpdateObject(searchOrder.toJSONString(), ConfigConstants.FILENAME_SEARCH_ORDER))){
				  log.info("复制上查下查文件成功");
			  }
		  }else{
			  log.info("无上查下查数据,不需要复制");
		  }
			
//		  generateXmlByObjectId(newObjectId);
		  
		} catch (Exception e) {
			log.error("模型复制异常"+e.getMessage());
			return error("模型复制失败");
		}
		return ok("模型复制成功");
		
	}
	
	//校验pageKey
	public static String checkPageKey(String pageKey){
		Map<String,String> map = new HashMap<String,String>();
		String objectsFilePath = null;
		try {
			objectsFilePath = ObjectOperation.getTableJSONFilePath();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		JSONObject objects = null;
		try {
			objects = ObjectOperation.getObjectsData(objectsFilePath);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		
		JSONArray groups = objects.getJSONArray(ObjectConstants.DATA_KEY);
		if(groups != null && groups.size()>0){
			
			for (Object object : groups) {
				JSONObject obj = (JSONObject) object;
				JSONArray objectList = obj.getJSONArray(ObjectConstants.OBJECT_LIST_KEY);
				
				if(objectList == null || objectList.size()==0){
					continue;
				}
				
				for (Object o : objectList) {
					JSONObject l = (JSONObject) o;
					map.put(l.getString(ObjectConstants.OBJECT_ID_KEY), l.getString(ObjectConstants.PAGE_KEY_KEY));
				}
			}
		}
		
		if(map.containsValue(pageKey)){
			return error("pageKey已经存在,不能重复添加");
		}
		return ok();
	}
	
	
	
	
	public static Boolean getResult(String result){
		Boolean bool = false;
		JSONObject object = JSONObject.parseObject(result);
		if(object!= null){
			String data = object.getString("code");
			if(data.equals(ConfigConstants.TEXT_ZERO)){
				return true;
			}
					
		}
		return bool;
	}
	
	
	public static void generateXmlByObjectId(String objectId){
		GenerateXMLOperation.generateXMLTables();
		log.info("生成表数据XML配置文件生成完毕");
		GenerateXMLOperation.generateXMLByObjectIdForAPI(objectId);
		log.info("表单XML配置文件生成完毕");
	}
	
	
}

