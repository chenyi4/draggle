package com.cloud.ddp.operation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.IncrementConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Leonard
 * @time 2020-04-10 16:47
 * 对象操作集合
 */
@Slf4j
public class ObjectOperation extends ResultWrapper {
    public static String getTableJSONFilePath() throws Exception {
        return SystemConfigManagement.getJSONFilePathByFileName(ObjectConstants.OBJECT_FILE_NAME);
    }

    public static JSONObject getObjectsData() throws Exception {
        return FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
    }

    public static JSONObject getObjectsData(String filePath) throws Exception {
        return FileUtil.readJSONObjectFromFile(filePath);
    }
    /**
     * 添加或更新对象数据
     * @param groupName
     * @param object
     * @return
     */
    public static String addOrUpdateObject(String groupName,String object) {
        JSONObject objectJSON = JSONObject.parseObject(object);
        objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
        //如果object id不存在，则执行添加操作
        if(!objectJSON.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(objectJSON.getString(ObjectConstants.OBJECT_ID_KEY))){
            try {
                String objectId = IncrementOperation.getIncrementIndexByKey(null, IncrementConstants.MODULE_INCREMENT_INDEX_KEY);
                objectJSON.put(ObjectConstants.OBJECT_ID_KEY,objectId);
                addObject(groupName,objectJSON);
            } catch (Exception e) {
                log.error(e.getMessage());
                return error();
            }
        }
        //如果object id存在，则执行更新操作
        else{
            try {
                updateObject(groupName,objectJSON);
            } catch (Exception e) {
                log.error(e.getMessage());
                return error();
            }
        }
        return ok(JSONUtils.convertKeyToCamelStyle(objectJSON));
    }

    /**
     * 新创建的object，object id是刚生成的
     * @param groupName
     * @param object
     * @throws Exception
     */
    private static void addObject(String groupName,JSONObject object)throws Exception{
        if(!object.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(object.getString(ObjectConstants.OBJECT_ID_KEY))){
            throw new Exception("object id 不能为空");
        }
        String objectsFilePath = getTableJSONFilePath();
        JSONObject objects = getObjectsData(objectsFilePath);
        JSONObject groupObject = JSONUtils.findCertainJSONNodesByValueFromArray(objects,ObjectConstants.DATA_KEY,ObjectConstants.GROUP_NAME_KEY,groupName);
        JSONArray objectListArray = groupObject.getJSONArray(ObjectConstants.OBJECT_LIST_KEY);
        objectListArray.add(object);
        groupObject.put(ObjectConstants.OBJECT_LIST_KEY,objectListArray);
        FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
    }

    /**
     * 根据object id 和 group name 更新对象信息
     * @param groupName
     * @param object
     * @throws Exception
     */
    private static void updateObject(String groupName,JSONObject object) throws Exception{
        if(!object.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(object.getString(ObjectConstants.OBJECT_ID_KEY))){
            throw new Exception("object id 不能为空");
        }
        String objectsFilePath = getTableJSONFilePath();
        JSONObject objects = getObjectsData(objectsFilePath);
        JSONObject groupObject = JSONUtils.findCertainJSONNodesByValueFromArray(objects,ObjectConstants.DATA_KEY,ObjectConstants.GROUP_NAME_KEY,groupName);
        JSONArray objectListArray = groupObject.getJSONArray(ObjectConstants.OBJECT_LIST_KEY);
        JSONUtils.removeDataByKeyValueFromArray(objectListArray,ObjectConstants.OBJECT_ID_KEY,object.getString(ObjectConstants.OBJECT_ID_KEY));
        objectListArray.add(object);
        groupObject.put(ObjectConstants.OBJECT_LIST_KEY,objectListArray);
        FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
    }

    /**
     * 查询所有对象信息
     * @return
     */
    public static String getAllObjects(){
        try {
            return ok(JSONUtils.convertKeyToCamelStyle(getObjectsData()));
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }
    }

    /**
     * 根据group name 和 object id更新page key
     * @param groupName
     * @param objectId
     * @param pageKey
     * @return
     */
    public static String updatePageKeyByGroupNameAndObjectId(String groupName,String objectId,String pageKey){
        if(StringUtils.isBlank(groupName) || StringUtils.isBlank(objectId) || StringUtils.isBlank(pageKey)){
            return error("参数不正确");
        }
        String objectsFilePath = null;
        try {
            objectsFilePath = getTableJSONFilePath();
        } catch (Exception e) {
            log.error(e.getMessage());
            return error();
        }
        JSONObject objects = null;
        try {
            objects = getObjectsData(objectsFilePath);
        } catch (Exception e) {
            log.error(e.getMessage());
            return error();
        }
        JSONObject groupObject = null;
        try {
            groupObject = JSONUtils.findCertainJSONNodesByValueFromArray(objects, ObjectConstants.DATA_KEY,ObjectConstants.GROUP_NAME_KEY,groupName);
        } catch (Exception e) {
            log.error(e.getMessage());
            return error();
        }
        JSONArray objectListArray = groupObject.getJSONArray(ObjectConstants.OBJECT_LIST_KEY);
        JSONObject object = null;
        try {
            object = JSONUtils.findCertainJSONNodesByValueFromArray(objectListArray, ObjectConstants.OBJECT_ID_KEY,objectId);
        } catch (Exception e) {
            log.error(e.getMessage());
            return error();
        }
        object.put(ObjectConstants.PAGE_KEY_KEY,pageKey);
        try {
            FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
        } catch (IOException e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }
        return ok();
    }

    public static String getGroupList(){
        try {
            String groupListFilePath = SystemConfigManagement.getMetaFilePathByFileName(ObjectConstants.OBJECT_GROUP_LIST_FILE_NAME);
            JSONObject group = FileUtil.readJSONObjectFromFile(groupListFilePath);
            return ok(JSONUtils.convertKeyToCamelStyle(group.getJSONArray("data")));
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }

    }

    public static String getObjectTypeList(){
        try {
            String objectTypeListFilePath = SystemConfigManagement.getMetaFilePathByFileName(ObjectConstants.OBJECT_TYPE_LIST_FILE_NAME);
            JSONObject objectType = FileUtil.readJSONObjectFromFile(objectTypeListFilePath);
            return ok(JSONUtils.convertKeyToCamelStyle(objectType.getJSONArray("data")));
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error();
        }
    }

    public static JSONObject getObjectByObjectIdForComponents(String objectId) throws Exception {
        JSONObject target = null;
        JSONObject data = getObjectsData();
        JSONArray groups = data.getJSONArray(ObjectConstants.DATA_KEY);
        for(Object group : groups){
            JSONObject groupJSONObject = (JSONObject)group;
            target = JSONUtils.findCertainJSONNodesByValueFromArray(groupJSONObject,ObjectConstants.OBJECT_LIST_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
            if(target != null && target.containsKey(ObjectConstants.OBJECT_ID_KEY) ){
                break;
            }
        }
        return target;
    }
    
    public static JSONObject getObjectByObjectId(String objectId) throws Exception {
        JSONObject target = null;
        JSONObject data = getObjectsData();
        JSONArray groups = data.getJSONArray(ObjectConstants.DATA_KEY);
        for(Object group : groups){
            JSONObject groupJSONObject = (JSONObject)group;
            target = JSONUtils.findCertainJSONNodesByValueFromArray(groupJSONObject,ObjectConstants.OBJECT_LIST_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
            if(target != null && target.containsKey(ObjectConstants.OBJECT_ID_KEY) && target.containsKey(ObjectConstants.PAGE_KEY_KEY)){
                break;
            }
        }
        return target;
    }

    
    
    public static String  removeObjectNodeByObjectIdForApi(String objectId){
    	try {
			removeObjectNodeByObjectId(objectId);
		} catch (Exception e) {
			 e.printStackTrace();
	         log.error(e.getMessage());
	         return error();
		}
    	return ok("删除成功");
    }
    
    
    
    public static void  removeObjectNodeByObjectId(String objectId) throws Exception{

        JSONObject data = getObjectsData();
        JSONArray groups = data.getJSONArray(ObjectConstants.DATA_KEY);
        
        JSONObject target = null;
        for(Object group : groups){
            JSONObject groupJSONObject = (JSONObject)group;
            target = JSONUtils.findCertainJSONNodesByValueFromArray(groupJSONObject,ObjectConstants.OBJECT_LIST_KEY,ObjectConstants.OBJECT_ID_KEY,objectId);
            if(target != null && target.containsKey(ObjectConstants.OBJECT_ID_KEY)){
                JSONUtils.removeDataByKeyValueFromArray(groupJSONObject.getJSONArray(ObjectConstants.OBJECT_LIST_KEY),ObjectConstants.OBJECT_ID_KEY,objectId);
                FileUtil.writeJSONObjectIntoFile(getTableJSONFilePath(),data); 
                
                //删除表
                TableOperation.removeTablesByObjectId(objectId);
                break;
            }
        }

    }
    
    
    /**
     * 获取所有object对象集合
     * @return
     * @throws Exception 
     */
    public static JSONArray getAllObjectList() throws Exception{
    	
    	  JSONArray objectList = new JSONArray();
    	  JSONObject data = getObjectsData();
          JSONArray groups = data.getJSONArray(ObjectConstants.DATA_KEY);
          if(groups!=null && groups.size()>0 ){
          	for (Object object : groups) {
          		JSONObject o = (JSONObject) object;
          		JSONArray children = o.getJSONArray(ObjectConstants.OBJECT_LIST_KEY);
          		if(children == null || children.size()== 0){
          			continue;
          		}
          		objectList.addAll(children);
  			}
          }
    	
    	return objectList;
    }
    
    
    public static JSONObject getServerNameByObjectId(String objectId){
    	JSONObject data = new JSONObject();
    	try {
			JSONObject object = getObjectsData();			
			
			//获取服务名称
			JSONArray groups = new JSONArray();
			if(object!=null){
				groups = object.getJSONArray("data");
				
				if(groups==null || groups.size()== 0){
					return null;
				}
				
				for (Object o : groups) {
					JSONObject group = (JSONObject) o;
					String groupName = group.getString(ObjectConstants.GROUP_NAME_KEY);
					String shortName = group.getString(ObjectConstants.SERVICE_NAME_SHORT);
					
					JSONArray list = group.getJSONArray(ObjectConstants.OBJECT_LIST_KEY);
					if(list == null || list.size() == 0){
						continue;
					}
					
					for (Object l : list) {
						JSONObject obj = (JSONObject) l;
						String objId = obj.getString(ObjectConstants.OBJECT_ID_KEY);
						if(objId.equals(objectId)){
							data.put(ObjectConstants.SERVICE_NAME_SHORT, shortName);
							data.put(ObjectConstants.GROUP_NAME, groupName);
							return data;
						}
					}
					
				}
			
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取对象异常");
		}
    	
    	return null;
    }
    
    
    
    public static List<String> getAllService(){
    	List<String> services = new ArrayList<String>();
    	try {
			JSONObject object = getObjectsData();
			if(object!=null){
				JSONArray groups = object.getJSONArray("data");
				if(groups == null || groups.size()== 0){
					return services;
				}
				
				for (Object o : groups) {
					JSONObject obj = (JSONObject) o;
					String groupName = "manage-".concat(obj.getString(ObjectConstants.GROUP_NAME));
					services.add(groupName);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("获取对象异常");
			return null;
		}			
    	
    	return services;
    }
}
