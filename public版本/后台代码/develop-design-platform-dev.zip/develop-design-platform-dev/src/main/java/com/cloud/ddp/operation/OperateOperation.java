package com.cloud.ddp.operation;


import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年4月22日上午9:41:13
 */
@Slf4j
public class OperateOperation extends ResultWrapper{

	/**
	 * 添加或者修改按钮
	 * @param operateType
	 * @param object
	 * @return
	 */
	public static String addOrUpdateObject(String operateCode,String object){
		String result = ok();
		switch (operateCode) {
		case ConfigConstants.BUTTON_SEARCH:
		case ConfigConstants.BUTTON_VIEW:
		case ConfigConstants.BUTTON_LIST:
		case ConfigConstants.BUTTON_AUDIT:
		case ConfigConstants.BUTTON_UNAUDIT:
		case ConfigConstants.BUTTON_SAVE:
		case ConfigConstants.BUTTON_REJECT:
		case ConfigConstants.BUTTON_ENABLE:
		case ConfigConstants.BUTTON_UPLOAD:
		case ConfigConstants.BUTTON_IMPORT:
		case ConfigConstants.BUTTON_EXPORT:
		case ConfigConstants.BUTTON_FILTER:
		case ConfigConstants.BUTTON_POSITION:
		case ConfigConstants.BUTTON_CHANGE:
		case ConfigConstants.BUTTON_SUBMIT:
		case ConfigConstants.BUTTON_UNSUBMIT:
		case ConfigConstants.BUTTON_UNABLE:
		case ConfigConstants.BUTTON_COPY:
		case ConfigConstants.BUTTON_PRINT:
		case ConfigConstants.BUTTON_REFRESH:
		case ConfigConstants.BUTTON_ADD:
		case ConfigConstants.BUTTON_DELETE:
		case ConfigConstants.BUTTON_CONFIGURATION:
		case ConfigConstants.BUTTON_QUIT:
			result = BaseOperation.addOrUpdateObject(null,object,ConfigConstants.FILENAME_BUTTON,ConfigConstants.BUTTON_LIST);
			break;
		case ConfigConstants.BUTTON_UPSEARCH:
		case ConfigConstants.BUTTON_SUBSEARCH:
			result = SearchOperation.addOrUpdateObject(object, ConfigConstants.FILENAME_SEARCH_ORDER);
			break;
		case ConfigConstants.BUTTON_PUSH:
		case ConfigConstants.BUTTON_SELECT_OREDER:
		case ConfigConstants.BUTTON_TYPE_PUSHDOWN:
			result = PushDownOperation.addOrUpdateObject(object, ConfigConstants.FILENAME_PUSH_DOWN);
			break;
		default:
			break;
		}		
		
		//生成xml
		JSONObject objectJSON = JSONObject.parseObject(object);
        objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
        if(objectJSON!=null && objectJSON.containsKey(ObjectConstants.OBJECT_ID_KEY)){
        	GenerateXMLOperation.generateXMLByObjectIdForAPI(objectJSON.getString(ObjectConstants.OBJECT_ID_KEY));
        }
		return result;
	}
	
	
	/**
	 * 查询对象详情
	 * @param operateType
	 * @param objectId
	 * @return
	 */
	public static String findObjectByNodeId(String objectId,String operateType){
		String result = null;
		switch (operateType) {
		case ConfigConstants.BUTTON_SEARCH:
		case ConfigConstants.BUTTON_VIEW:
		case ConfigConstants.BUTTON_LIST:
		case ConfigConstants.BUTTON_AUDIT:
		case ConfigConstants.BUTTON_UNAUDIT:
		case ConfigConstants.BUTTON_SAVE:
		case ConfigConstants.BUTTON_REJECT:
		case ConfigConstants.BUTTON_ENABLE:
		case ConfigConstants.BUTTON_UPLOAD:
		case ConfigConstants.BUTTON_IMPORT:
		case ConfigConstants.BUTTON_EXPORT:
		case ConfigConstants.BUTTON_FILTER:
		case ConfigConstants.BUTTON_POSITION:
		case ConfigConstants.BUTTON_CHANGE:
		case ConfigConstants.BUTTON_SUBMIT:
		case ConfigConstants.BUTTON_UNSUBMIT:
		case ConfigConstants.BUTTON_UNABLE:
		case ConfigConstants.BUTTON_COPY:
		case ConfigConstants.BUTTON_PRINT:
		case ConfigConstants.BUTTON_REFRESH:
		case ConfigConstants.BUTTON_ADD:
		case ConfigConstants.BUTTON_DELETE:
		case ConfigConstants.BUTTON_CONFIGURATION:
		case ConfigConstants.BUTTON_QUIT:
			result = BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_BUTTON, ConfigConstants.BUTTON_LIST, ObjectConstants.OBJECT_ID_KEY);
			break;
		case ConfigConstants.BUTTON_UPSEARCH:
		case ConfigConstants.BUTTON_SUBSEARCH:
			result = BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_SEARCH_ORDER, ConfigConstants.SEARCH_ORDER_LIST, ObjectConstants.OBJECT_ID_KEY);
			break;
		case ConfigConstants.BUTTON_PUSH:
		case ConfigConstants.BUTTON_SELECT_OREDER:
			result = BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_PUSH_DOWN, ConfigConstants.PUSH_DOWN_LIST, ObjectConstants.OBJECT_ID_KEY);
			break;
		default:
			break;
		}		
		return result;
	}
	
	
	
	/**
	 * 查询对象详情
	 * @param operateType
	 * @param objectId
	 * @return
	 */
	public static String findObjectByNodeId(String objectId){
		JSONObject data = new JSONObject();
		//查询button 按钮详情  
		String result = BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_BUTTON, ConfigConstants.BUTTON_LIST, ObjectConstants.OBJECT_ID_KEY);

		if(StringUtils.isNotBlank(result)){
			JSONObject res = JSONObject.parseObject(result);
			data.put("button", res.getJSONObject("data"));
		}
		
		//查询searchOrder按钮详情
		result = BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_SEARCH_ORDER, ConfigConstants.SEARCH_ORDER_LIST, ObjectConstants.OBJECT_ID_KEY);
		if(StringUtils.isNotBlank(result)){
			JSONObject res = JSONObject.parseObject(result);
			data.put("searchOrder", res.getJSONObject("data"));
		}
		
		//查询pushDown按钮详情
		result = BaseOperation.findObjectByNodeId(objectId, ConfigConstants.FILENAME_PUSH_DOWN, ConfigConstants.PUSH_DOWN_LIST, ObjectConstants.OBJECT_ID_KEY);
		if(StringUtils.isNotBlank(result)){
			JSONObject res = JSONObject.parseObject(result);
			data.put("pushDown", res.getJSONObject("data"));
		}
		
		//加载默认数据
		JSONObject buttonTemplate = ButtonOperation.loadButtonTemplate();
		if(buttonTemplate!= null){
			buttonTemplate = (JSONObject) JSONUtils.convertKeyToCamelStyle(buttonTemplate);
			data.put("defaultButton", buttonTemplate.getJSONArray("Fun"));
		}
		
		return ok(data);
	}
	
	
	
	public static String deleteOperateByCode(String objectId,String operateCode){
		String result = ok();
		//获取特殊按钮的所属类型上查下查/选单下推
		String type = getButtonType(objectId, operateCode);
		switch (type) {
		case ConfigConstants.BUTTON_UPSEARCH:
		case ConfigConstants.BUTTON_SUBSEARCH:
			result =  SearchOperation.deleteOperateByCode(objectId, operateCode);
			break;
		
		case ConfigConstants.BUTTON_SEARCH:
		case ConfigConstants.BUTTON_VIEW:
		case ConfigConstants.BUTTON_LIST:
		case ConfigConstants.BUTTON_AUDIT:
		case ConfigConstants.BUTTON_UNAUDIT:
		case ConfigConstants.BUTTON_SAVE:
		case ConfigConstants.BUTTON_REJECT:
		case ConfigConstants.BUTTON_ENABLE:
		case ConfigConstants.BUTTON_UPLOAD:
		case ConfigConstants.BUTTON_IMPORT:
		case ConfigConstants.BUTTON_EXPORT:
		case ConfigConstants.BUTTON_FILTER:
		case ConfigConstants.BUTTON_POSITION:
		case ConfigConstants.BUTTON_CHANGE:
		case ConfigConstants.BUTTON_SUBMIT:
		case ConfigConstants.BUTTON_UNSUBMIT:
		case ConfigConstants.BUTTON_UNABLE:
		case ConfigConstants.BUTTON_COPY:
		case ConfigConstants.BUTTON_PRINT:
		case ConfigConstants.BUTTON_REFRESH:
		case ConfigConstants.BUTTON_ADD:
		case ConfigConstants.BUTTON_DELETE:
		case ConfigConstants.BUTTON_CONFIGURATION:
		case ConfigConstants.BUTTON_QUIT:
			
			break;
		case ConfigConstants.BUTTON_PUSH:
		case ConfigConstants.BUTTON_SELECT_OREDER:
		case ConfigConstants.BUTTON_TYPE_PUSHDOWN:
			result = PushDownOperation.deleteOperateByCode(objectId, operateCode);
			break;
		default:
			break;
		}
		
		//删除按钮数据
		if(StringUtils.isNotBlank(result)){
			String code = JSONObject.parseObject(result).getString("code");
			if(!code.equals(ConfigConstants.TEXT_ONE)){
				result = deleteOperate(objectId, operateCode);
			}
		}
		
		return result;
	}
	
	
	public static String getButtonType(String objectId,String operateCode){
		
		String result = BaseOperation.findByNodeIdNoCovertKey(objectId, ConfigConstants.FILENAME_BUTTON, ConfigConstants.BUTTON_LIST, ObjectConstants.OBJECT_ID_KEY);
		if(StringUtils.isNotBlank(result)){
			JSONObject res = JSONObject.parseObject(result);
			JSONObject button = res.getJSONObject("data");
		    JSONArray funs = button == null? null:button.getJSONArray(XmlConstants.FUN);
		    
		    if(funs == null || funs.size() == 0){
		    	return operateCode;
		    }
		    
		    for (Object object : funs) {
				JSONObject fun = (JSONObject) object;
				JSONObject properties = fun.getJSONObject(ConfigConstants.PROPERTIES_TAG);
				if(properties.containsKey(XmlConstants.TYPE)){
					String code  = properties.getString(XmlConstants.FOLDER_NAME_BUTTON);
					if(StringUtils.isBlank(code)){
						continue;
					}else if(code.equals(operateCode)){
						operateCode = properties.getString(XmlConstants.TYPE);
						break;
					}
				}
				
			}

		}
		return operateCode;
	}
	
	/**
	 * 添加按钮操作
	 * @param object
	 */
	public static void addOrUpdateOperate(JSONArray objects,String fileName,String operateType){
        try {
        	String objectId= objects.getJSONObject(0).getString(ObjectConstants.OBJECT_ID_KEY);
        	if(StringUtils.isBlank(objectId)){
        		log.error("保存operate操作失败，ObjectId 不存在");
        		
        	}else{
        		JSONObject button = new JSONObject();
    			button.put(ObjectConstants.OBJECT_ID_KEY, objectId);
                String primaryId = BaseOperation.getIncrementIndexByKey(null,ObjectConstants.OBJECT_ID_KEY,fileName,ConfigConstants.BUTTON_LIST);
    			button.put(ConfigConstants.PRIMARY_KEY_ID, primaryId);
    			
    			JSONArray funs = findFunsByObjectId(objectId);
            	if(!CollectionUtils.isEmpty(objects)){
            		for (Object object : objects) {
    					JSONObject o = (JSONObject) object;
    					
    					JSONObject data = new JSONObject();
    					JSONObject properties = new JSONObject();
    					properties.put("button", o.getString("operate-code"));
    					properties.put("name", o.getString("operate-name"));
    					properties.put("type", operateType);
    					data.put(ConfigConstants.PROPERTIES_TAG, properties);
    					
    					JSONObject operate = findObjectFromArray(funs, "button", o.getString("operate-code"));
    					if(operate != null){
    						funs.remove(operate);	
    					}
    					funs.add(data);
    				}
    				  button.put(XmlConstants.FUN, funs);
    		          updateObject(button, fileName, objectId);
            	}
        		
        	}
    		
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		
	}
	
	
	
	/**
	 * 更新Object信息
	 * @param data
	 * @param fileName
	 * @param arrKey
	 * @param objectId
	 * @throws Exception
	 */
	public static void updateObject(JSONObject data,String fileName,String objectId) throws Exception{
		String objectsFilePath = BaseOperation.getObjectJSONFilePath(fileName);
        JSONObject objects = BaseOperation.getObjectsDataFromPath(objectsFilePath);
        
        JSONArray operates = JSONUtils.findJSONArrayByKey(objects, ConfigConstants.BUTTON_LIST);
        JSONObject object = JSONUtils.findCertainJSONNodesByValueFromArray(operates, ObjectConstants.OBJECT_ID_KEY, objectId);
        operates.remove(object);
        operates.add(data);

        FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);			        

	}
	
	
	
	/**
	 * 删除按钮数据
	 * @param objectId
	 * @param operateCode
	 * @return
	 */
	public static String deleteOperate(String objectId,String operateCode){
		try {
			JSONObject object = null;
			try {
				object = ButtonOperation.findObjectByObjectId(objectId);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("获取Object 对象异常："+e.getMessage());
			}
			
			if(object == null){
				return noData();
			}
			
			JSONArray funs = object.getJSONArray(XmlConstants.FUN);
			
			if(funs == null || funs.size() == 0){
				return noData("未配置任何功能按钮操作！");
			}
			
			JSONObject subNode = findObjectFromArray(funs, "button", operateCode);
			
			if(subNode!= null){
				funs.remove(subNode);
				object.put(XmlConstants.FUN, funs);
				
				updateObject(object, ConfigConstants.FILENAME_BUTTON, objectId);
			}
			return ok();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * 查询对象操作是否存在
	 * @param array
	 * @param key
	 * @param value
	 * @return
	 * @throws Exception
	 */
	  public static JSONObject findObjectFromArray(JSONArray array, String key, String value) throws Exception {
	        if(StringUtils.isBlank(key) || StringUtils.isBlank(value)){
	            throw new Exception("Params invalid");
	        }
	        if(array == null || array.size() == 0){
	            return null;
	        }
	        int size = array.size();
	        for(int i=0;i<size;i++){
	            JSONObject object = array.getJSONObject(i);
	            JSONObject node = object.getJSONObject(ConfigConstants.PROPERTIES_TAG);
	            if(node.containsKey(key)){
	                if(value.equals(node.getString(key))){
	                    return object;
	                }
	            }				
	        }
	        return null;
	    }

	
	  
	  
	  /**
	   * 查询对象的funs 集合
	   * @param objectId
	   * @return
	   */
	  public static JSONArray findFunsByObjectId(String objectId){
		JSONArray datas = null;  
		String result = BaseOperation.findByNodeIdNoCovertKey(objectId, ConfigConstants.FILENAME_BUTTON, ConfigConstants.BUTTON_LIST, ObjectConstants.OBJECT_ID_KEY);
		JSONObject object = JSONObject.parseObject(result);
		JSONObject data = object.getJSONObject("data");
		if(data == null){
			datas = new JSONArray();
		}else{
			datas = data.getJSONArray(XmlConstants.FUN);
		}		
		return datas;
	  }
	
}

