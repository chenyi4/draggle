package com.cloud.ddp.operation;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.TableConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年7月15日下午1:31:20
 */
@Slf4j
public class ProcessControlOperation extends ResultWrapper{
	
	
	public static String getPageKeys(String objectId){
		String result = getAllPageKeys(objectId);
		JSONObject resultJSON = JSONObject.parseObject(result);
		JSONObject data = new JSONObject();
		if(!resultJSON.getString("code").equals(ConfigConstants.TEXT_ZERO)){
			return result;
		}else{
			data.put("data", resultJSON.getJSONArray("data"));
		}
		
		String bindsStr = getBindPageKeys(objectId);
		JSONObject bindJSON = JSONObject.parseObject(bindsStr);
		if(bindJSON.getString("code").equals(ConfigConstants.TEXT_ZERO)){
			data.put("binds", bindJSON.getJSONArray("data"));
		}else if(bindJSON.getString("code").equals(ConfigConstants.TEXT_TWO)){
			data.put("binds", new JSONArray());
		}else{
			return bindsStr;
		}
		return ok(JSONUtils.convertKeyToCamelStyle(data));
	}
	
	/**
	 * 获取所有pageKey   
	 * @return
	 */
	public static String getAllPageKeys(String objectId){
		JSONArray data = new JSONArray();
		JSONObject object = null;
		try {
			object = ObjectOperation.getObjectsData(ObjectOperation.getTableJSONFilePath());
		} catch (Exception e) {
			log.info("获取文件异常");
		}
		
		if(object == null){
			return noData();
		}
		
		JSONArray groups = object.getJSONArray(ObjectConstants.DATA_KEY);
		 for(Object group : groups){
            JSONObject groupJSONObject = (JSONObject)group;
            
            JSONArray objectList = groupJSONObject.getJSONArray(ObjectConstants.OBJECT_LIST_KEY);
            if(objectList!= null && objectList.size()>0){
            	
            	for (Object o : objectList) {
					JSONObject obj = (JSONObject) o;
					String objId = obj.getString(ObjectConstants.OBJECT_ID_KEY);
					if(!objectId.equals(objId)){
						data.add(obj);
					}
					
				}
            }
            
		 }
		return ok(data);
	}
	
	/**
	 * 生成table_relationship JSON 数据
	 * @param objectId
	 * @param objectJSON
	 * @return
	 */
	public static String  addRelationShips(String objectId,String objectJSON){
		//获取当前object 对象的pageKey		
		JSONArray relations = new JSONArray();
		
		JSONArray objects = JSONArray.parseArray(objectJSON);
		objects = (JSONArray)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objects);
		JSONObject object = null;
		try {
			object = ObjectOperation.getObjectByObjectId(objectId);
		} catch (Exception e) {
			log.error("");
		}
		      
		if(object == null){
			return error("未设置pageKey");
		}
		String currentPageKey = object.getString(ObjectConstants.PAGE_KEY_KEY);

		JSONObject currentTable = getMainTableByObjectId(objectId);
		if(currentTable == null){
			return error("当前对象主表不存在");
		}
		String entityName =  CaseConversionUtils.getClassName(currentTable.getString(TableConstants.TABLE_NAME_KEY));
		String currentTableId = currentTable.getString(TableConstants.TABLE_ID_KEY);
		
		if(objects == null || objects.size() == 0){
			return ok();
		}
		
		JSONObject curObject = new JSONObject();
		curObject.put(ObjectConstants.OBJECT_ID_KEY, objectId);
		
		for (Object o : objects) {
			JSONObject os = (JSONObject) o;
			String pageKey = os.getString(ObjectConstants.PAGE_KEY_KEY);			
			String objId = os.getString(ObjectConstants.OBJECT_ID_KEY);
			JSONObject mainTable = getMainTableByObjectId(objId);
			
			try {
				if(mainTable == null){
					continue;
				}else{
					JSONObject relation = new JSONObject();
					relation.put("current-page-key", currentPageKey);
					relation.put("associted-page-key", pageKey);
					relation.put("associted-object-id", objId);
					relation.put("entityName", entityName);
					String sql = buildSql(mainTable,currentTableId,entityName);
					relation.put("sql", sql);
					relations.add(relation);
					
				}
			} catch (Exception e) {
				log.error("生成table_relationship sql 异常"+e.getMessage());
				return error("生成table_relationship sql 异常"+e.getMessage());
			}
			
		}
		curObject.put("ralations", relations);
		//写入文件
		try {
			writeToJSONFile(curObject);
		} catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("保存文件异常");
		}
		return ok(curObject); 
	}
	
	
	/**
	 * 获取绑定的pageKey
	 * @param objectId
	 * @return
	 */
	public static String getBindPageKeys(String objectId){
		try {
			List<String> objectIds = new ArrayList<String>();
			String result = BaseOperation.findByNodeIdNoCovertKey(objectId, ConfigConstants.FILENAME_TABLE_RELATION, TableConstants.DATA_KEY, ObjectConstants.OBJECT_ID_KEY);
			JSONObject resultJSON = JSONObject.parseObject(result);
			
			if(resultJSON.getString("code").equals(ConfigConstants.TEXT_ZERO)){
				JSONObject data = resultJSON.getJSONObject(TableConstants.DATA_KEY);
				JSONArray relations = data.getJSONArray("ralations");
				if(relations==null || relations.size()==0){
					return noData();
				}
				
				for (Object object : relations) {
					JSONObject o = (JSONObject) object;
					objectIds.add(o.getString("associted-object-id"));
				}
			}else{
				return result;
			}
			
			JSONArray data = getObjectsByObjectIds(objectIds);
			return ok(data);
			
		} catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return error("获取文件异常");
		}
	}
	
	
	/**
	 * 获取指定object对象集合
	 * @param objectIds
	 * @throws Exception 
	 */
	public static JSONArray getObjectsByObjectIds(List<String> objectIds) throws Exception{
		JSONArray data = new JSONArray();
        JSONArray objects = ObjectOperation.getAllObjectList();
        if(objects!=null && objects.size()>0){
        	for (Object object : objects) {
				JSONObject o = (JSONObject) object;
				
				String objectId = o.getString(ObjectConstants.OBJECT_ID_KEY);
				if(objectIds.contains(objectId)){
					data.add(o);
				}
			}
        }
		
        return data;
	}
	
	
	
	/**
	 * 组装生成table_relationship sql数据    
	 * @param table
	 * @return
	 * @throws Exception 
	 */
	public static String buildSql(JSONObject table, String currentTableId,String entityName) throws Exception{
		JSONArray associations = table.getJSONArray(TableConstants.TABLE_ASSOCIATION);
		if(associations == null || associations.size()== 0){
			return null;
		}
		String tableId = table.getString(TableConstants.TABLE_ID_KEY);
		String tableName = table.getString(TableConstants.TABLE_NAME_KEY);
		
		StringBuffer sql = new StringBuffer();
		for (Object object : associations) {
			JSONObject o = (JSONObject) object;
			
			String refTableId = o.getString(TableConstants.REF_TABLE_ID);
			
			String fieldId = o.getString(TableConstants.FIELD_ID_KEY);
			if(StringUtils.isBlank(tableId) || StringUtils.isBlank(fieldId) || StringUtils.isBlank(refTableId)){
				continue;
			}
			
			JSONObject field = TableOperation.findFieldObjectByTableIdAndFieldId(tableId, fieldId);
			
			if(refTableId.equals(currentTableId) && field != null){
				String fieldName = field.getString(TableConstants.FIELD_NAME);
				sql.append("SELECT * FROM ").append(tableName)
				.append(" where ").append(fieldName).append(" = {#")
				.append(entityName)
				.append(".id")
				.append("}");
			}
			
		}
		
		return sql.toString();
	}
	
	
	/**
	 * 获取对象的主表
	 * @param objectId
	 * @return
	 */
	public static JSONObject getMainTableByObjectId(String objectId){
		String result = TableOperation.getTableListByObjectIDForAPI(objectId);
		if(result == null){
			return null;
		}
		JSONObject resultJSON = JSONObject.parseObject(result);
		JSONObject objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(resultJSON.getJSONObject("data"));
		if(objectJSON == null){
			return null;
		}
		JSONArray tables = objectJSON.getJSONArray("data");
		for (Object t : tables) {
			JSONObject table = (JSONObject) t;
			Boolean isMainTable = table.getBoolean(TableConstants.IS_MAIN_TABLE);
			if(isMainTable){
				return table;
				
			}
		}
		return null;
	}
	
	/**
	 * table_relationship 数据生成到json 文件
	 * @param data
	 * @throws Exception 
	 */
	public static void  writeToJSONFile(JSONObject data) throws Exception{
		
		String path = SystemConfigManagement.getJSONFilePathByFileName(ConfigConstants.FILENAME_TABLE_RELATION);
		
		JSONObject obj = FileUtil.readJSONObjectFromFile(path);
        JSONArray objectListArray = obj.getJSONArray("data");
        JSONUtils.removeDataByKeyValueFromArray(objectListArray,ObjectConstants.OBJECT_ID_KEY,data.getString(ObjectConstants.OBJECT_ID_KEY));
        objectListArray.add(data);
        obj.put("data",objectListArray);
        FileUtil.writeJSONObjectIntoFile(path,obj);
	}
	
	
	
	
}

