package com.cloud.ddp.operation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.IncrementConstants;
import com.cloud.ddp.constants.ProjectInfoKeyConstants;
import com.cloud.ddp.constants.TableConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;
import org.apache.commons.lang3.StringUtils;

import java.io.File;

public class ProjectOperation extends ResultWrapper {

    public static String createProject(String jsonStr)throws Exception{
        if(StringUtils.isBlank(jsonStr)){
            throw new Exception("参数不正确");
        }

        JSONObject projectJSONObject = JSONUtils.parseJSONString(jsonStr);
        if (!projectJSONObject.containsKey(ProjectInfoKeyConstants.PROJECT_NAME_KEY) || StringUtils.isBlank(projectJSONObject.getString(ProjectInfoKeyConstants.PROJECT_NAME_KEY))) {
            throw new Exception("项目名不能为空");
        }

        //尝试获取 project list 文件

        String projectListJsonFilePath = getProjectListJSONFilePath();
        File projectListJsonFile = new File(projectListJsonFilePath);


        if (projectListJsonFile.exists()) {
            JSONObject projectListJSONObject = FileUtil.readJSONObjectFromFile(projectListJsonFilePath);

            if(!checkProjectNameExistence(projectJSONObject.getString(ProjectInfoKeyConstants.PROJECT_NAME_KEY),projectListJSONObject)){
                //获取一个project id,组装进 projectJSONObject，插入到 project list array中
                String projectId = IncrementOperation.getNewProjectID();
                projectJSONObject.put(ProjectInfoKeyConstants.PROJECT_ID_KEY,projectId);
                JSONArray projectJSONArray = projectListJSONObject.getJSONArray(ProjectInfoKeyConstants.PROJECT_LIST_KEY);
                projectJSONArray.add(projectJSONObject);
                FileUtil.writeJSONObjectIntoFile(projectListJsonFilePath,projectListJSONObject);
            }else{
                throw new Exception("项目名称已存在");
            }
        }else{
            String projectId = IncrementOperation.getNewProjectID();
            projectJSONObject.put(ProjectInfoKeyConstants.PROJECT_ID_KEY,projectId);

            JSONArray projectJSONArray = new JSONArray();
            projectJSONArray.add(projectJSONObject);

            JSONObject projectListJSONObject = new JSONObject();
            projectListJSONObject.put(ProjectInfoKeyConstants.PROJECT_LIST_KEY,projectJSONArray);
            FileUtil.writeJSONObjectIntoFile(projectListJsonFilePath,projectListJSONObject);
        }

        return JSONObject.toJSONString(projectJSONObject);
    }

    public static boolean checkProjectNameExistence(String projectName, JSONObject jsonObject) throws Exception {
        JSONObject projectJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(jsonObject,ProjectInfoKeyConstants.PROJECT_LIST_KEY,ProjectInfoKeyConstants.PROJECT_NAME_KEY,projectName);
        if(projectJSONObject == null){
            return false;
        }else{
            return true;
        }
    }

    public static String getProjectListJSONFilePath() throws Exception {
        return SystemConfigManagement.getJSONFilePathByFileName(ProjectInfoKeyConstants.PROJECT_INFO_JSON_FILE_NAME);
    }

}
