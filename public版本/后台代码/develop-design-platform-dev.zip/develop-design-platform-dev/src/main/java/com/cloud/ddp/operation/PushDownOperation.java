package com.cloud.ddp.operation;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PushDownOperation extends ResultWrapper{

			 
	 
	/**
	 * 添加按钮操作
	 * @param object
	 */
	public static String addOrUpdateObject(String object,String fileName){
        try {        	
        	//组装保存operate数据
            JSONObject objectJSON = JSONObject.parseObject(object);
            objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
            
            if(objectJSON != null){
            	JSONArray list = objectJSON.getJSONArray(XmlConstants.PUSH);
            	JSONArray operates = null;
            	for (Object os : list) {
					JSONObject ot = (JSONObject) os;
					
					if(operates == null){
						operates = new JSONArray();
					}
					String operateCode = ot.getString("key");
					if(StringUtils.isBlank(operateCode)){
						return error("操作代码不能为空");
					}
					String pushType = ot.getString("operate-code");
 					JSONObject operate = new JSONObject();
					operate.put("object-id", objectJSON.get("object-id"));
					operate.put("operate-code", operateCode);
					operate.put("operate-name", getPushDownName(pushType));
					operates.add(operate);
				}
            	OperateOperation.addOrUpdateOperate(operates, ConfigConstants.FILENAME_BUTTON,ConfigConstants.BUTTON_TYPE_PUSHDOWN);
            }    
            
        	String result = addOrUpdateNode(object, fileName);

        	return result;
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		return null;
	}
	
	
	public static String deleteOperateByCode(String objectId,String operateCode){
		//获取OBject 对象
		try {
			String result = BaseOperation.findByNodeIdNoCovertKey(objectId, ConfigConstants.FILENAME_PUSH_DOWN, ConfigConstants.PUSH_LIST, ObjectConstants.OBJECT_ID_KEY);
			
			//删除operateCode对应部分
			if(StringUtils.isNoneBlank(result)){
				JSONObject data = JSONObject.parseObject(result).getJSONObject("data");
				if(data == null){
					return noData();
				}
				JSONArray push = data.getJSONArray(XmlConstants.PUSH);
				JSONObject subNode = JSONUtils.findCertainJSONNodesByValueFromArray(push, "key", operateCode);
				if(subNode != null){
					push.remove(subNode);
					data.put(XmlConstants.PUSH, push);
					String objectsFilePath = BaseOperation.getObjectJSONFilePath(ConfigConstants.FILENAME_PUSH_DOWN);
			        JSONObject objects = BaseOperation.getObjectsDataFromPath(objectsFilePath);
			        
			        JSONArray list = JSONUtils.findJSONArrayByKey(objects, ConfigConstants.PUSH_LIST);
			        JSONObject object = JSONUtils.findCertainJSONNodesByValueFromArray(list, ObjectConstants.OBJECT_ID_KEY, objectId);
			        list.remove(object);
			        list.add(data);
			        objects.put(ConfigConstants.PUSH_LIST, list);
					FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
				}else{
					return noData();
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return error(e.getMessage());
		}
		
		return  ok();
	}
	
	
	
	public static String getPushDownName(String pushCode){
		String name = null;
		switch (pushCode) {
		case ConfigConstants.BUTTON_PUSH:
			name = ConfigConstants.NAME_PUSH_DOWN;
			break;
		case ConfigConstants.BUTTON_SELECT_OREDER:
			name = ConfigConstants.NAME_SELECT_ORDER;
		default:
			break;
		}
		return name;
	}
	
	
	
	public static String addOrUpdateNode(String object,String fileName) throws Exception{
 		JSONObject objectJSON = JSONObject.parseObject(object);
		objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
		 if(!objectJSON.containsKey(ObjectConstants.OBJECT_ID_KEY) || StringUtils.isBlank(objectJSON.getString(ObjectConstants.OBJECT_ID_KEY))){
	            throw new Exception("Object id 不能为空");
	        }
		 
		 	JSONArray newPushList = objectJSON.getJSONArray(ConfigConstants.BUTTON_PUSH);
		 	
		 	JSONArray pushs = BaseOperation.getNodeListNoCovert(fileName, ConfigConstants.PUSH_LIST);
		 	JSONArray objectPushs = BaseOperation.getSubNodeList(pushs, ObjectConstants.OBJECT_ID_KEY, objectJSON.getString(ObjectConstants.OBJECT_ID_KEY));
		 	
		 	JSONArray oldPushList =  new JSONArray();
		 	if(objectPushs != null && objectPushs.size()> 0){
		 		oldPushList = objectPushs.getJSONObject(0).getJSONArray(ConfigConstants.BUTTON_PUSH);
		 	}
		 	//判断是新增还是更新
	 		for (Object o : newPushList) {
				JSONObject nbj = (JSONObject) o;
				String newKey = nbj.getString("key");
				String type = ConfigConstants.OPERATE_TYPE_CREATE;
				
				for (int i = 0; i < oldPushList.size(); i++) {
					JSONObject obj = oldPushList.getJSONObject(i);
					String oldKey = obj.getString("key");
					if(newKey.equals(oldKey)){
						type = ConfigConstants.OPERATE_TYPE_UPDATE;
						oldPushList.set(i, nbj);
					}
				}
				
				if(type.equals(ConfigConstants.OPERATE_TYPE_CREATE)){
					oldPushList.add(nbj);
				}
			}
	 		
	 		objectJSON.put(ConfigConstants.BUTTON_PUSH, oldPushList);		 	
		 
	        String objectsFilePath = BaseOperation.getObjectJSONFilePath(fileName);
	        JSONObject objects = BaseOperation.getObjectsDataFromPath(objectsFilePath);
	        JSONArray objectListArray = JSONUtils.findJSONArrayByKey(objects, ConfigConstants.PUSH_LIST);
	        JSONUtils.removeDataByKeyValueFromArray(objectListArray,ObjectConstants.OBJECT_ID_KEY,objectJSON.getString(ObjectConstants.OBJECT_ID_KEY));
	        objectListArray.add(objectJSON);
	        objects.put(ConfigConstants.PUSH_LIST,objectListArray);
	        FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
	        return ok(JSONUtils.convertKeyToCamelStyle(objectJSON));
	}
}

