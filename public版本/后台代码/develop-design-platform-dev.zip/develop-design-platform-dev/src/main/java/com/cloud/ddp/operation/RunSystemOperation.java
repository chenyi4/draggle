package com.cloud.ddp.operation;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.util.ResultWrapper;
import com.cloud.ddp.vo.FileInfo;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年7月10日下午1:48:21
 */
@Slf4j
public class RunSystemOperation extends ResultWrapper{

    //调用其他的可执行文件，例如：自己制作的exe，或是 下载 安装的软件. //
    public static String executeExe() {  

    	String os = System.getProperty("os.name");  
		
	    Runtime rn = Runtime.getRuntime();
	    Process p = null;
	    try {
	    	if(os.toLowerCase().startsWith("win")){  
	    		p = rn.exec("cmd /c start "+ConfigConstants.EXE_PATH);
	  		}else{	  				  			
	  			executeJarForLinux();
	  		}
	    	
	    	//执行打包操作
	    	runSystem();
	    } catch (Exception e) { 
	      log.error("Error exec!"+e.getMessage());
	      return error("error exe"+e.getMessage());
	    }
	    return ok("发布成功!");
    }
    
    
    
    //调用其他的可执行文件，例如：自己制作的exe，或是 下载 安装的软件. //
    public static String runSystem() {  
	    Runtime rn = Runtime.getRuntime();
	    try {
	    	//获取服务列表
	    	List<String> list = ObjectOperation.getAllService();
	    	String services = String.join(",", list);
	    	log.info("stop service start:"+services);
	    	//stop服务
	    	String[] args = new String[] { "/bin/bash","-c", "fab -f /opt/app/ddp-script.py stop_list:"+services};
	    	
	    	Process process = rn.exec(args);
	    	log.info("停止服务脚本："+args[2]);
			BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String line;
			
			while ((line = in.readLine()) != null) {
				log.info(line);
			}
			in.close();
			int re = process.waitFor();
			System.out.println("stop service end...."+re);


	    	log.info("package start.......");
			String[] args1 = new String[] {"/bin/bash","-c","fab -f /opt/app/ddp-script.py deploy_all:"+services};
			 Process p = Runtime.getRuntime().exec(args1);
			BufferedReader ins = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String lline;
			while ((lline = ins.readLine()) != null) {
				log.info(lline);
			}
			ins.close();
			int code = p.waitFor();
			log.info("run end...."+code);
	    	log.info("服务运行脚本结束："+args1[2]);
	    	
	    	

	    } catch (Exception e) {
	      log.error("Error exec!"+e.getMessage());
	      return error("error exe"+e.getMessage());
	    }
	    return ok("启动中");
    }
    
    
    
     public static void executeJarForLinux() {
          Runtime run = Runtime.getRuntime();
          File wd = new File("/bin");
          System.out.println(wd);
          Process proc = null;
          try {
              proc = run.exec("/bin/bash", null, wd);
          } catch (IOException e) {
              e.printStackTrace();
          }
         if (proc != null) {
             BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
             PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(proc.getOutputStream())), true);
             out.println("cd "+ConfigConstants.GEN_JAR_PATH);
             out.println("pwd");
             out.println("java -jar GEN.jar");
             out.println("exit");//这个命令必须执行，否则in流不结束。
             
             try {
                 String line;
                 while ((line = in.readLine()) != null) {
                     System.out.println(line);
                 }
                 proc.waitFor();
                 in.close();
                 out.close();
                 proc.destroy();
             } catch (Exception e) {
                 e.printStackTrace();
             }
         }
    }
    
    //
    
    public static String upload(MultipartFile file,String pageKey,String groupName)  {
    	String md5 = null;
    	FileInfo fileInfo = new FileInfo();
		try {
			md5 = fileMd5(file.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		fileInfo.setId(md5);// 将文件的md5设置为文件表的id
		fileInfo.setName(file.getOriginalFilename());
		fileInfo.setContentType(file.getContentType());
		fileInfo.setIsImg(fileInfo.getContentType().startsWith("image/"));
		fileInfo.setSize(file.getSize());
		fileInfo.setCreateTime(new Date());
		
		if (!fileInfo.getName().contains(".")) {
			fileInfo.setState("2");
			throw new IllegalArgumentException("缺少后缀名");
		}
		if(StringUtils.isBlank(groupName)){
			return error("groupName 参数不能为空");
		}
		
		if(StringUtils.isBlank(pageKey)){
			return error("pageKey 参数不能为空");
		}
		 
		//文件所在目录
		String path = ConfigConstants.PAGES_PATH.concat("/").concat(groupName)
				.concat("/").concat(pageKey);
		
		log.info("发布文件路径："+path);
				
		File fi = new File(path);
		if (!fi.exists())  {
			 fi.mkdir();
		}
		//创建文件
		path = path.concat("/").concat(fileInfo.getName());
		File f = new File(path);
		
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(f);
			out.write(file.getBytes());
			
			out.flush();
			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return error("文件发布失败"+e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			return error("文件发布失败"+e.getMessage());
		}finally{
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
				return error("关闭文件异常"+e.getMessage());
			}
		}
    	return ok("文件发布成功");
    }
    
    
    /**
	 * 文件的md5
	 * 
	 * @param inputStream
	 * @return
	 */
	public static String fileMd5(InputStream inputStream) {
		try {
			return DigestUtils.md5Hex(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		return null;
	}
    
	
	
    

}

