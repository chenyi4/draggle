package com.cloud.ddp.operation;


import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.operation;
 * 描述：
 * @author wenlu
 * @date 2020年4月22日上午9:41:13
 */
@Slf4j
public class SearchOperation extends ResultWrapper{

	/**
	 * 添加按钮操作
	 * @param object
	 */
	public static String addOrUpdateObject(String object,String fileName){
        try {
        	//组装保存operate数据
            JSONObject objectJSON = JSONObject.parseObject(object);
            objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
            
            String arrStr = BaseOperation.getNodeList(fileName, ConfigConstants.SEARCH_ORDER_LIST, ObjectConstants.OBJECT_ID_KEY, objectJSON.getString(ObjectConstants.OBJECT_ID_KEY));
            JSONObject js = JSONObject.parseObject(arrStr);
            JSONArray json = js.getJSONArray("data");

            for (Object o : json) {
				JSONObject jsonObj = (JSONObject) o;
				jsonObj = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);

	            if(json != null){
	            	JSONArray searchList = jsonObj.getJSONArray("search-list");
	            	JSONArray operates = null;
	            	for (Object os : searchList) {
						JSONObject ot = (JSONObject) os;
						
						if(operates == null){
							operates = new JSONArray();
						}
						
						String operateCode = ot.getString("key");
						if(StringUtils.isBlank(operateCode)){
							return error("操作代码不能为空");
						}
						JSONObject operate = new JSONObject();
						operate.put("object-id", objectJSON.get("object-id"));
						operate.put("operate-code", ot.get("operate-code"));
						operate.put("operate-name", ot.get("search-display-name"));
						operates.add(operate);
					}
	            	OperateOperation.addOrUpdateOperate(operates, ConfigConstants.FILENAME_BUTTON,ConfigConstants.BUTTON_TYPE_SEARCHORDER);
	            }
			}  
        	String result = BaseOperation.addOrUpdateObject(null,object,ConfigConstants.FILENAME_SEARCH_ORDER,ConfigConstants.SEARCH_ORDER_LIST);

        	return result;
		} catch (Exception e) {
			log.error(e.getMessage());
		}

		return null;
	}
	
	
	public static String deleteOperateByCode(String objectId,String operateCode){
		//获取OBject 对象
		try {
			String result = BaseOperation.findByNodeIdNoCovertKey(objectId, ConfigConstants.FILENAME_SEARCH_ORDER, ConfigConstants.SEARCH_ORDER_LIST, ObjectConstants.OBJECT_ID_KEY);
			
			//删除operateCode对应部分
			if(StringUtils.isNoneBlank(result)){
				JSONObject data = JSONObject.parseObject(result).getJSONObject("data");
				JSONArray searchList = data.getJSONArray("search-list");
				JSONObject subNode = JSONUtils.findCertainJSONNodesByValueFromArray(searchList, "operate-code", operateCode);
				if(subNode != null){
					searchList.remove(subNode);
					data.put("search-list", searchList);
					String objectsFilePath = BaseOperation.getObjectJSONFilePath(ConfigConstants.FILENAME_SEARCH_ORDER);
			        JSONObject objects = BaseOperation.getObjectsDataFromPath(objectsFilePath);
			        
			        JSONArray list = JSONUtils.findJSONArrayByKey(objects, ConfigConstants.SEARCH_ORDER_LIST);
			        JSONObject object = JSONUtils.findCertainJSONNodesByValueFromArray(list, ObjectConstants.OBJECT_ID_KEY, objectId);
			        list.remove(object);
			        list.add(data);
			        objects.put(ConfigConstants.SEARCH_ORDER_LIST, list);
					FileUtil.writeJSONObjectIntoFile(objectsFilePath,objects);
				}else{
					return noData();
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage());
			return error(e.getMessage());
		}
		
		return  ok();
	}
}

