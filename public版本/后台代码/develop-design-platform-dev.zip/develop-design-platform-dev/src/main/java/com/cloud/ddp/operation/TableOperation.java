package com.cloud.ddp.operation;


import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.IncrementConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.TableConstants;
import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;


@Slf4j
public class TableOperation extends ResultWrapper {

    private static String getTableJSONFilePath() throws Exception {
        return SystemConfigManagement.getJSONFilePathByFileName(TableConstants.TABLE_DATA_FILE);
    }


    /**
     * 用于生成xml时使用
     * @param tableId
     * @return
     * @throws Exception
     */
    public static JSONObject findTableObjectByTableId(String tableId) throws Exception {
        JSONObject tableData = FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
        JSONObject tableJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(tableData, TableConstants.TABLES_KEY, TableConstants.TABLE_ID_KEY, tableId);
        return tableJSONObject;
    }

    /**
     * 用于设计平台前端调用
     * @param tableId
     * @return
     */
    public static String findTableByTableId(String tableId) {
        try {
            JSONObject tableJSONObject = findTableObjectByTableId(tableId);
            if (tableJSONObject == null) {
                return noData();
            } else {
                return ok(JSONUtils.convertKeyToCamelStyle(tableJSONObject));
            }
        }catch (Exception e){
            log.error(e.getMessage());
            return error();
        }
    }


    /**
     * 在 table json object中根据field id查询 字段信息
     * @param tableJSONObject
     * @param fieldId
     * @return
     * @throws Exception
     */
    public static JSONObject findFieldObjectByFieldId(JSONObject tableJSONObject,String fieldId) throws Exception {
        JSONObject fieldJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(tableJSONObject,TableConstants.FIELD_LIST_KEY,TableConstants.FIELD_ID_KEY,fieldId);
        return fieldJSONObject;
    }

    /**
     * 根据table id 和 field id查询对应的field 信息
     * @param tableId
     * @param fieldId
     * @return
     * @throws Exception
     */
    public static JSONObject findFieldObjectByTableIdAndFieldId(String tableId,String fieldId) throws Exception {
        JSONObject tableJSONObject = findTableObjectByTableId(tableId);
        JSONObject fieldJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(tableJSONObject,TableConstants.FIELD_LIST_KEY,TableConstants.FIELD_ID_KEY,fieldId);
        return fieldJSONObject;
    }

    /**
     * 用于设计平台前端调用
     * @return
     * @throws Exception
     */
    public static String getAllTableList() {
        try {
            JSONObject tableData = FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
            JSONArray array = JSONUtils.findJSONArrayByKey(tableData, TableConstants.TABLES_KEY);
            if (array == null) {
                return noData();
            } else {
                return ok(JSONUtils.convertKeyToCamelStyle(array));
            }
        }catch (Exception e){
            log.error(e.getMessage());
            return error();
        }
    }

    public static String getTableListByObjectIDForAPI(String objectId){
        try {
            if (StringUtils.isBlank(objectId)) {
                String errorMessage = "page key 不能为空";
                log.error(errorMessage);
                return error(errorMessage);
            }
            
            JSONObject object = ObjectOperation.getObjectByObjectIdForComponents(objectId);
            if(object == null){
            	 log.error("不存在该单据对象");
                 return error("不存在该单据对象");
            }
            JSONObject tablesData = FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
            JSONArray array = JSONUtils.findJSONNodesByValueFromArray(tablesData, TableConstants.TABLES_KEY, TableConstants.OBJECT_ID_KEY, objectId);
            
            //拼接是否启用树结构
            JSONObject data = new JSONObject();
            data.put(TableConstants.IS_TREE, object.getBoolean(TableConstants.IS_TREE)!=null ?object.getBoolean(TableConstants.IS_TREE):false );
            data.put(TableConstants.DATA_KEY, array);
            
            //拼接服务名称
            JSONObject group = ObjectOperation.getServerNameByObjectId(objectId);
            if(group!=null){
                data.put(ObjectConstants.GROUP_NAME, group.getString(ObjectConstants.GROUP_NAME));
                data.put(ObjectConstants.SERVICE_NAME_SHORT, group.getString(ObjectConstants.SERVICE_NAME_SHORT));
            }
            
            //拼接主表信息
            JSONObject table = getMainTableInfo(array);
            if(table!= null){
            	data.put("mainTableName", CaseConversionUtils.getClassName(table.getString(TableConstants.TABLE_NAME_KEY)));
            }
            
            
            if (array == null) {
                return noData();
            } else {
                return ok(JSONUtils.convertKeyToCamelStyle(data));
            }
        }catch (Exception e){
            log.error(e.getMessage());
            return error();
        }
    }

    /**
     * 根据 object id查询table list，并关联object 查询出对应的page key
     * @param objectId
     * @return
     * @throws Exception
     */
    public JSONArray getTableListByObjectId(String objectId) throws Exception {
        if (StringUtils.isBlank(objectId)) {
            String errorMessage = "object id 不能为空";
            throw new Exception(errorMessage);
        }

        JSONObject object = ObjectOperation.getObjectByObjectId(objectId);
        if(object == null || !object.containsKey(ObjectConstants.PAGE_KEY_KEY)){
            throw new Exception("表单对象不存在");
        }
        String pageKey = object.getString(ObjectConstants.PAGE_KEY_KEY);
        JSONObject tablesData = FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
        JSONArray array = JSONUtils.findJSONNodesByValueFromArray(tablesData, TableConstants.TABLES_KEY, TableConstants.OBJECT_ID_KEY, objectId);
        if(array == null || array.size() == 0){
            return null;
        }
        for(Object obj : array){
            JSONObject jsonObject = (JSONObject)obj;
            jsonObject.put(ObjectConstants.PAGE_KEY_KEY,pageKey);
        }
        return array;
    }

    /**
     * 创建一个新的tables数据JSONObject
     * @return
     */
    private static JSONObject createTablesDataObject(){
        JSONObject tablesData = new JSONObject();
        JSONArray array = new JSONArray();
        tablesData.put(TableConstants.TABLES_KEY,array);
        return tablesData;
    }


    /**
     * 检查新建 table name 是否已经存在
     * @param tableName
     * @param tablesData
     * @return
     * @throws Exception
     */
    private static boolean checkTableNameExistence(String tableId,String tableName,JSONObject tablesData) throws Exception {
        if(StringUtils.isBlank(tableName) || tablesData == null){
            throw new Exception("Params invalid");
        }
        JSONObject tableJSONObject = JSONUtils.findCertainJSONNodesByValueFromArray(tablesData,TableConstants.TABLES_KEY,TableConstants.TABLE_NAME_KEY,tableName);
        if(tableJSONObject == null){
            return false;
        }else{
            if(StringUtils.isNotBlank(tableId) && tableId.equals(tableJSONObject.getString(TableConstants.TABLE_ID_KEY))){
                return false;
            }
            return true;
        }
    }

    /**
     * 检查表名是否存在
     * @param tableId
     * @param tableName
     * @return
     */
    public static String checkTableNameExistence(String tableId,String tableName){
        try {
            JSONObject tablesJSONObject = FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
            boolean existed = checkTableNameExistence(tableId,tableName,tablesJSONObject);
            return ok(existed ? "1" : "0");
        } catch (Exception e) {
            log.error(e.getMessage());
            return error();
        }
    }


    public static String checkTableNameExistence(String table){
        try {
            JSONObject json = JSONObject.parseObject(table);
            json = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen( json);
            String tableId = json.getString("table-id");
            String tableName = json.getString("table-name");
            return checkTableNameExistence(tableId,tableName);
        } catch (Exception e) {
            log.error(e.getMessage());
            return error();
        }
    }


    /**
     * 添加或者更新表数据，并返回 table id 列表
     * @param pageKey
     * @param tables
     * @return
     */
    public static String addOrUpdateTablesByPageKey(String pageKey,String objectId,String groupName,String tables){
        if(StringUtils.isBlank(pageKey)){
            return error("pagekey 不能为空");
        }
        if(StringUtils.isBlank(tables)){
            return error("tables 数据不能为空");
        }
        
        try {
            JSONObject tablesJSONObject;
            tablesJSONObject = FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
            if (tablesJSONObject == null) {
                tablesJSONObject = createTablesDataObject();
            }

            JSONArray tableArrayExisted = tablesJSONObject.getJSONArray(TableConstants.TABLES_KEY);
            ObjectOperation.updatePageKeyByGroupNameAndObjectId(groupName,objectId,pageKey);

            //需要根据pagekey 把原有的数据删除，然后重新写入
            JSONUtils.removeDataByKeyValueFromArray(tableArrayExisted,TableConstants.OBJECT_ID_KEY,objectId);

            JSONObject tableData  = JSONObject.parseObject(tables);
            tableData = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(tableData);
            //保存对象是否启用树结构
            Boolean isTree = tableData.getBoolean(TableConstants.IS_TREE);
            addObject(objectId,groupName, isTree);
            
            JSONArray tableArray = tableData.getJSONArray(TableConstants.DATA_KEY);
            tableArray = (JSONArray) JSONUtils.convertKeyToLowerCaseAndAddHyphen(tableArray);

            String tableIdString = IncrementOperation.getIncrementIndexByKeyWithoutWriteBackToFile("1", IncrementConstants.TABLE_INCREMENT_INDEX_KEY);
            log.info("New table id is : " + tableIdString);
            int tableId = Integer.valueOf(tableIdString);
            boolean tableIdChanged = false;
            for(Object obj : tableArray){
                if(!validateTableData((JSONObject)obj)){
                    return error("表设计数据校验不通过");
                }
                JSONObject tableJSONObject = (JSONObject)obj;
                tableJSONObject.put(TableConstants.OBJECT_ID_KEY,objectId);
                String tableName = tableJSONObject.getString(TableConstants.TABLE_NAME_KEY);
                if(StringUtils.isBlank(tableName)){
                    return error("表名不能为空");
                }
                if(tableJSONObject.containsKey(TableConstants.TABLE_ID_KEY)){
                    if(checkTableNameExistence(tableJSONObject.getString(TableConstants.TABLE_ID_KEY),tableName,tablesJSONObject)){
//                        return error("Table Name " + tableName + " exists");
                        return error("表名称 " + tableName + " 重复");
                    }
                }else{
                    if(checkTableNameExistence(null,tableName,tablesJSONObject)){
//                        return error("Table Name " + tableName + " exists");
                        return error("表名称 " + tableName + " 重复");
                    }
                }

                if(!tableJSONObject.containsKey(TableConstants.TABLE_ID_KEY) || StringUtils.isBlank(tableJSONObject.getString(TableConstants.TABLE_ID_KEY))) {
                    tableJSONObject.put(TableConstants.TABLE_ID_KEY, String.valueOf(tableId));
                    tableId ++;
                    tableIdChanged = true;
                }

                addOrUpdateTableFields(tableJSONObject,tableJSONObject.getString(TableConstants.TABLE_ID_KEY));
            }

            if(tableIdChanged) {
                tableId = tableId - 1;
                IncrementOperation.updateIncrementIndexByKey("1", IncrementConstants.TABLE_INCREMENT_INDEX_KEY, String.valueOf(tableId));
            }

            tableArrayExisted.addAll(tableArray);

            FileUtil.writeJSONObjectIntoFile(getTableJSONFilePath(),tablesJSONObject);
            return ok(JSONUtils.convertKeyToCamelStyle(tableArray));
        }catch (Exception e){
            log.error(e.getMessage());
            e.printStackTrace();
            return error();
        }
    }


    /**
     * 添加或者更新表字段数据
     * @param tableJSONObject
     * @param tableId
     */
    private static void addOrUpdateTableFields(JSONObject tableJSONObject,String tableId) throws Exception {
        JSONArray fieldArray = tableJSONObject.getJSONArray(TableConstants.FIELD_LIST_KEY);
        int fieldIncrementIndex = Integer.valueOf(IncrementOperation.getFieldIdByTableId(tableId));
        boolean fieldIdChanged = false;
        for(Object o : fieldArray){
            JSONObject obj = (JSONObject)o;
            if(!obj.containsKey(TableConstants.FIELD_ID_KEY) || StringUtils.isBlank(obj.getString(TableConstants.FIELD_ID_KEY))) {
                obj.put(TableConstants.FIELD_ID_KEY,String.valueOf(fieldIncrementIndex));
                fieldIncrementIndex += 1;
                fieldIdChanged = true;
            }
        }

        if(fieldIdChanged) {
            fieldIncrementIndex -= 1;
            IncrementOperation.addOrUpdateFieldIdByTableId(tableId, String.valueOf(fieldIncrementIndex));
        }
    }
    /**
     * 从业务角度检查校验表设计数据
     * @param tableJSONObject
     * @return
     */
    private static boolean validateTableData(JSONObject tableJSONObject){
        return true;
    }

    /**
     * 从业务角度检查校验字段数据
     * @param fieldData
     * @return
     */
    private static boolean validateFieldData(JSONObject fieldData){
        return true;
    }
    
    
    
    public static String getDefaultTableFields() {
        try {
            JSONObject tableData = FileUtil.readJSONObjectFromFile(getDefaultFieldsJSONFilePath());
            JSONArray array = JSONUtils.findJSONArrayByKey(tableData, "default-fields");
            if (array == null) {
                return noData();
            } else {
                return ok(JSONUtils.convertKeyToCamelStyle(tableData));
            }
        }catch (Exception e){
            log.error(e.getMessage());
            return error();
        }
    }
    
    
    
    private static String getDefaultFieldsJSONFilePath() throws Exception {
        return SystemConfigManagement.getJSONFilePathByFileName("default-fields");
    }
    
    
    /**
     * 
     * @return
     * @throws Exception 
     */
    public static String removeTablesByObjectId(String objectId) throws Exception{
    	if (StringUtils.isBlank(objectId)) {
            String errorMessage = "objectId 不能为空";
            throw new Exception(errorMessage);
        }
    	JSONObject tableData = FileUtil.readJSONObjectFromFile(getTableJSONFilePath());
    	JSONArray array = JSONUtils.findJSONArrayByKey(tableData, TableConstants.TABLES_KEY);
        if (array == null) {
            return noData();
        } else {
           JSONUtils.removeDataByKeyValueFromArray(array, ObjectConstants.OBJECT_ID_KEY, objectId);
           FileUtil.writeJSONObjectIntoFile(getTableJSONFilePath(),tableData); 
        }
    	return ok();
    }

    /**
     * 保存是否启用树节点
     * @param objectId
     * @param isTree
     * @throws Exception 
     */
    public static void addObject(String objectId,String groupName,Boolean isTree) throws Exception{
    	
    	JSONObject object = ObjectOperation.getObjectByObjectId(objectId);
    	object.put(TableConstants.IS_TREE, isTree);
    	ObjectOperation.addOrUpdateObject(groupName, object.toJSONString());
    }
    
    /**
     * 获取主表信息
     * @param arr
     * @return
     */
    public static JSONObject getMainTableInfo(JSONArray arr){
    	if(arr!=null && arr.size()>0){
    		for (Object object : arr) {
				JSONObject o = (JSONObject) object;
				Boolean isMainTable = o.getBoolean("is-main-table");
				if(isMainTable){
					return o;
				}
			}
    	}
    	return null;
    }
}
