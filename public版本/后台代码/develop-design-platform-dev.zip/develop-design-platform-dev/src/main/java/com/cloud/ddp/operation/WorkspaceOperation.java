package com.cloud.ddp.operation;

import com.cloud.ddp.system.SystemConfigManagement;
import com.cloud.ddp.util.FileUtil;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

public class WorkspaceOperation {
    public static int createWorkspace(String workspacePath) throws Exception{
        if(!StringUtils.isBlank(workspacePath)){
            try {
                SystemConfigManagement.setWorkspacePath(workspacePath);
            } catch (IOException e) {
                e.printStackTrace();
                throw new IOException("设置工作目录异常");
            }
        }else{
            workspacePath = SystemConfigManagement.getWorkspacePath();
        }

        FileUtil.createDir(workspacePath);
        return 0;
    }
}
