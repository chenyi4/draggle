package com.cloud.ddp.plugin;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.util.FileUtil;
import com.cloud.ddp.util.JsonXmlUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileDetector {
    private static final String PROPERTY_COLLECTION_CONFIG_FILE_PATH = "src\\main\\resources\\meta\\bizconfig\\property_collection.json";

    private static final String PROPERTY_COLLECTION_KEY = "property-collection";

    private static final String PAGE_NAME_KEY = "page-name";

    private static final String PROPERTY_OBJECT_LIST_KEY = "property-object-list";

    private static final String PROPERTY_OBJECT_KEY = "property-object";

    private static final String RELATED_FILE_TYPE_LIST_KEY = "related-file-type-list";

    private static final String FILE_TYPE_KEY = "file-type";

    public static List<String> detectFile(String pageName, String propertyObject) throws IOException {
        List<String> fileTypeList= new ArrayList<>();
        String configJson = FileUtil.readJsonFile(PROPERTY_COLLECTION_CONFIG_FILE_PATH);
        JSONObject jsonObject = JSONObject.parseObject(configJson);
        JSONArray jsonArray = jsonObject.getJSONArray(PROPERTY_COLLECTION_KEY);
        for(int i = 0; i < jsonArray.size(); i ++){
            JSONObject obj = jsonArray.getJSONObject(i);
            if(obj.containsKey(PAGE_NAME_KEY)){
                if(obj.getString(PAGE_NAME_KEY).equals(pageName)){
                    JSONArray propertyObjectList = obj.getJSONArray(PROPERTY_OBJECT_LIST_KEY);
                    if(propertyObjectList != null && propertyObjectList.size() > 0){
                        for(int j=0; j < propertyObjectList.size(); j ++){
                             JSONObject po = propertyObjectList.getJSONObject(j);
                             if(po.containsKey(PROPERTY_OBJECT_KEY)){
                                 String propertyObjectName = po.getString(PROPERTY_OBJECT_KEY);
                                 if(propertyObjectName.equals(propertyObject)){
                                     JSONArray fileTypeArray = po.getJSONArray(RELATED_FILE_TYPE_LIST_KEY);
                                     if(fileTypeArray != null && fileTypeArray.size() > 0){
                                         for(int k = 0; k < fileTypeArray.size(); k++){
                                             JSONObject fileType = fileTypeArray.getJSONObject(k);
                                             fileTypeList.add(fileType.getString(FILE_TYPE_KEY));
                                         }
                                         return fileTypeList;
                                     }
                                 }
                             }
                        }
                    }
                }
            }
        }
        return null;
    }
}
