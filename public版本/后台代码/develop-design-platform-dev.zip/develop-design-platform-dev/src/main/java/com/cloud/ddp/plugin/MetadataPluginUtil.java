package com.cloud.ddp.plugin;

import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.util.DataValidation;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.JsonXmlUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.plugin;
 * 描述：生成元数据文件
 * @author wenlu
 * @date 2020年3月11日下午1:17:59
 */
@Slf4j
public class MetadataPluginUtil extends ResultWrapper {
	
	
	public static String createMetaFileXML(String pageKey,String jsonStr){
		//校验json
		Boolean status = DataValidation.validateJson(jsonStr);
		
		//生成xml
		if(status){
			JSONObject obj = JSONObject.parseObject(jsonStr);
			
			//生成xmlFile
			String fileName = ConfigConstants.FILE_PATH.concat("/").concat(XmlConstants.FOLDER_NAME_ALLXMLFILES).concat("/").concat(pageKey).concat(".xml");
			try {
				JsonXmlUtils.jsonToPrettyXml(obj,fileName);
			} catch (Exception e) {
				log.error("生成table xml失败:"+e.getMessage());
				return error("生成xml失败");
			}
		}

		return ok("生成xml成功");   
	}
		

	//test
	public static void main(String[] args) {		
		//生成xml文件
		String json = JSONUtils.getJsonObjFromResource("json/metaData.json");
		System.out.println(createMetaFileXML("subWorkOrder", json));
		
		//反转成json文件
//		String xml = JsonXmlUtils.getJsonObjFromResource("xml/allXmlFiles/subWorkOrder.xml");
//        System.out.println(XmlJsonUtils.xml2Json(xml));
	}
	
}

