package com.cloud.ddp.plugin;

import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.util.DataValidation;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.JsonXmlUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.util;
 * 描述：按钮功能文件生成
 * @author wenlu
 * @date 2020年3月4日下午4:49:33
 */
@Slf4j
public class PushDownPluginUtil extends ResultWrapper{
	
	/**
	 * 创建功能按钮文件
	 * @param jsonStr
	 * @param pageKey
	 * @return
	 */
	public static String createOperateXml(String pageKey,String jsonStr){
		//校验json
		Boolean status = DataValidation.validateJson(jsonStr);
		
		//生成xml
		if(status){
			JSONObject obj = JSONObject.parseObject(jsonStr);
			String fileName = ConfigConstants.FILE_PATH.concat("/pushDown/").concat(pageKey).concat(".xml");
			
			try {
				JsonXmlUtils.jsonToPrettyXml(obj,fileName);
			} catch (Exception e) {
				log.error("生成pushDown xml失败:"+e.getMessage());
				return error("生成xml失败");
			}
		}
		return ok("生成xml成功");    
	}
	
	
	
	
	
	
	//test
	public static void main(String[] args) {		
		//生成xml文件
		String json = JSONUtils.getJsonObjFromResource("json/pushDown.json");
		System.out.println(createOperateXml("subWorkOrder", json));
		
//		//反转成json文件
//		String xml = JsonXmlUtils.getJsonObjFromResource("xml/button/subWorkOrder.xml");
//        System.out.println(XmlJsonUtils.xml2Json(xml));

	}
	
	
	
	
	
	
	
}
