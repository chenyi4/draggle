package com.cloud.ddp.system;

import com.cloud.ddp.constants.SystemConstants;
import com.cloud.ddp.util.PropertyUtil;

import java.io.IOException;

public class SystemConfigManagement {



    /**
     * 设置设计器工作目录
     * @param path
     * @return
     */
    public static int setWorkspacePath(String path) throws IOException {
        PropertyUtil.setProperty(SystemConstants.SYSTEM_WORKSPACE_KEY,path);
        return 0;
    }

    public static String getWorkspacePath() throws Exception {
        return (String) PropertyUtil.getProperty(SystemConstants.SYSTEM_WORKSPACE_KEY);
    }

    public static String getJSONFilePathByFileName(String jsonFileName) throws Exception {
        String workspacePath = SystemConfigManagement.getWorkspacePath();
        String incrementJsonFilePath = workspacePath.concat("/").concat(jsonFileName).concat(".json");
        return incrementJsonFilePath;
    }

    public static String getMetaFilePathByFileName(String metaFileName) throws Exception {
        String workspacePath = SystemConfigManagement.getWorkspacePath();
        String incrementJsonFilePath = workspacePath.concat("/../meta/").concat(metaFileName).concat(".json");
        return incrementJsonFilePath;
    }
}
