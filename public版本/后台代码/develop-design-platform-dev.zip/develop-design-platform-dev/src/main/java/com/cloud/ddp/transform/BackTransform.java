package com.cloud.ddp.transform;


import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.TableConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.operation.ObjectOperation;
import com.cloud.ddp.operation.TableOperation;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.JsonXmlUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.transform;
 * 描述：
 * @author wenlu
 * @date 2020年4月15日下午5:20:08
 */
@Slf4j
public class BackTransform extends ResultWrapper{
	
	/**
	 * 获取单个表转化为back功能文件
	 * @param objectId
	 * @return
	 */
	public static String transformJson(String objectId){
		String jsonStr = BaseOperation.findByNodeIdNoCovertKey(objectId, ConfigConstants.FILENAME_BACK, ConfigConstants.BACK_LIST, ObjectConstants.OBJECT_ID_KEY);
		if(StringUtils.isNoneBlank(jsonStr)){
			JSONObject json = JSONObject.parseObject(jsonStr).getJSONObject("data");
			if(json == null){
				return noData();
			}
			//查询对象数据
			JSONObject object = null;
			try {
				object = ObjectOperation.getObjectByObjectId(objectId);
			} catch (Exception e) {
				log.error("获取Object对象异常："+e.getMessage());
			}
			if(object == null){
				return noData();
			}
			String pageKey = object.getString("page-key");
			//组装json对象
			json = createNodeFun(json);
			log.info(json.toJSONString());


			//生成xml文件
			String fileName = ConfigConstants.FILE_PATH.concat("/").concat(XmlConstants.FOLDER_NAME_BACK).concat("/").concat(pageKey).concat(".xml");
			JsonXmlUtils.jsonToPrettyXml(json,fileName);
		}
		return ok("生成xml成功");
	}
	
	/**
	 * 创建根节点
	 * @return
	 */
	public static JSONObject createNodeFun(JSONObject json){
		//创建根节点
		JSONObject root = new JSONObject(true);
		
		try {

			JSONArray backList = json.getJSONArray("reference-list");
			JSONObject back = new JSONObject();
			for (Object object : backList) {				
				JSONObject backKey = new JSONObject(true);
				JSONObject temp = (JSONObject) object;
				//查找带回的backKey
				String refKey = temp.getString("ref-key");
				
			    //判断是否后台分页
			    backKey = createBackPage(temp.getBoolean("pagination-selected"),temp.getBoolean("multi-ref-selected"), backKey);
			    
			    //关联参数 
			    JSONArray associations = temp.getJSONArray("associate-params");
			    backKey = createAssociateParams(associations, backKey);
			    
			    //列表显示,默认显示的是所有已分配权限的字段
			    JSONArray displayFields = temp.getJSONArray("display-list");
			    backKey = createFieldsDisplay(displayFields, backKey);
			    
			    //普通引用
			    JSONObject normalRef = temp.getJSONObject("normal-ref");
			    backKey = createNormalRef(normalRef, backKey);
			    
			    //内联引用
			    JSONObject innerRef = temp.getJSONObject("inner-ref");
			    backKey = createInnerRef(innerRef, backKey);
			    
			    
			    back.put(refKey, backKey);
			    
			}
			root.put("Root", back);
			
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		
		return root;
	}

	/**
	 * 创建后台分页节点
	 * @param pagination
	 * @param root
	 * @return
	 */
	public static JSONObject createBackPage(Boolean pagination,Boolean multiRef,JSONObject root){
	   if(pagination != null && pagination){
	    	JSONObject backPage = new JSONObject();
	    	
	    	JSONObject properties = new JSONObject();
	    	if(multiRef){
	    		properties.put(XmlConstants.TYPE, "backPivotal");
	    	}else{
	    		properties.put(XmlConstants.TYPE, "back");
	    	}
	    	backPage.put(ConfigConstants.PROPERTIES_TAG, properties);
	    	
	    	root.put(XmlConstants.BACK_PAGE, backPage);
	   }
		return  root;
	}
	
	
	
	/**
	 * 创建关联参数 mainParam节点
	 * @param associations
	 * @param root
	 * @return
	 * @throws Exception 
	 */

	public static JSONObject createAssociateParams(JSONArray associations,JSONObject root) throws Exception{
		if(!CollectionUtils.isEmpty(associations)){
			JSONArray mainParams = new JSONArray();
			for (Object object : associations) {
				JSONObject o = (JSONObject) object;
				
				if(o.keySet().size()>0){
					JSONObject mainParam = new JSONObject(true);
					//关联参数ID
					JSONObject associateTable = TableOperation.findTableObjectByTableId(o.getString("table-id"));		
					//内联参数
					JSONObject associateField = TableOperation.findFieldObjectByFieldId(associateTable, o.getString("field-id"));
					mainParam.put("mainParam", associateField.getString("field-name"));
					
					mainParams.add(mainParam);

				}
			}
			
			root.put(ConfigConstants.SUB_NODE_LIST, mainParams);
		}
		return root;
	}
	
	/**
	 * 列表显示,默认显示的是所有已分配权限的字段
	 * @param displayFields
	 * @param root
	 * @return
	 * @throws Exception 
	 */
	public static JSONObject createFieldsDisplay(JSONArray displayFields,JSONObject root) throws Exception{
		 if(!CollectionUtils.isEmpty(displayFields)){
				JSONObject model = new JSONObject();
				String entityName = null;
				JSONObject table = null;
		    	JSONArray columns = new JSONArray();
		    	for (Object o : displayFields) {
					JSONObject oj = (JSONObject) o;
					if(entityName == null){
						table = TableOperation.findTableObjectByTableId(oj.getString("table-id"));
						if(table == null || StringUtils.isBlank(table.toJSONString())){
							log.error("表不存在");
						}
						entityName = CaseConversionUtils.getClassName(table.getString("table-name"));
					}
					
					JSONObject column = new JSONObject();
					JSONObject field = TableOperation.findFieldObjectByFieldId(table, oj.getString("field-id"));
					column.put(XmlConstants.COLUMN, field.getString("field-name"));
					columns.add(column);
				}
		    	
		    	JSONObject property =new JSONObject();
		    	property.put(XmlConstants.NAME, entityName);
		    	model.put(ConfigConstants.PROPERTIES_TAG, property);
		    	model.put(XmlConstants.MODEL, columns);
		    			    	
		    	root.put(XmlConstants.SOURCE_ENTITY, model);
		    }
		return root;
	}
	
	
	
	
	/**
	 * 创建普通引用
	 * @param normalRef
	 * @param root
	 * @return
	 * @throws Exception 
	 */
	public static JSONObject createNormalRef(JSONObject normalRef,JSONObject root) throws Exception{
		JSONArray fieldMappingList = normalRef.getJSONArray("field-mapping-list");
		
		if(!CollectionUtils.isEmpty(fieldMappingList)){
			
			JSONArray conBackFileds = new JSONArray();
			JSONArray fields  = new JSONArray();
			for (Object object : fieldMappingList) {
				JSONObject o = (JSONObject) object;
				
				JSONObject filedObj = new JSONObject();
				
				JSONObject filed = new JSONObject();
				
				JSONObject properties = new JSONObject();
				
				JSONObject table = TableOperation.findTableObjectByTableId(o.getString(TableConstants.TABLE_ID_KEY));
				JSONObject field = TableOperation.findFieldObjectByFieldId(table, o.getString(TableConstants.FIELD_ID_KEY));
				
				properties.put(XmlConstants.SOURCE_ENTITY, table.getString(TableConstants.TABLE_NAME_KEY));
				properties.put(XmlConstants.NAME, field.getString(TableConstants.FIELD_NAME));
				
				//target
				JSONObject targetTable = TableOperation.findTableObjectByTableId(o.getString("target-table-id"));
				JSONObject targetField = TableOperation.findFieldObjectByFieldId(targetTable, o.getString("target-field-id"));
				
				properties.put(XmlConstants.TARGET_ENTITY, targetTable.getString(TableConstants.TABLE_NAME_KEY));
				properties.put(XmlConstants.TARGET, targetField.getString(TableConstants.FIELD_NAME));

				
				filed.put(ConfigConstants.PROPERTIES_TAG, properties);
				filedObj.put(XmlConstants.FILED, filed);
				
				fields.add(filedObj);
			}
			conBackFileds.add(fields);
			root.put(XmlConstants.CON_BACK_FILED, conBackFileds);			
		}
		JSONObject complexAssociation = normalRef.getJSONObject("complex-association");
		JSONObject condition = normalRef.getJSONObject("condition");
		root.put(XmlConstants.SQL, complexAssociation.getString("value"));
		root.put(XmlConstants.WHERE, condition.getString("value"));
		
		return root;
	}
	
	
	/**
	 * 创建内联引用
	 * @param innerRef
	 * @param root
	 * @return
	 * @throws Exception 
	 */
	public static JSONObject createInnerRef(JSONObject innerRef,JSONObject root) throws Exception{
		JSONArray fieldMappingList = innerRef.getJSONArray("field-mapping-list");
		
		JSONObject backList = new JSONObject(true);
		
		
		//backList param节点
		JSONObject param = new JSONObject();
		JSONObject paramProPerties = new JSONObject();
		//内联表单
		JSONObject refTable = TableOperation.findTableObjectByTableId(innerRef.getString("ref-form"));		
		//内联参数
		JSONObject refField = TableOperation.findFieldObjectByFieldId(refTable, innerRef.getString("ref-param"));
		
		if(refTable == null){
			return root;
		}

		paramProPerties.put(XmlConstants.TYPE, refField.getString("type"));//long
		param.put(ConfigConstants.PROPERTIES_TAG, paramProPerties);
		param.put("value", CaseConversionUtils.replaceUnderLineAndUpperCaseNoFirst(refTable.getString("table-name")).concat(".").concat(refField.getString("field-name")));
		
		backList.put(XmlConstants.PARAM, param);

		//backList BackListFiled节点
		if(!CollectionUtils.isEmpty(fieldMappingList)){
			
			JSONArray BackListFiled = new JSONArray();
			for (Object object : fieldMappingList) {
				JSONObject o = (JSONObject) object;
				
				JSONObject backField = new JSONObject();
				JSONObject filed = new JSONObject();
				
				JSONObject properties = new JSONObject();
				
				JSONObject table = TableOperation.findTableObjectByTableId(o.getString(TableConstants.TABLE_ID_KEY));
				JSONObject field = TableOperation.findFieldObjectByFieldId(table, o.getString(TableConstants.FIELD_ID_KEY));

				//查询sourceEntity
				properties.put(XmlConstants.SOURCE_ENTITY, table.getString(TableConstants.TABLE_NAME_KEY));
				properties.put(XmlConstants.NAME, field.getString(TableConstants.FIELD_NAME));
				
				//target
				JSONObject targetTable = TableOperation.findTableObjectByTableId(o.getString("target-table-id"));
				JSONObject targetField = TableOperation.findFieldObjectByFieldId(targetTable, o.getString("target-field-id"));
				
				properties.put(XmlConstants.TARGET_ENTITY, targetTable.getString(TableConstants.TABLE_NAME_KEY));
				properties.put(XmlConstants.TARGET, targetField.getString(TableConstants.FIELD_NAME));
				
				backField.put(ConfigConstants.PROPERTIES_TAG, properties);
				filed.put(XmlConstants.FILED, backField);

				BackListFiled.add(filed);
			}
			
			backList.put(XmlConstants.SQL, innerRef.getString("condition"));
			
			backList.put(XmlConstants.BACK_LIST_FILED, BackListFiled);	
		}
		
		root.put(XmlConstants.BACK_LIST, backList);

		return root;
	}
	
	
	
	
	public static String transformAll(){
		String jsonStr = null;
		try {
			jsonStr = BaseOperation.getNodeList("back", ConfigConstants.BACK_LIST);
		    JSONObject json = JSONObject.parseObject(jsonStr);
		    JSONArray arr = json.getJSONArray("data");
		    for (Object object : arr) {
				JSONObject obj = (JSONObject) object;
				if(obj != null && obj.keySet().size()>0){
					transformJson(obj.getString("object-id"));
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonStr;
	}
	
	
	public static void main(String[] args) {
		BackTransform.transformJson("1");
	}
}

