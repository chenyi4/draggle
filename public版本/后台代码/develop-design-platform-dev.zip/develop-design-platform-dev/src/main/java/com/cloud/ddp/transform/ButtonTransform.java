package com.cloud.ddp.transform;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.TableConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.operation.ObjectOperation;
import com.cloud.ddp.operation.TableOperation;
import com.cloud.ddp.plugin.ButtonPluginUtil;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.transform;
 * 描述：
 * @author wenlu
 * @date 2020年4月1日下午3:00:08
 */
@Slf4j
public class ButtonTransform extends ResultWrapper{
	
	/**
	 * 获取单个表转化为button功能文件
	 * @param tableId
	 * @return
	 */
	public static String transformJson(String objectId){
		String jsonStr = BaseOperation.findByNodeIdNoCovertKey(objectId, ConfigConstants.FILENAME_BUTTON, ConfigConstants.BUTTON_LIST, ObjectConstants.OBJECT_ID_KEY);
		if(StringUtils.isNoneBlank(jsonStr)){
			JSONObject json = JSONObject.parseObject(jsonStr).getJSONObject("data");
			if(json == null){
				return noData();
			}
			
			//查询对象数据
			JSONObject object = null;
			try {
				object = ObjectOperation.getObjectByObjectId(objectId);
			} catch (Exception e) {
				log.error("获取Object对象异常："+e.getMessage());
			}
			if(object == null){
				return noData();
			}
			
			String pageKey = object.getString("page-key");
			//组装json对象
			json = createNodeFun(json);
			log.info(json.toJSONString());
			
			//生成xml文件
			ButtonPluginUtil.createOperateXml(pageKey, json.toJSONString());

		}
		return ok("生成xml成功"); 
	}
	
	/**
	 * 创建功能节点
	 * @return
	 */
	public static JSONObject createNodeFun(JSONObject json){
		JSONObject root = new JSONObject();
		//创建根节点
		JSONObject funs = new JSONObject();
		funs.put(XmlConstants.STATUS, json.getJSONObject("status"));

		JSONArray funList = json.getJSONArray("fun");
		if(funList !=null && funList.size()>0){
			JSONArray buttons = new JSONArray();
			for (Object object : funList) {
				JSONObject fun = (JSONObject) object;
				JSONObject xml = new JSONObject();
				if(createButtonXml(fun)!=null){
					xml.put(XmlConstants.FUN, createButtonXml(fun));
					buttons.add(xml);
				}
			}
			funs.put(ConfigConstants.SUB_NODE_LIST, buttons);
		}
		root.put(XmlConstants.FUNS, funs);
//		root.put("searchOrder", new JSONObject());
		return root;
	}
	
	
	public static JSONObject createButtonXml(JSONObject object){
		JSONObject data = new JSONObject();
		JSONObject dataNode = object.getJSONObject("data");
		//判断是否特殊按钮如下推选单，上查下查
		if(dataNode == null){
			return null;
		}
		
		data.put(XmlConstants.DATA, dataNode.getString("data"));
		
		JSONObject validate = object.getJSONObject("validate");
		data.put(XmlConstants.VALIDATE, validate.getString("data"));
		
		JSONObject dataSet = object.getJSONObject("data-set");
		data.put(XmlConstants.DATASET, dataSet.getString("data"));
		
		JSONObject properties = object.getJSONObject("properties");
		properties.remove(XmlConstants.NAME);
		data.put(ConfigConstants.PROPERTIES_TAG, properties);
		
		JSONArray dataWriteBacks = object.getJSONArray("data-write-back");
		if(CollectionUtils.isEmpty(dataWriteBacks)){
			return data;
		}
		data.put(ConfigConstants.SUB_NODE_LIST, createDataWriteBack(dataWriteBacks));
		

		return data;
	}
	
	
	/**
	 * 反写方式
	 * @param funList
	 * @return
	 */
	public static JSONArray createDataWriteBack(JSONArray dataWriteBacks){
		JSONArray datas = new JSONArray();
			
		JSONObject dataWriteBack = new JSONObject(true);
		for (Object o : dataWriteBacks) {
			JSONObject writeBackMode = (JSONObject) o;
			String  type = writeBackMode.getString("type");
			//按对象方式
			if(type.equals("object-mode")){
				try {
					dataWriteBack.put(XmlConstants.TABLE, createObjectMode(writeBackMode));
				} catch (Exception e) {
					log.error("按对象方式反写失败"+e.getMessage());
				}
			}else if(type.equals("pulgin-mode")){
			  //按插件方式
				try {
					dataWriteBack.put(XmlConstants.EXECUTION, createPluginMode(writeBackMode));
				} catch (Exception e) {
					log.error("按插件方式反写失败"+e.getMessage());
				}
			}else{
			   //按脚本方式
				try {
					dataWriteBack.put(XmlConstants.EXECUTIONSQL, createSqlMode(writeBackMode));
				} catch (Exception e) {
					log.error("按脚本方式反写失败"+e.getMessage());
				}
			}
			datas.add(dataWriteBack);
		}
		return datas;
		
	}
	
	/**
	 * 对象模式反写
	 * @param writeBackMode
	 * @return
	 * @throws Exception 
	 */
	public static JSONArray createObjectMode(JSONObject objectMode) throws Exception{
		JSONArray tables = new JSONArray();
		
		JSONObject table = new JSONObject(true);

		JSONArray columns  = objectMode.getJSONArray("columns");
		JSONObject properties = new JSONObject();
		JSONObject sourceTable = TableOperation.findTableObjectByTableId(objectMode.getString("table-id"));
		if(sourceTable == null){
			return null;
		}
		
		properties.put(XmlConstants.TARGETTABLE, sourceTable.getString(TableConstants.TABLE_NAME_KEY));
		properties.put(XmlConstants.OPERATE, objectMode.getString("operate-type"));
		
		JSONArray datas = new JSONArray();
		for (Object object : columns) {
			JSONObject column = (JSONObject) object;
			JSONObject sourceField = TableOperation.findFieldObjectByFieldId(sourceTable, column.getString("field-id"));
			JSONObject targetField = TableOperation.findFieldObjectByTableIdAndFieldId(column.getString("target-table-id"), column.getString("target-field-id"));
			
			String type = column.getString("type");
			//判断是否关联关系
			if(type.equals("join")){ 
				properties.put(XmlConstants.TARGETKEY, targetField.getString(TableConstants.FIELD_NAME));
				properties.put(XmlConstants.SOURCEKEY, sourceField.getString(TableConstants.FIELD_NAME));
				
			}else{
				JSONObject o = new JSONObject();
				JSONObject columnObject = new JSONObject();
				
				JSONObject columnProperties = new JSONObject();
				
				columnProperties.put(XmlConstants.NAME, sourceField.getString(TableConstants.FIELD_NAME));
				columnProperties.put(XmlConstants.TYPE, column.getString("type"));
				columnProperties.put("source", targetField.getString(TableConstants.TABLE_NAME_KEY));
				
				columnObject.put(ConfigConstants.PROPERTIES_TAG, columnProperties);
				o.put(XmlConstants.COLUMN, columnObject);
				
				datas.add(o);
			}
		}
		table.put(ConfigConstants.PROPERTIES_TAG, properties);
		table.put(ConfigConstants.SUB_NODE_LIST, datas);
		tables.add(table);
		
		
		return tables;
	}
	
	
	/**
	 * 插件方式   
	 * @param pluginMode
	 * @return
	 * @throws Exception 
	 */
	public static JSONArray createPluginMode(JSONObject pluginMode) throws Exception{
		JSONArray executions = new JSONArray();
		JSONObject execution = new JSONObject();
//			JSONObject targetTable = TableOperation.findTableObjectByTableId(pluginMode.getString("table-id"));
		execution.put(XmlConstants.LOCATION, pluginMode.getString("location"));
		execution.put(XmlConstants.METHOD,  pluginMode.getString("method-name"));
		
		JSONObject parameter = new JSONObject();
		
		JSONObject properties = new JSONObject();  
		properties.put(XmlConstants.BASICTYPE, "");
		
		parameter.put(ConfigConstants.PROPERTIES_TAG, properties);
		
		JSONObject paramterIn = pluginMode.getJSONObject("parameter-in");
		parameter.put("value", paramterIn.getString(paramterIn.getString("value")));
		
		execution.put(XmlConstants.PARAMETER, parameter);
		
		executions.add(execution); //
		
		return executions;
	}
	
	
	/**
	 * sql方式
	 * @param sqlMode
	 * @return
	 * @throws Exception 
	 */
	public static JSONArray createSqlMode(JSONObject sqlMode) throws Exception{
		JSONArray executionSqls = new JSONArray();
		
		JSONObject executionSql = new JSONObject();

		JSONArray parameterIn = sqlMode.getJSONArray("parameter-in");
		
		JSONArray paramters = new JSONArray();
		for (Object object : parameterIn) {
			JSONObject in = (JSONObject) object;
			
			JSONObject node = new JSONObject();
			JSONObject parameter = new JSONObject();
			JSONObject properties = new JSONObject();
			properties.put(XmlConstants.BASICTYPE, in.getString("basictype"));
			parameter.put(ConfigConstants.PROPERTIES_TAG, properties);
			
			JSONObject field = TableOperation.findFieldObjectByTableIdAndFieldId(in.getString("ref-table-id"), in.getString("ref-field-id"));
			parameter.put("value", field.getString(TableConstants.FIELD_NAME));
			
			node.put(XmlConstants.PARAMETER, parameter);
			paramters.add(node);
			
		}
		
		executionSql.put(ConfigConstants.SUB_NODE_LIST, paramters);
		//校验值   
		if(StringUtils.isNotBlank(sqlMode.getString("count-num"))){
			executionSql.put(XmlConstants.COUNTNUM, sqlMode.getString("count-num"));
		}else if(StringUtils.isNotBlank(sqlMode.getString("count-sql"))){
		 //校验sql
			executionSql.put(XmlConstants.COUNTSQL, sqlMode.getString("count-sql"));
		}
		executionSql.put(XmlConstants.SQL, sqlMode.getString("sql"));
		
		executionSqls.add(executionSql);
		
		
		
		return executionSqls;
	}
	
	
	
	/**
	 * 批量获取表节点转化为button 功能文件
	 * @return
	 */
	public static  String transformAll(){
		String jsonStr = null;
		try {
			jsonStr = BaseOperation.getNodeListNoCovertKey("button", ConfigConstants.BUTTON_LIST);
		    JSONObject json = JSONObject.parseObject(jsonStr);
		    JSONArray arr = json.getJSONArray("data");
		    for (Object object : arr) {
				JSONObject obj = (JSONObject) object;
				if(obj != null && obj.keySet().size()>0){
					transformJson(obj.getString(ConfigConstants.PRIMARY_KEY_ID));
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonStr;
	}
	
	
	public static void main(String[] args) {
		transformJson("107");
	}
}

