package com.cloud.ddp.transform;


import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.util.DataValidation;
import com.cloud.ddp.util.JsonXmlUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.transform;
 * 描述：
 * @author wenlu
 * @date 2020年4月15日上午11:20:08
 */
@Slf4j
public class DefaultDictionaryTransform extends ResultWrapper{
	

	/**
	 * 创建默认字典xml
	 * @return
	 */
	public static String createDictionaryXml(String jsonStr){
		//校验json
		Boolean status = DataValidation.validateJson(jsonStr);
		
		//生成xml
		if(status){
			JSONObject obj = JSONObject.parseObject(jsonStr);
			String fileName = ConfigConstants.DEFAULT_DICTIONARY;
			//生成xml文件
			String filePath = ConfigConstants.FILE_PATH.concat("/").concat(XmlConstants.FOLDER_NAME_DICTIONARY).concat("/").concat(fileName).concat(".xml");
			try {
				JsonXmlUtils.jsonToPrettyXml(obj,filePath);
			} catch (Exception e) {
				log.error("生成dictionary xml:"+e.getMessage());
				error("生成xml失败");
			}
		}
		return ok("生成xml成功");
	}
	
	
	
	/**
	 * 生成默认字典的Xml
	 * @param objectId
	 * @return
	 */
	public static String createDictionaryXml(){
		String jsonStr = BaseOperation.getNodeListNoCovertKey("dictionary", ConfigConstants.DICTIONARY_LIST);
		if(StringUtils.isNoneBlank(jsonStr)){
			JSONArray arr = JSONObject.parseObject(jsonStr).getJSONArray("data");
			if(CollectionUtils.isEmpty(arr)){
				return noData();
			}
			
			//组装json对象
			JSONObject object = createJsonNode(arr);
			log.info(object.toJSONString());

			String fileName = ConfigConstants.DEFAULT_DICTIONARY;
			//生成xml文件
			String filePath = ConfigConstants.FILE_PATH.concat("/").concat(XmlConstants.FOLDER_NAME_DICTIONARY).concat("/").concat(fileName).concat(".xml");
			JsonXmlUtils.jsonToPrettyXml(object,filePath);
		}
		return ok("生成xml成功");
	}
	
	
    /**
     * 创建xml文件所需的json文件
     * @param arr
     * @return
     */
	public static JSONObject createJsonNode(JSONArray arr){
		JSONObject root = new JSONObject();
		JSONObject group = new JSONObject();
		JSONArray Dictionarys = new JSONArray();
		
		if(!CollectionUtils.isEmpty(arr)){
			for (Object object : arr) {
				JSONObject temp = (JSONObject) object;
				JSONObject properties = new JSONObject();
				properties.put(XmlConstants.GROUP_NAME, temp.getString("group-name"));
				properties.put(XmlConstants.GROUP_NO, temp.getString("group-no"));
				properties.put(XmlConstants.I18N_KEY, temp.getString("i18n-key"));
				
				JSONObject dictionaryGroup = new JSONObject();
				dictionaryGroup.put(ConfigConstants.PROPERTIES_TAG, properties);
				
				JSONArray dictionryKeys = temp.getJSONArray("dictionry-keys");
				dictionaryGroup.put(XmlConstants.DICTIONRY, dictionryKeys);
				
				Dictionarys.add(dictionaryGroup);
			}
			
			group.put(XmlConstants.DICTIONARY_GROUP, Dictionarys);
			root.put(XmlConstants.DICTIONARYS, group);
		}		
		return root;
	}
	
	//test
	public static void main(String[] args) {	
		createDictionaryXml();
		
	}
		
	
}

