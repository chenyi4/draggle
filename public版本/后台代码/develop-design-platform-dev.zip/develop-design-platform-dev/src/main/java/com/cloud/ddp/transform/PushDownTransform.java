package com.cloud.ddp.transform;

import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.operation.ObjectOperation;
import com.cloud.ddp.operation.TableOperation;
import com.cloud.ddp.plugin.PushDownPluginUtil;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.transform;
 * 描述：
 * @author wenlu
 * @date 2020年4月7日下午5:20:08
 */
@Slf4j
public class PushDownTransform extends ResultWrapper{
	
	/**
	 * 获取单个表转化为pushDown功能文件
	 * @param tableId
	 * @return
	 */
	public static String transformJson(String objectId){
		String jsonStr = BaseOperation.findByNodeIdNoCovertKey(objectId, "pushDown", ConfigConstants.PUSH_LIST, "object-id");
		if(StringUtils.isNoneBlank(jsonStr)){
			JSONObject result = JSONObject.parseObject(jsonStr);
			JSONObject json = result.getJSONObject("data");
			
			if(json == null){
				log.info("生成pushDown XML 失败 ! ObjectId:"+objectId+", "+result.getString("message"));
				return result.getString("message");
			}
			
			//查询object
			JSONObject object = null;
			try {
				object = ObjectOperation.getObjectByObjectId(json.getString(ObjectConstants.OBJECT_ID_KEY));
			} catch (Exception e) {
				log.error("获取Object对象异常："+e.getMessage());
			}
			if(object == null){
				return noData("object 不存在");
			}
			String pageKey = object.getString("page-key");
			
			//组装json对象
			json = createNodeFun(json);
			log.info(json.toJSONString());
			
			//生成xml文件
			PushDownPluginUtil.createOperateXml(pageKey, json.toJSONString());
		}
		return ok("生成xml成功");
	}
	
	/**
	 * 创建根节点 
	 * @return
	 */
	public static JSONObject createNodeFun(JSONObject json){
		//创建根节点
		JSONObject root = new JSONObject();
		
		JSONObject ret = new JSONObject();
		
		JSONArray pushObjes = new JSONArray();
		
		JSONArray pushList = json.getJSONArray("push");
		for (Object object : pushList) {
			JSONObject temp = (JSONObject) object;
			String pushType = temp.getString("push-type");
			
			JSONObject pushNode = new JSONObject(true); 
			JSONObject pushKeyObj = new JSONObject(true);

			//下推或选单标识
			String pushKey = temp.getString("key");
			//选单
			if(StringUtils.endsWith(pushType, ConfigConstants.TEXT_ONE)){
				//页面显示字段配置
				JSONObject souceEntity = createSourceEntity(temp);
				if(souceEntity != null){
					pushNode.put(XmlConstants.SOURCE_ENTITY, souceEntity);
				}
				
			}
			
			//迁移配置
			JSONArray dataRef = temp.getJSONArray("data-ref");
			
			JSONArray resultMaps = new JSONArray();
			for (Object o : dataRef) {
				JSONObject data = (JSONObject) o;
				String paramType = data.getString("param-type");
				//按参数方式
				if(StringUtils.equals(paramType, ConfigConstants.TEXT_ZERO)){
					pushNode = createParamNode(data,pushNode);
				//按脚本方式
				}else if(StringUtils.equals(paramType, ConfigConstants.TEXT_ONE)){
					pushNode = createSqlNode(data,pushNode,resultMaps);
				//按插件方式
				}else{
					pushNode = createPluginNode(data,pushNode,resultMaps);
				}
				
			}
			if(!CollectionUtils.isEmpty(resultMaps)){
				JSONArray res = pushNode.getJSONArray(ConfigConstants.SUB_NODE_LIST);
				pushNode.remove(ConfigConstants.SUB_NODE_LIST);
				
				JSONObject subNode = new JSONObject();
				subNode.put(ConfigConstants.SUB_NODE_LIST, res);
				pushNode.put(XmlConstants.PUSH, subNode);
			}
			
			pushKeyObj.put(pushKey, pushNode);
			pushObjes.add(pushKeyObj);
		}
		
		
		ret.put(ConfigConstants.SUB_NODE_LIST, pushObjes);
		root.put("Root", ret);
		return root;
	}
	
	/**
	 * 选单页面展示字段
	 * @param data
	 * @return
	 */
	public static JSONObject createSourceEntity(JSONObject data){
		JSONArray selectOrderDisplay = data.getJSONArray("select-order-diplay");
		if(CollectionUtils.isEmpty(selectOrderDisplay)){
			return null;
		}
		JSONObject sourceEntity = new JSONObject();
		
		for (Object object : selectOrderDisplay) {
			JSONObject o = (JSONObject) object;
			
			JSONObject model = new JSONObject();
			
			String tableId = o.getString("table-id");
			
			if(StringUtils.isBlank(tableId)){
				continue;
			}
			
			JSONObject table = null;
			try {
				table = TableOperation.findTableObjectByTableId(tableId);
			} catch (Exception e) {
				log.error("获取表数据异常："+e.getMessage());
			}
			
			JSONObject properties = new JSONObject();
			properties.put(XmlConstants.NAME, CaseConversionUtils.getClassName(table.getString("table-name")));
			
			model.put(ConfigConstants.PROPERTIES_TAG, properties);
			
			JSONArray columns = o.getJSONArray("columns");
			
			JSONArray cs = new JSONArray();
			for (Object column : columns) {
				JSONObject c = (JSONObject) column;
				
				JSONObject columnNode = new JSONObject();
				JSONObject field = null;
				try {
					field = TableOperation.findFieldObjectByFieldId(table, c.getString("field-id"));
				} catch (Exception e) {
					log.error("获取字段异常"+e.getMessage());
				}
				if(field == null){
					continue;
				}
				columnNode.put(XmlConstants.COLUMN, field.getString("field-name"));
				
				cs.add(columnNode);
			}
			
			model.put(ConfigConstants.SUB_NODE_LIST, cs);			
			
			sourceEntity.put(XmlConstants.MODEL, model);
		}		
		return sourceEntity;
	}
	
	
	
	
	
	
	/**
	 * 按参数方式创建节点
	 * @param oldJSONObj
	 * @param newJSONObj
	 * @return
	 */
	public static JSONObject createParamNode(JSONObject oldJSONObj,JSONObject newJSONObj){
		//目标单据
		JSONObject pageKey = new JSONObject();
		JSONObject properties = new JSONObject();
		properties.put(XmlConstants.NAME, oldJSONObj.getString("target-object-key"));
		pageKey.put(ConfigConstants.PROPERTIES_TAG, properties);
		newJSONObj.put(XmlConstants.PAGE_KEY, pageKey);
		
		JSONArray pushFields = oldJSONObj.getJSONArray("push-fields");
		JSONArray fields = new JSONArray();
		for (Object object : pushFields) {
			JSONObject temp = (JSONObject) object;
			JSONObject field = new JSONObject();
			JSONObject propertie = new JSONObject();
			String sourceTableId = temp.getString("source-table-id");
			String sourceFieldId = temp.getString("source-field-id");
			if(StringUtils.isBlank(sourceTableId) || StringUtils.isBlank(sourceFieldId) ){
				continue;
			}
			JSONObject sourceTable = null;
			try {
				sourceTable = TableOperation.findTableObjectByTableId(sourceTableId);
				if(sourceTable == null){
					continue;
				}
			} catch (Exception e) {
				log.error("find source table error!"+e.getMessage());
			}
			
			JSONObject sourceField = null;
			try {
				sourceField = TableOperation.findFieldObjectByFieldId(sourceTable, sourceFieldId);
				if(sourceField == null){
					continue;
				}
			} catch (Exception e) {
				log.error("find source field  error!"+e.getMessage());
			}
			
			String targetTableId = temp.getString("target-table-id");
			String targetFieldId = temp.getString("target-field-id");
			if(StringUtils.isBlank(targetTableId) || StringUtils.isBlank(targetFieldId) ){
				continue;
			}
			JSONObject targetTable = null;
			try {
				targetTable = TableOperation.findTableObjectByTableId(targetTableId);
				if(targetTable == null){
					continue;
				}
			} catch (Exception e) {
				log.error("find target table error!"+e.getMessage());
			}
			
			JSONObject targetField = null;
			try {
				targetField = TableOperation.findFieldObjectByFieldId(targetTable, targetFieldId);
				if(targetField == null){
					continue;
				}
			} catch (Exception e) {
				log.error("find target field  error!"+e.getMessage());
			}						
			propertie.put(XmlConstants.SOURCE_ENTITY, CaseConversionUtils.getClassName(sourceTable.getString("table-name")));
			propertie.put(XmlConstants.NAME, sourceField.getString("field-name"));
			propertie.put(XmlConstants.TARGET_ENTITY, CaseConversionUtils.getClassName(targetTable.getString("table-name")));
			propertie.put(XmlConstants.TARGET, targetField.getString("field-name"));
			field.put(ConfigConstants.PROPERTIES_TAG, propertie);
			fields.add(field);
		}
		JSONObject pushFild = new JSONObject();
		pushFild.put(XmlConstants.FILED, fields);
		newJSONObj.put(XmlConstants.PUSH_FILED, pushFild);
		
		String where = oldJSONObj.getString("where");
		if(StringUtils.isNotBlank(where)){
			newJSONObj.put(XmlConstants.WHERE, where);
		}
		return newJSONObj;
	}
	
	
	/**
	 * 按脚本方式创建节点
	 * @param oldJSONObj
	 * @param newJSONObj
	 * @return
	 */
	public static JSONObject createSqlNode(JSONObject oldJSONObj,JSONObject newJSONObj,JSONArray resultMaps){		
		JSONObject resultMap = new JSONObject();
		
		String targetTableId = oldJSONObj.getString("target-table-id");
		if(StringUtils.isBlank(targetTableId)){
			return null;
		}
		JSONObject targetTable = null;
		try {
			targetTable = TableOperation.findTableObjectByTableId(targetTableId);
		} catch (Exception e) {
			log.error("获取目标表单失败！targetTableId:"+targetTableId+","+e.getMessage());
		}
		if(targetTable == null){
			return null;
		}
		JSONObject properties = new JSONObject();
		properties.put("model", CaseConversionUtils.getClassName(targetTable.getString("table-name")));

		
		resultMap.put(XmlConstants.SQL, oldJSONObj.getString("sql"));
		
		resultMap.put(ConfigConstants.PROPERTIES_TAG, properties);
		
		JSONObject sql = new JSONObject();
		sql.put(XmlConstants.RESULTMAP, resultMap);
		
		resultMaps.add(sql);
		
		newJSONObj.put(ConfigConstants.SUB_NODE_LIST, resultMaps);
		
		return newJSONObj;
	}
	
	
	
	

	/**
	 * 按插件方式创建节点
	 * @param oldJSONObj
	 * @param newJSONObj
	 * @return
	 */
	public static JSONObject createPluginNode(JSONObject oldJSONObj,JSONObject newJSONObj,JSONArray resultMaps){
		
		JSONObject resultMap = new JSONObject();
		String targetTableId = oldJSONObj.getString("target-table-id");
		if(StringUtils.isBlank(targetTableId)){
			return null;
		}
		JSONObject targetTable = null;
		try {
			targetTable = TableOperation.findTableObjectByTableId(targetTableId);
		} catch (Exception e) {
			log.error("获取目标表单失败！targetTableId:"+targetTableId+","+e.getMessage());
		}
		if(targetTable == null){
			return null;
		}
		
		JSONObject properties = new JSONObject();
		properties.put("model", CaseConversionUtils.getClassName(targetTable.getString("table-name")));
		
		JSONObject execution = new JSONObject();
		execution.put(XmlConstants.LOCATION, oldJSONObj.getString("location"));
		execution.put(XmlConstants.METHOD, oldJSONObj.getString("method-name"));
		execution.put(XmlConstants.PARAMETER, oldJSONObj.getString("param-field"));
		JSONObject property = new JSONObject();
		property.put(XmlConstants.BASICTYPE, oldJSONObj.getString("field-type"));
		
		resultMap.put(XmlConstants.EXECUTION, execution);
		
		resultMap.put(ConfigConstants.PROPERTIES_TAG, properties);
		
		JSONObject plugin = new JSONObject();
		plugin.put(XmlConstants.RESULTMAP, resultMap);
		
		resultMaps.add(plugin);
		
		newJSONObj.put(ConfigConstants.SUB_NODE_LIST, resultMaps);
		
		return newJSONObj;
	}
	
	
	
	/**
	 * 批量获取表节点转化为button 功能文件
	 * @return
	 */
	public String transformAll(){
		String jsonStr = null;
		try {
			jsonStr = BaseOperation.getNodeList("pushDown", ConfigConstants.PUSH_LIST);
		    JSONObject json = JSONObject.parseObject(jsonStr);
		    JSONArray arr = json.getJSONArray("data");
		    for (Object object : arr) {
				JSONObject obj = (JSONObject) object;
				if(obj != null && obj.keySet().size()>0){
					transformJson(obj.getString("object-id"));
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonStr;
	}
	
	
	public static void main(String[] args) {
		PushDownTransform button = new PushDownTransform();
		button.transformJson("1");
//		button.transformAll();
	}
}

