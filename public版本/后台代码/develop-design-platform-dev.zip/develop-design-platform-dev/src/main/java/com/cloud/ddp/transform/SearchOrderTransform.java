package com.cloud.ddp.transform;


import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.operation.BaseOperation;
import com.cloud.ddp.operation.ObjectOperation;
import com.cloud.ddp.operation.TableOperation;
import com.cloud.ddp.plugin.SearchOrderPluginUtil;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.transform;
 * 描述：table json 转换
 * @author wenlu
 * @date 2020年3月31日下午1:53:01
 */
@Slf4j
public class SearchOrderTransform extends ResultWrapper{
	
	
	/**
	 * 获取单个表转化为pushDown功能文件
	 * @param tableId
	 * @return
	 */
	public static String transformJson(String nodeId){
		String jsonStr = BaseOperation.findByNodeIdNoCovertKey(nodeId, "searchOrder", ConfigConstants.SEARCH_ORDER_LIST, ObjectConstants.OBJECT_ID_KEY);
		if(StringUtils.isNoneBlank(jsonStr)){
			JSONObject json = JSONObject.parseObject(jsonStr).getJSONObject("data");
			if(json == null){
				return noData();
			}
			//生成xml文件
			JSONObject object = null;
			try {
				object = ObjectOperation.getObjectByObjectId(json.getString(ObjectConstants.OBJECT_ID_KEY));
			} catch (Exception e) {
				log.error("获取Object对象异常："+e.getMessage());
			}
			if(object == null){
				return noData("object 不存在");
			}
			String pageKey = object.getString("page-key");
			//组装json对象
			json = createNodeFun(json);
			System.out.println(json.toJSONString());
			//生成xml文件
			SearchOrderPluginUtil.createFileXML(pageKey, json.toJSONString());

		}
		return ok("生成xml成功");
	}
	
	
	/**
	 * 创建根节点
	 * @return
	 */
	public static JSONObject createNodeFun(JSONObject json){
		//创建根节点
		JSONObject root = new JSONObject();		
		
		JSONObject searchOrder = new JSONObject();
		
		JSONArray searchList = json.getJSONArray("search-list");
		for (Object object : searchList) {
			JSONObject temp = (JSONObject) object;
			//上查或下查标识
			String searchKey = temp.getString("key");
			
			JSONObject searchNode = new JSONObject();
			//关联查询
			JSONArray searchAssociations = temp.getJSONArray("search-associations");
			
			JSONObject model = jsonToAssociations(searchAssociations);
			searchNode.put(XmlConstants.MODEL, model);
			
			searchOrder.put(searchKey, searchNode);
			
		}
		
		root.put(XmlConstants.SEARCHORDER, searchOrder);
		
		return root;
	}
	
	
	/**
	 * JSON 格式转换
	 * @param list
	 * @return
	 */
	public static JSONObject jsonToAssociations(JSONArray list){
		JSONObject level  = new JSONObject();
		try {
			level = createAssociations(list,null,null);
		} catch (Exception e) {
 			log.error("创建表关联失败"+e.getMessage());
		}
		return level;
		
	}
	
	
	public static JSONObject createAssociations(JSONArray list,String rootNodeId,JSONObject root) throws Exception{
		//找根节点
		for (Object object : list) {
			JSONObject o = (JSONObject) object;
			String refRableId = o.getString("ref-table-id");
			String tableId = o.getString("table-id");
			if(StringUtils.isBlank(refRableId) ||  refRableId.equals(tableId)){
				root = createModel(o);
				rootNodeId = o.getString("table-id");
			}else{
				root.put(XmlConstants.MODEL, createModel(o));
			}
			
			
		}
		
		if(root == null){
			return root;
		}			
		return root;
		
	}
	
	
	public static JSONObject  subToJSon(JSONObject object,String tableId) throws Exception{
		JSONObject model = new JSONObject();
		JSONObject o = (JSONObject) object;
		String refRableId = o.getString("ref-table-id");
		//获取table info
		
		JSONObject table = TableOperation.findTableObjectByTableId(o.getString("table-id"));

		JSONObject properyties = new JSONObject();
		JSONObject key = TableOperation.findFieldObjectByFieldId(table, o.getString("key-id"));
		if(StringUtils.isNotBlank(refRableId)){
			JSONObject refTable = TableOperation.findTableObjectByTableId(refRableId);
			JSONObject Field = TableOperation.findFieldObjectByFieldId(refTable, o.getString("ref-key-id"));
			properyties.put(XmlConstants.UPKEY, Field.getString("field-name"));
		}
		
		properyties.put(XmlConstants.NAME, CaseConversionUtils.getClassName(table.getString("table-name")));
		properyties.put(XmlConstants.KEY, key.getString("field-name"));
		

		model.put(ConfigConstants.PROPERTIES_TAG, properyties);

		
		JSONArray columns = new JSONArray();
		for (Object of : object.getJSONArray("columns")) {
			JSONObject field = (JSONObject) of;
			JSONObject column = new JSONObject();
			column.put("column", field.getString("field-name"));
			columns.add(column);
		}
		model.put(ConfigConstants.SUB_NODE_LIST, columns);
		
		return model;
	}
	
	/**
	 * 创建model
	 * @param model
	 * @return
	 * @throws Exception
	 */
	public static JSONObject createModel(JSONObject model) throws Exception{
		JSONObject level = new JSONObject();
		
		JSONObject properyties = new JSONObject();
		
		JSONObject table = TableOperation.findTableObjectByTableId(model.getString("table-id"));
		if(table == null){
			return level;
		}
		
		if(StringUtils.isNotBlank(model.getString("ref-table-id"))){
			JSONObject refTable = TableOperation.findTableObjectByTableId(model.getString("ref-table-id"));
			JSONObject Field = TableOperation.findFieldObjectByFieldId(refTable, model.getString("ref-key-id"));
			properyties.put(XmlConstants.UPKEY, Field!=null?Field.getString("field-name"):null);
		}
		properyties.put(XmlConstants.NAME, CaseConversionUtils.getClassName(table.getString("table-name")));
		properyties.put(XmlConstants.KEY, model.getString("key-id"));
		

		level.put(ConfigConstants.PROPERTIES_TAG, properyties);
		
		
		JSONArray levels = new JSONArray();
		JSONArray columns = model.getJSONArray("columns");
		for (Object column : columns) {
			JSONObject sub = new JSONObject();
			JSONObject col = (JSONObject) column;
			//获取字段
			JSONObject field = TableOperation.findFieldObjectByFieldId(table, col.getString("field-id"));
			if(field == null){
				continue;
			}
			sub.put(XmlConstants.COLUMN, field.getString("field-name"));
			levels.add(sub);
		}
		level.put(ConfigConstants.SUB_NODE_LIST,levels);
		
		
		return level;
	}
	
	
	
	
	
	/**
	 * 批量获取节点转化为上查下查文件
	 * @return
	 */
	public static String transformAll(){
		String jsonStr = null;
		try {
			jsonStr = BaseOperation.getNodeListNoCovertKey("searchOrder", ConfigConstants.SEARCH_ORDER_LIST);
		    JSONObject json = JSONObject.parseObject(jsonStr);
		    JSONArray arr = json.getJSONArray("data");
		    for (Object object : arr) {
				JSONObject obj = (JSONObject) object;
				if(obj != null && obj.keySet().size()>0){
					transformJson(obj.getString(ObjectConstants.OBJECT_ID_KEY));
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonStr;

	}
	
	
	
	public static void main(String[] args) {
		System.out.println(SearchOrderTransform.transformJson("1"));
	}
}

