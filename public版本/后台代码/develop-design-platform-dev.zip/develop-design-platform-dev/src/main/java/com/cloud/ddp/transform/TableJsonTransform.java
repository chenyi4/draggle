package com.cloud.ddp.transform;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;
import com.cloud.ddp.constants.ObjectConstants;
import com.cloud.ddp.constants.XmlConstants;
import com.cloud.ddp.operation.ObjectOperation;
import com.cloud.ddp.operation.TableOperation;
import com.cloud.ddp.plugin.MetadataPluginUtil;
import com.cloud.ddp.util.CaseConversionUtils;
import com.cloud.ddp.util.JSONUtils;
import com.cloud.ddp.util.ResultWrapper;

import lombok.extern.slf4j.Slf4j;

/**
 * package com.cloud.ddp.transform;
 * 描述：table json 转换
 * @author wenlu
 * @date 2020年3月31日下午1:53:01
 */
@Slf4j
public class TableJsonTransform extends ResultWrapper{
	
	/**
	 * 获取单个表转化为元数据表文件
	 * @param tableId
	 * @return
	 */
	public static String transformJson(String tableId){
		JSONObject retObj = null;
		String jsonStr = TableOperation.findTableByTableId(tableId);
		JSONObject objectJSON = JSONObject.parseObject(jsonStr);
		objectJSON = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(objectJSON);
		if(StringUtils.isNoneBlank(jsonStr)){
			JSONObject json = objectJSON.getJSONObject("data");
			//创建表关联关系
			retObj = createTableRaleations(json);
			//创建表字段
			retObj = createColumns(json, retObj);
			//生成xml文件
			String fileName = json.getString("table-name");
			if(StringUtils.isBlank(fileName)){
				log.error("table-name不存在，无法创建文件!");
				return error("生成xml文件失败!");
			}
			System.out.println(retObj.toJSONString());
			MetadataPluginUtil.createMetaFileXML(CaseConversionUtils.getClassName(fileName), retObj.toJSONString());

		}
		return ok("生成xml成功");
	}
	
	
	/**
	 * 批量获取表节点转化为表文件
	 * @return
	 */
	public static String transformAll(){
		String jsonStr = null;
		try {
			jsonStr = TableOperation.getAllTableList();
		    JSONObject json = JSONObject.parseObject(jsonStr);
		    json = (JSONObject)JSONUtils.convertKeyToLowerCaseAndAddHyphen(json);

		    JSONArray arr = json.getJSONArray("data");
		    for (Object object : arr) {
				JSONObject obj = (JSONObject) object;
				if(obj != null && obj.keySet().size()>0){
					transformJson(obj.getString("table-id"));
				}
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonStr;
	}
	
	/**
	 * 创建表关联
	 * @param json
	 * @param associations
	 * @return
	 * "foreignKey":{
            "generalKey":{
                "properties":{
                    "columnId":"main_id",
                    "generalModel":"ProductionRetreatMain",
                    "generalName":"ProductionRetreatMain"
                }
            },
            "detailOneKey":[
                {
                    "properties":{
                        "columnId":"generate_group_id",
                        "detailModel":"BMaterial",
                        "detailName":"bMaterial"
                    }
                },
                {
                    "properties":{
                        "columnId":"planner_id",
                        "detailModel":"BaseStaff",
                        "detailName":"baseStaff"
                    }
                }
            ]
        }
	 */
	public static JSONObject createTableRaleations(JSONObject json){
		JSONObject retObj = new JSONObject(true);
		JSONObject resultMap = new JSONObject();
		
		JSONObject foreignKey = new JSONObject();
		JSONArray associations = json.getJSONArray(ConfigConstants.TABLE_ASSOCIATION);		
		if(associations!=null && associations.size()>0){
			for (Object object : associations) {
				JSONObject obj = (JSONObject) object;
				//验证table-id是否存在
				String tableId = obj.getString("table-id");
				if(StringUtils.isBlank(tableId)){
					log.info("没有表关联关系");
					continue;
				}
				foreignKey = createDetailKeys(obj, json.getString("table-id"), foreignKey);
			}
		}		
		resultMap.put(XmlConstants.FOREIGN_KEY, foreignKey);
		retObj.put(XmlConstants.RESULTMAP, resultMap);
		
		return retObj;
	}
	
	
	/**
	 * 创建表关联关系
	 * @param object
	 * @param sourceTableId
	 * @return
	 */
	public static JSONObject createDetailKeys(JSONObject object,String sourceTableId,JSONObject foreignKey){
		String tableId = object.getString("table-id");
		if(StringUtils.isBlank(tableId)){
			return foreignKey;
		}
		
		JSONArray details = new JSONArray();
		JSONObject table = null;
		try {
			table = TableOperation.findTableObjectByTableId(tableId);
		} catch (Exception e) {
			log.error("table不存在，table id :"+tableId);
		}
		
		/* 0 一对一   1 一对多*/
		String relationType = object.getString("relation-type");
		JSONObject field = null;
		try {
			field = TableOperation.findFieldObjectByFieldId(table, object.getString("field-id"));
		} catch (Exception e1) {
			log.error("关联参数对象不存在");
		}

		JSONObject refTable = null;
		try {
			refTable = TableOperation.findTableObjectByTableId(object.getString("ref-table-id"));
		} catch (Exception e) {
			log.error("关联表不存在");
		}
		Boolean isMainTable = table.getBooleanValue("is-main-table");
		if(isMainTable && sourceTableId.equals(tableId)){

		  	JSONObject detailKey = new JSONObject();
			JSONObject detailProperties = new JSONObject();
			detailProperties.put(XmlConstants.COLUMN_ID, field.getString("field-name"));
			detailProperties.put(XmlConstants.DETAIL_MODEL, CaseConversionUtils.getClassName(refTable.getString("table-name")));
			detailKey.put(ConfigConstants.PROPERTIES_TAG, detailProperties);
			foreignKey.put(XmlConstants.DETAIL_KEY, detailKey);
		  	
		  	//创建一对一关系
		  	if(relationType.equals(ConfigConstants.TEXT_ZERO)){
		  		JSONObject detailOneToOneKeys = new JSONObject();
				JSONObject detailOneToOneKey = new JSONObject();
				JSONObject properties = new JSONObject();
				properties.put(XmlConstants.COLUMN_ID, field.getString("field-name"));
				properties.put(XmlConstants.DETAIL_MODEL, CaseConversionUtils.getClassName(refTable.getString("table-name")));
				detailOneToOneKey.put(ConfigConstants.PROPERTIES_TAG, properties);
				detailOneToOneKeys.put(XmlConstants.DETAIL_ONE_TO_ONE_KEY, detailOneToOneKey);
				details.add(detailOneToOneKeys);
			}
		  	 
		}else{
			JSONObject generalKey = new JSONObject();
			JSONObject generalProperties = new JSONObject();
			generalProperties.put(XmlConstants.COLUMN_ID, field.getString("field-name"));
			generalProperties.put(XmlConstants.DETAIL_MODEL, CaseConversionUtils.getClassName(refTable.getString("table-name")));
			generalKey.put(ConfigConstants.PROPERTIES_TAG, generalProperties);
			foreignKey.put(XmlConstants.DETAIL_KEY, generalKey);

			if(relationType.equals(ConfigConstants.TEXT_ZERO)){
				JSONObject generalOneToOneDetail = new JSONObject();
				JSONObject generalOneToOneKey = new JSONObject();
				JSONObject properties = new JSONObject();
				properties.put(XmlConstants.COLUMN_ID, field.getString("field-name"));
				properties.put(XmlConstants.DETAIL_MODEL, CaseConversionUtils.getClassName(refTable.getString("table-name")));
				generalOneToOneKey.put(ConfigConstants.PROPERTIES_TAG, properties);
				generalOneToOneDetail.put(XmlConstants.GENERAL_ONE_TO_ONE_KEY, generalOneToOneKey);
				details.add(generalOneToOneDetail);
			}
		}
		
		//创建一对多关系detailOneKey
		if(relationType.equals(ConfigConstants.TEXT_ONE)){
			JSONObject detailOneKeys = new JSONObject();
			JSONObject detailOneKey = new JSONObject();
			JSONObject properties = new JSONObject();
			properties.put(XmlConstants.COLUMN_ID, field.getString("field-name"));
			properties.put(XmlConstants.DETAIL_MODEL, CaseConversionUtils.getClassName(refTable.getString("table-name")));
			detailOneKey.put(ConfigConstants.PROPERTIES_TAG, properties);
			detailOneKeys.put(XmlConstants.DETAIL_ONE_KEY, detailOneKey);
			details.add(detailOneKeys);
		}
		
		foreignKey.put(ConfigConstants.SUB_NODE_LIST, details);
		return foreignKey;
	}
	
	
	
	
	/**
	 * 创建表字段
	 * @param json
	 * @return
	 * "column":[
            {
                "properties":{
                    "column":"id",
                    "jdbcType":"bigInt",
                    "property":"id",
                    "is_detail":"",
                    "type":"",
                    "length":"",
                    "fomart":"",
                    "default_value":"",
                    "is_required":"y",
                    "is_permission_need":"y",
                    "bussniess_type":"1"
                }
            },
            {
                "properties":{
                    "column":"name",
                    "jdbcType":"varchar(50)",
                    "property":"name",
                    "is_detail":"",
                    "type":"",
                    "length":"",
                    "fomart":"",
                    "default_value":"",
                    "is_required":"y",
                    "is_permission_need":"y",
                    "bussniess_type":"1"
                }
            }
        ]
	 */
	public static JSONObject createColumns(JSONObject json,JSONObject retObj){
		//获取字段列表
		JSONArray filedList = json.getJSONArray(ConfigConstants.FIELD_LIST);
		if(filedList != null && filedList.size()>0){
			JSONArray columns = new JSONArray();
			for (Object object : filedList) {
				JSONObject properties = new JSONObject(true);
				JSONObject obj = (JSONObject) object;
				JSONObject property = new JSONObject(true);
				properties.put(XmlConstants.COLUMN, obj.getString("field-name"));
				String jdbcType = obj.getString("type");
				String length = obj.getString("length");
				Boolean primary = obj.getBoolean("primary");
				if(primary!=null && primary){
					properties.put(XmlConstants.PRIMARY_KEY, "Y");
				}
				
				if(StringUtils.isNotBlank(jdbcType)&& jdbcType.contains("varchar")){
					if(StringUtils.isNotBlank(length)){
						properties.put(XmlConstants.JDBC_TYPE, jdbcType.concat("(").concat(length).concat(")"));
					}else{
						properties.put(XmlConstants.JDBC_TYPE, jdbcType.concat("(50)"));
					}
					
				}else{
					properties.put(XmlConstants.JDBC_TYPE, obj.getString("type"));
				}
				properties.put(XmlConstants.PROPERTY, obj.getString("name"));
				properties.put(XmlConstants.IS_DETAIL, ConfigConstants.VALUE_N);
				properties.put(XmlConstants.TYPE, obj.getString("type"));
				properties.put(XmlConstants.LENGTH, obj.getString("length"));
				properties.put(XmlConstants.FORMAT, null);//待修改
				properties.put(XmlConstants.DEFAULT_VALUE, obj.getString("default"));
				properties.put(XmlConstants.TAB_NAME, obj.getString("title"));
				properties.put(XmlConstants.TAB_NUM, obj.getString("position"));
				properties.put(XmlConstants.IS_REQUIRED, covertBooleanToYOrN(obj.getBoolean("requeired")));
				properties.put(XmlConstants.IS_PERMISSION_NEED, covertBooleanToYOrN(obj.getBoolean("permission")));
				property.put(ConfigConstants.PROPERTIES_TAG, properties);
				columns.add(property);
			}
			JSONObject resultMap = retObj.getJSONObject("resultMap");
			resultMap.put(XmlConstants.COLUMN, columns);
			
			//
			JSONObject properties = new JSONObject();
			properties.put(XmlConstants.TABLE_NAME,json.getString("table-name"));
			JSONObject object = null;
			try {
				object = ObjectOperation.getObjectByObjectId(json.getString(ObjectConstants.OBJECT_ID_KEY));
			} catch (Exception e) {
				log.error("获取Object对象异常");
			}
			JSONObject group = ObjectOperation.getServerNameByObjectId(object.getString(ObjectConstants.OBJECT_ID_KEY));
			String serverName = null;
			if(group!=null){
				serverName = group.getString(ObjectConstants.GROUP_NAME);
			}
			properties.put(XmlConstants.PAGE_KEY_WITH_LINE, object.getString("page-key"));
			properties.put(XmlConstants.PAGE_KEY_CH, object.getString("object-name"));
			properties.put(XmlConstants.SERVER_NAME, serverName);
			resultMap.put(ConfigConstants.PROPERTIES_TAG, properties);
			retObj.put(XmlConstants.RESULTMAP, resultMap);
		}

		return retObj;
		
	}
	
	
	/**
	 * 将boolean值转化为y,n
	 * @param value
	 * @return
	 */
	public static String covertBooleanToYOrN(Boolean value){
		value = value!= null? value:false;
		return value == true?ConfigConstants.VALUE_Y: ConfigConstants.VALUE_N;
	}
	
	
	
	public static void main(String[] args) {
		TableJsonTransform.transformJson("42");
		
	}
}

