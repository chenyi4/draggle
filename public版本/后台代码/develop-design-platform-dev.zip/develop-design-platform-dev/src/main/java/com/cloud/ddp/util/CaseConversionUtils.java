package com.cloud.ddp.util;


import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;
//import org.springframework.util.StringUtils;

/**
 * 实体名转化
 * @author 
 *
 */
public class CaseConversionUtils {
	
	/**
	 * 首字母转小写
	 * @param s
	 * @return
	 */
    public static String toLowerCaseFirstOne(String s){
        if(Character.isLowerCase(s.charAt(0))){
        	return s;
        }else{
        	return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0))).append(s.substring(1)).toString();
        }
    }
    
   /**
    * 首字母转大写
    * @param s
    * @return
    */
    public static String toUpperCaseFirstOne(String s){
        if(Character.isUpperCase(s.charAt(0))){
            return s;
        }else{
            return (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
        }
    }
	
	/**
	 * 把数据库表名解析为实体类文件名
	 * @param cn
	 * @return 
	 */
	public static String getClassName(String cn) {
		String className = new  String();
		String[] cns = cn.split("_");
		for(String cna :cns){
			className = className + toUpperCaseFirstOne(cna);
		}
		return className;
	}
	
	/**
	 * 根据驼峰命名法则将字符串中下划线转下一个字母转大写并去掉下划线。
	 * @param str
	 * @return
	 */
	public static String replaceUnderLineAndUpperCase(String str) {
        StringBuffer sb = new StringBuffer();
        sb.append(str);
        int count = sb.indexOf("_");
        int num;
        char ss;
        char ia;
        while (count != 0) {
            num = sb.indexOf("_", count);
            count = num + 1;
            if (num != -1) {
                ss = sb.charAt(count);
                ia = (char) (ss - 32);
                sb.replace(count, count + 1, ia + "");
            }
        }
        String result = sb.toString().replaceAll("_", "");
        return StringUtils.capitalize(result);
    }
	    
 	/**
 	 * 将字符串中大写字母转化为小写字母并拼接下划线。
 	 * @param str
 	 * @return
 	 */
    public static String replaceUpperCaseAndUnderLine(String str) {
    	StringBuffer sb = new StringBuffer();
    	if(str!=null)
    	{
    		char c;
    		for(int i=0;i<str.length();i++){
    			c = str.charAt(i);
    			if(Character.isUpperCase(c)){
    				if(i==0)
    				{
    					sb.append(Character.toLowerCase(c));
    				}else
    				{
    					sb.append("_"+Character.toLowerCase(c));
    				}    				
    			}else
    			{
    				sb.append(c);
    			}    			
    		}
    	}
    	String result = sb.toString();
		return result;
    }

    /**
     * 将字符串中大写字母转化为小写字母并拼接下划线。
     * @param str
     * @return
     */
    public static String replaceUpperCaseAndHyphen(String str) {
        StringBuffer sb = new StringBuffer();
        if(str!=null)
        {
            char c;
            for(int i=0;i<str.length();i++){
                c = str.charAt(i);
                if(Character.isUpperCase(c)){
                    if(i==0)
                    {
                        sb.append(Character.toLowerCase(c));
                    }else
                    {
                        sb.append("-"+Character.toLowerCase(c));
                    }
                }else
                {
                    sb.append(c);
                }
            }
        }
        String result = sb.toString();
        return result;
    }
	
    /**
     * 将字符串中非首个下划线转化为大写字母。
     * @param str
     * @return
     */
    public static String replaceUnderLineAndUpperCaseNoFirst(String str) {
		StringBuffer sb = new StringBuffer();
        sb.append(str);
        int count = sb.indexOf("_");
        int num;
        char ss;
        char ia;
        while (count != 0) {
            num = sb.indexOf("_", count);
            count = num + 1;
            if (num != -1) {
                ss = sb.charAt(count);
                ia = (char) (ss - 32);
                sb.replace(count, count + 1, String.valueOf(ia));
            }
        }
        String result = sb.toString().replaceAll("_", "");
        return result;
    }
    
    /**
     * 去掉字符串中的下划线
     * @param str
     * @return
     */
    public static String replaceUnderLine(String str) {
        StringBuffer sb = new StringBuffer();
        sb.append(str);
        int count = sb.indexOf("_");
        int num;
        char ss;
        char ia;
        while (count != 0) {
            num = sb.indexOf("_", count);
            count = num + 1;
            if (num != -1) {
                ss = sb.charAt(count);
                ia = (char) (ss - 32);
                sb.replace(count, count + 1, ia + "");
            }
        }
        String result = sb.toString().replaceAll("_", "");
        return result;
    }


    public static String convertLowerCaseAndHyphenToUpperCase(String target){
        target = toUpperCaseFirstOne(target);
        StringBuffer sb = new StringBuffer(target);
        int count = sb.indexOf("-");
        int num;
        char ss;
        char ia;
        while (count != 0) {
            num = sb.indexOf("-", count);
            count = num + 1;
            if (num != -1) {
                ss = sb.charAt(count);
                ia = (char) (ss - 32);
                sb.replace(count, count + 1, String.valueOf(ia));
            }
        }
        String result = sb.toString().replaceAll("-", "");
        return result;
    }

    public static String convertUpperCaseToLowerCaseAndHyphen(String target){
        target = toLowerCaseFirstOne(target);
        StringBuffer sb = new StringBuffer(target);
        int index = 0;
        int size = sb.length();
        List<Integer> indexList = new ArrayList<>();
        for(int i=0;i<size;i++){
            char upperCaseLetter = sb.charAt(i);
            if(Character.isUpperCase(upperCaseLetter)){
                index = i;
                char lowerCaseLetter = (char)(upperCaseLetter + 32);
                sb.replace(index,index+1,String.valueOf(lowerCaseLetter));
                indexList.add(i);
            }
        }
        int count = 0;
        for(Integer idx : indexList){
            sb.insert(idx.intValue()+count,'-');
            count ++;
        }

        return sb.toString();
    }
    
    /**
     * 将某个key 转化为驼峰法并大写
     * @param object
     * @param key
     * @return
     */
    public static JSONObject covertLowerCaseAndToUpperKey(JSONObject object,String key){
    	if(object.containsKey(key)){
    		object.put(CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(key), object.get(key));
    		object.remove(key);
    	}
    	return object;
    }
    
   
}
