package com.cloud.ddp.util;


import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSONObject;

/**
 * 校验数据合法性与一致性
 */
public class DataValidation {

    public static boolean validateJson(String inputJSONString){
    	if(StringUtils.isEmpty(inputJSONString) ){
            return false;
        }
    	try {
			JSONObject.parseObject(inputJSONString);
			return true;
		} catch (Exception e) {
			return false;
		}
    }

    /**
     * 校验提交数据与原数据是否一致
     * @param inputJSONString
     * @param originalJSONString
     * @return
     * @throws Exception
     */
    public static boolean validateData(String inputJSONString, String originalJSONString)throws Exception{
        if(StringUtils.isEmpty(inputJSONString) || StringUtils.isEmpty(originalJSONString)){
            throw new Exception("参数为空");
        }
        String inputMD5Hex = DigestUtils.md5Hex(inputJSONString);
        String originalMD5Hex = DigestUtils.md5Hex(originalJSONString);
        if(inputMD5Hex.equals(originalMD5Hex)){
            return true;
        }
        return false;
    }
    
    
    /**
     * 校验原数据中key值是否存在
     * @param inputStrKey
     * @param inputJson
     * @return
     * @throws Exception
     */
    public static boolean validateKey(String inputStrKey,JSONObject inputJson){
    	try {
			if(inputJson == null){
				throw new Exception("JSON 为空");
			}
			if(!inputJson.containsKey(inputStrKey)){
				throw new Exception("格式错误，key不存在");
			}
			if(StringUtils.isNotBlank(inputJson.getString(inputStrKey))){
				return true;
			}
		} catch (Exception e) {
			return false;
		}
    	return false;
    }
}
