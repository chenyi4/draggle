package com.cloud.ddp.util;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

/**
 * @className： DateUtil
 * @description：TODO （时间公共类）
 * @version： v1.0
 * @time： 2018/12/18 10:02
 * @author：qwer
 */
public class DateUtil extends DateUtils {

	private static String[] parsePatterns = { "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm:ss:sss",
			"yyyy-MM-dd HH:mm", "yyyy-MM", "yyyy", "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM",
			"yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm", "yyyy.MM" };

	public static String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		return sdf.format(new Date());
	}

	public static String getDateTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(new Date());
	}

	public static String getDate(Date date, String pattern) {
		if (StringUtils.isBlank(pattern)) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(date);
	}

	public static String getWeekStartDate(Date date, String pattern) {
		if (StringUtils.isBlank(pattern)) {
			return null;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Calendar cd = Calendar.getInstance();
		cd.setTime(date);

		int weekOfMonth = cd.get(Calendar.WEEK_OF_MONTH);
		int dayOfWeek = cd.get(Calendar.DAY_OF_WEEK);
		// 如果i_week_day =1 的话
		int iWeekDay = cd.get(Calendar.DAY_OF_WEEK); 
		// 实际上是周日												
		int weekDay = 0;
		// dayOfWeek+1 就是星期几（星期日 为 1）
		if (iWeekDay == 1) { 
			weekDay = (weekOfMonth - 1) * 7 + dayOfWeek + 1;
		} else {
			weekDay = 7 - iWeekDay + 1 + (weekOfMonth - 1) * 7 + dayOfWeek + 1;
		}
		cd.set(Calendar.DATE, weekDay);

		cd.set(Calendar.DAY_OF_WEEK, 2);
		return sdf.format(cd.getTime());
	}

	public static String getMonthStartDate(Date date, String pattern) {
		if (StringUtils.isBlank(pattern)) {
			return null;
		}
		Calendar cd = Calendar.getInstance();
		cd.setTime(date);
		cd.set(Calendar.DAY_OF_MONTH, 1);
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(cd.getTime());
	}

	public static Date parseDate(Object str) {
		if (str == null) {
			return null;
		}
		try {
			return parseDate(str.toString(), parsePatterns);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * 得到两个时间相差多少秒
	 * @param beginStr
	 * @param endStr
	 * @return
	 */
	public static String getTimeWithTwoDate(String beginStr, String endStr) {

		try {
			Date date1 = DateUtil.parseDate(beginStr);
			Date date2 = DateUtil.parseDate(endStr);
			long countTime = ((date2.getTime() - date1.getTime()) / 1000);
			return String.valueOf(countTime);
		} catch (Exception e) {
			return null;
		}
	}

	public static void main(String[] args) {
		/*
		 * System.out.println(getDate(new Date(), "yyyy-MM-dd"));
		 * System.out.println(getWeekStartDate(new Date(), "yyyy-MM-dd"));
		 * System.out.println(getMonthStartDate(new Date(), "yyyy-MM-dd"));
		 * System.out.println(getDate(new Date("2018-12-23"), "yyyy-MM-dd"));
		 * System.out.println(getWeekStartDate(new Date("2018-12-23"),
		 * "yyyy-MM-dd")); System.out.println(getMonthStartDate(new
		 * Date("2018-12-23"), "yyyy-MM-dd")); System.out.println(getDate(new
		 * Date(), "yyMMddHHmmSSsss"));
		 */

		String serviceStartTime = "2019-07-16 15:55:27";
		String serviceEndTime = "2019-07-16 16:55:27";
		Date date1 = DateUtil.parseDate(serviceStartTime);
		Date date2 = DateUtil.parseDate(serviceEndTime);
		long l = date2.getTime() - date1.getTime();
		System.out.println(String.valueOf(l / 1000));
	}
}
