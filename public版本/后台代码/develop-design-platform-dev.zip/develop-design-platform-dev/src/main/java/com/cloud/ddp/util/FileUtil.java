package com.cloud.ddp.util;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.cloud.ddp.system.SystemConfigManagement;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;

import java.io.*;


@Slf4j
public class FileUtil {

    /**
     * 将文件保存到本地
     *
     * @param path
     * @return
     */
    public static String saveFile(String path) {
        try {
            File targetFile = new File(path);
            if (targetFile.exists()) {
                return path;
            }

            if (!targetFile.getParentFile().exists()) {
                targetFile.getParentFile().mkdirs();
            }

            return path;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 删除本地文件
     *
     * @param pathname
     * @return
     */
    public static boolean deleteFile(String pathname) {
        File file = new File(pathname);
        if (file.exists()) {
            boolean flag = file.delete();

            if (flag) {
                File[] files = file.getParentFile().listFiles();
                if (files == null || files.length == 0) {
                    file.getParentFile().delete();
                }
            }

            return flag;
        }

        return false;
    }

    public static int createDir(String path)throws IOException{
        File file = new File(path);
        if(file.exists()){
            if(file.isDirectory()){
                FileUtils.deleteDirectory(file);
            }else{
                file.deleteOnExit();
            }
        }
        file.mkdir();
        return 0;
    }

    public static void createParentDirRecursively(String filePath){
        File file = new File(filePath);
        createParentDirRecursively(file);
    }

    public static void createParentDirRecursively(File file){
        File parentDir = file.getParentFile();
        if(!parentDir.exists()){
            createParentDirRecursively(parentDir);
            parentDir.mkdir();
        }
    }


    public static void deleteFileRecursively(String filePath){
        File file = new File(filePath);
        deleteFileRecursively(file);
    }

    public static void deleteFileRecursively(File file){
        if(!file.exists()){
            return;
        }
        if(file.isFile()){
            file.delete();
            log.info("删除文件成功");
        }
        if(file.isDirectory()){
            File[] files = file.listFiles();
            for(File f : files){
                deleteFileRecursively(f);
            }
        }
        log.info("文件夹已清空");
    }

	/**
	 * 根据pageKey读取对应的原数据文件
	 * @param pageKey
	 * @return
	 * @throws IOException
	 */
    public static String readJsonFileByPageKey(String pageKey)throws IOException{
    	String filePath = "";
    	String fileName = filePath.concat("/").concat(pageKey).concat(".json");
    	String jsonData = readJsonFile(fileName);
    	return jsonData;
	}

	/**
	 * 读取json文件，返回json串
	 * @param fileName
	 * @return
	 */
	public static String readJsonFile(String fileName) throws IOException{
        File file = new File(fileName);
        if(!file.exists()){
            throw new IOException("File " + fileName + " dose not exist!");
        }
        String jsonStr = FileUtils.readFileToString(file, "UTF-8");
        return jsonStr;

	}


    /**
     * 读取json文件，返回json串
     * @param file
     * @return
     */
    public static String readJsonFile(File file) throws IOException{
        if(!file.exists()){
            throw new IOException("File " + file.getAbsolutePath() + " dose not exist!");
        }
        String jsonStr = FileUtils.readFileToString(file, "UTF-8");
        return jsonStr;

    }

    public static JSONObject readJSONObjectFromFile(String JsonFilePath) throws Exception {
        JSONObject jsonObject = JSONUtils.parseJSONString(FileUtil.readJsonFile(JsonFilePath));
        return jsonObject;
    }

    public static JSONObject readJSONObjectFromFile(File JsonFile) throws Exception {
        JSONObject jsonObject = JSONUtils.parseJSONString(FileUtil.readJsonFile(JsonFile));
        return jsonObject;
    }

    public static JSONObject readJSONObjectByFileName(String fileName) throws Exception {
        String filePath = SystemConfigManagement.getJSONFilePathByFileName(fileName);
        return readJSONObjectFromFile(filePath);
    }

    public static void writeJSONObjectIntoFile(String JsonFilePath,JSONObject jsonObject) throws IOException {
        String content = JSON.toJSONString(jsonObject, SerializerFeature.PrettyFormat, SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteDateUseDateFormat);
        FileUtils.write(new File(JsonFilePath),content,"utf-8");
    }

    public static void writeJSONObjectIntoFile(File JsonFile,JSONObject jsonObject) throws IOException {
        String content = JSON.toJSONString(jsonObject, SerializerFeature.PrettyFormat, SerializerFeature.WriteMapNullValue,
                SerializerFeature.WriteDateUseDateFormat);
        FileUtils.write(JsonFile,content,"utf-8");
    }
}
