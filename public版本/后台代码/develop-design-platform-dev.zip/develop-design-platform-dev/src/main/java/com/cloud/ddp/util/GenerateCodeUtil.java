package com.cloud.ddp.util;



import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang3.StringUtils;

public class GenerateCodeUtil {

    private static Lock lock = new ReentrantLock();

    /**
     * 根据当前时间获取唯一的编码
     * @param type
     * @return
     */
    public static String generateCode(String type) {
        String code = null;
        lock.lock();
        try {
            if (StringUtils.isBlank(type)) {
                return DateUtil.getDate(new Date(), "yyMMddHHmmSSsss");
            }
            StringBuilder codeBuilder = new StringBuilder();
            codeBuilder.append(type).append("_").append(DateUtil.getDate(new Date(), "yyMMddHHmmSSsss"));
            code = codeBuilder.toString();
        } catch (Exception e) {
            throw new IllegalArgumentException("编码生成失败！");
        } finally {
            lock.unlock();
        }
        return code;
    }

    

    
    

    
}
