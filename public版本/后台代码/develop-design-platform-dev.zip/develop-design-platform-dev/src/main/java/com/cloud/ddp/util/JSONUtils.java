package com.cloud.ddp.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.util.Set;

@Slf4j
public class JSONUtils {
    /**
     * 读取json文件里面的数据
     * @param filename
     * @return
     */
    public static String getJsonObjFromResource(String filename) {
        String json = null;
        try {
            String path = JsonXmlUtils.class.getClassLoader().getResource(filename).getPath();

            File file = new File(path);
            if (file.exists()) {
                json = FileUtils.readFileToString(file, "UTF-8");
//                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return json;
    }


    public static JSONObject parseJSONString(String jsonStr)throws Exception{
        if(StringUtils.isBlank(jsonStr)){
            throw new Exception("JSON字符串为空");
        }
        return JSONObject.parseObject(jsonStr);
    }


    /**
     * 在传入的json对象中获取指定一级节点
     * @param jsonObject
     * @param nodeName
     * @return
     */

    public static JSONObject getJSONNode(JSONObject jsonObject,String nodeName) throws Exception {
        if(jsonObject == null){
            throw new Exception("JSON 对象  NULL");
        }

        if(jsonObject.containsKey(nodeName)){
            return jsonObject.getJSONObject(nodeName);
        }
        return null;
    }


    /**
     * 根据 数组key、key、value找到对应的数组节点对象
     * @param jsonObject
     * @param arrayKey
     * @param key
     * @param value
     * @return
     * @throws Exception
     */
    public static JSONObject findCertainJSONNodesByValueFromArray(JSONObject jsonObject,String arrayKey,String key, String value) throws Exception {
        if(jsonObject == null || StringUtils.isBlank(arrayKey) || StringUtils.isBlank(key) || StringUtils.isBlank(value)) return null;
        JSONArray array = findJSONArrayByKey(jsonObject,arrayKey);
        JSONObject result = findCertainJSONNodesByValueFromArray(array,key,value);
        return result;
    }

    /**
     * 检查数组中是否包含指定key的指定value,如果存在，则返回该节点，如果不存在，则返回 NULL
     * key对应的value在该数组中唯一
     * @param array
     * @param key
     * @param value
     * @return
     */

    public static JSONObject findCertainJSONNodesByValueFromArray(JSONArray array, String key, String value) throws Exception {
        if(StringUtils.isBlank(key) || StringUtils.isBlank(value)){
            throw new Exception("Params invalid");
        }
        if(array == null || array.size() == 0){
            return null;
        }
        int size = array.size();
        for(int i=0;i<size;i++){
            JSONObject object = array.getJSONObject(i);
            if(object.containsKey(key)){
                if(value.equals(object.getString(key))){
                    return object;
                }
            }
        }
        return null;
    }


    /**
     * 从json object 对象中查询某个数组中符合条件的对象集合
     * @param jsonObject
     * @param arrayKey
     * @param key
     * @param value
     * @return
     * @throws Exception
     */
    public static JSONArray findJSONNodesByValueFromArray(JSONObject jsonObject,String arrayKey, String key, String value) throws Exception {
        JSONArray array = findJSONArrayByKey(jsonObject,arrayKey);
        JSONArray result = findJSONNodesByValueFromArray(array,key,value);
        return result;
    }
    /**
     * 检查数组中是否包含指定key的指定value,如果存在，则返回该节点，如果不存在，则返回 NULL
     * key对应的value在该数组中有多个结果
     * @param array
     * @param key
     * @param value
     * @return
     */

    public static JSONArray findJSONNodesByValueFromArray(JSONArray array, String key, String value) throws Exception {
        if(array == null || StringUtils.isBlank(key) || StringUtils.isBlank(value)){
            throw new Exception("参数异常");
        }
        if(array.size() == 0){
            return null;
        }
        JSONArray resultArray = null;
        int size = array.size();
        for(int i=0;i<size;i++){
            JSONObject object = array.getJSONObject(i);
            if(object.containsKey(key)){
                if(value.equals(object.getString(key))){
                    if(resultArray == null){
                        resultArray = new JSONArray();
                    }
                    resultArray.add(object);
                }
            }
        }
        return resultArray;
    }

    public static void insertJSONObject(JSONArray array,JSONObject object){
        array.add(object);
    }

    /**
     * 获取 JSON 对象某个节点的值(value) ,该节点为叶子节点
     * @param jsonObject
     * @param key
     * @return
     */
    public static String getValueFromJSONObject(JSONObject jsonObject,String key){
        String value = null;
        JSONObject target = findJSONObjectByChildKey(jsonObject,key);
        if(target != null){
            value = target.getString(key);
        }
        return value;
    }

    /**
     * 根据子节点的Key找到父节点，并返回父节点对象 (如果父节点直接包含key,则该父节点只能是一个Object,而不是Array)
     * @param jsonObject
     * @param key
     * @return
     */
    public static JSONObject findJSONObjectByChildKey(JSONObject jsonObject,String key){
        JSONObject target = null;
        if(jsonObject.containsKey(key)){
            target = jsonObject;
            return target;
        }
        Set<String> keySet = jsonObject.keySet();
        for(String k : keySet){
            Object obj = jsonObject.get(k);
            if(obj instanceof JSONArray){
                log.info("Object ".concat(key).concat(" is a JSONArray"));
                continue;
            }else if(obj instanceof JSONObject) {
                target = findJSONObjectByChildKey((JSONObject) obj, key);
            }else{
                continue;
            }
        }
        return target;
    }

    /**
     * 根据数组 key 找到数组对象
     * @param jsonObject
     * @param arrayKey
     * @return
     */
    public static JSONArray findJSONArrayByKey(JSONObject jsonObject,String arrayKey){
        JSONArray target = null;
        //首先检查一级子节点是否包含该数组
        if(jsonObject.containsKey(arrayKey)){
            Object obj = jsonObject.get(arrayKey);
            if(obj instanceof JSONArray){
                target = (JSONArray)obj;
                return target;
            }
        }

        Set<String> keySet = jsonObject.keySet();
        for(String k : keySet){
            Object obj = jsonObject.get(k);
            if(obj instanceof JSONArray){
                //虽然是数组，但是key不匹配，所以不是目标对象
                log.info("Object ".concat(arrayKey).concat(" is a JSONArray"));
                continue;
            }else if(obj instanceof JSONObject) {
                target = findJSONArrayByKey((JSONObject) obj, arrayKey);
            }else{
                continue;
            }
        }
        return target;
    }

    /**
     * 将原有数据删除
     * @param array
     * @param key
     * @param value
     * @throws Exception
     */
    public static void removeDataByKeyValueFromArray(JSONArray array,String key,String value) throws Exception {
        JSONArray removeArray = findJSONNodesByValueFromArray(array,key,value);
        if(removeArray == null || removeArray.size() == 0){
            return;
        }
        for(Object o : removeArray){
            array.remove(o);
        }
    }

    /**
     * 将对象的key转换为驼峰风格
     * @param object
     * @return
     */
    public static Object convertKeyToCamelStyle(Object object){
        Object result = null;
        if(object instanceof JSONObject){
            JSONObject convertedJSONObject = new JSONObject();
            JSONObject jsonObject = ((JSONObject)object);
            Set<String> keySet = jsonObject.keySet();
            for(String key : keySet){
                String convertedKey = CaseConversionUtils.convertLowerCaseAndHyphenToUpperCase(key);
                Object obj = jsonObject.get(key);
                Object convertedObj = convertKeyToCamelStyle(obj);
                convertedJSONObject.put(convertedKey,convertedObj);
            }
            result = convertedJSONObject;
        }else if( object instanceof JSONArray){
            JSONArray array = (JSONArray) object;
            JSONArray convertedArray = new JSONArray();
            for(Object obj : array){
                convertedArray.add(convertKeyToCamelStyle(obj));
            }
            result = convertedArray;
        }else{
            result = object;
        }
        return result;
    }

    /**
     * 将驼峰风格的key转换成小写，并加上-作为分隔符
     * @param object
     * @return
     */
    public static Object convertKeyToLowerCaseAndAddHyphen(Object object){
        Object result = null;
        if(object instanceof JSONObject){
            JSONObject convertedJSONObject = new JSONObject();
            JSONObject jsonObject = ((JSONObject)object);
            Set<String> keySet = jsonObject.keySet();
            for(String key : keySet){
                String convertedKey = CaseConversionUtils.convertUpperCaseToLowerCaseAndHyphen(key);
                Object obj = jsonObject.get(key);
                Object convertedObj = convertKeyToLowerCaseAndAddHyphen(obj);
                convertedJSONObject.put(convertedKey,convertedObj);
            }
            result = convertedJSONObject;
        }else if( object instanceof JSONArray){
            JSONArray array = (JSONArray) object;
            JSONArray convertedArray = new JSONArray();
            for(Object obj : array){
                convertedArray.add(convertKeyToLowerCaseAndAddHyphen(obj));
            }
            result = convertedArray;
        }else{
            result = object;
        }
        return result;
    }
}
