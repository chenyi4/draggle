package com.cloud.ddp.util;

import java.io.*;
import java.util.Iterator;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.xml.sax.SAXException;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;

/**
 * package com.cloud.ddp.util;
 * 描述：
 * @author wenlu
 * @date 2020年3月4日下午1:31:25
 */
public class JsonXmlUtils {

	/**
	 * json 转xml工具方法
	 * @param json
	 * @return
	 */
	public static String jsonToPrettyXml(JSONObject json) {
        StringWriter formatXml;
		try {
			Document document = jsonToDocument(json);

			/* 格式化xml */
			OutputFormat format = OutputFormat.createPrettyPrint();

			// 设置缩进为4个空格
			format.setIndent(" ");
			format.setIndentSize(4);

			formatXml = new StringWriter();
			XMLWriter writer = new XMLWriter(formatXml, format);
			writer.write(document);
			return formatXml.toString();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    }
	
	
	/**
	 * json 转xml工具方法，生成xml
	 * @param json
	 * @return
	 */
	public static void jsonToPrettyXml(JSONObject json,String fileName) {
        Writer out = null;
        XMLWriter writer = null;
		try {
			FileUtil.deleteFileRecursively(fileName);

			FileUtil.createParentDirRecursively(fileName);

			Document document = jsonToDocument(json);

			/* 格式化xml */
			OutputFormat format = OutputFormat.createPrettyPrint();

			// 设置缩进为4个空格
			format.setIndent(" ");
			format.setIndentSize(4);
			
			out = new PrintWriter(fileName, ConfigConstants.ENCODING);
			writer = new XMLWriter(out, format);
			
			writer.write(document);
			
			out.close();
			writer.close();
			 
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(out!= null){
				try {
					out.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(writer!=null){
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
    }
	
	
	/**
     * JSON对象转Document对象
     * 
     * @param json JSON对象
     * @return Document对象
     * @throws SAXException
     */
    public static Document jsonToDocument(JSONObject json) throws SAXException {
        Document document = DocumentHelper.createDocument();
        document.setXMLEncoding(ConfigConstants.ENCODING);

        // root对象只能有一个
        for (String rootKey : json.keySet()) {
            Element root = jsonToElement(json.getJSONObject(rootKey), rootKey);
            document.add(root);
            break;
        }
        return document;
    }
    
    
    
    /**
     * JSON对象转Element对象
     * 
     * @param json JSON对象
     * @param nodeName 节点名称
     * @return Element对象
     */
    public static Element jsonToElement(JSONObject json, String nodeName) {
        Element node = DocumentHelper.createElement(nodeName);
        for (String key : json.keySet()) {
            Object child = json.get(key);
            
            //nodeName属性标签
            if(StringUtils.endsWith(key, ConfigConstants.PROPERTIES_TAG)){
            	String str = json.getString(ConfigConstants.PROPERTIES_TAG);
            	JSONObject attrObj = JSONObject.parseObject(str);
            	for(String attr : attrObj.keySet()){
            		node.addAttribute(attr, attrObj.getString(attr));
            	}
            	
            }
            //subnode 多数据标签
            else if(StringUtils.endsWith(key, ConfigConstants.SUB_NODE_LIST)){
            	String str = json.getString(ConfigConstants.SUB_NODE_LIST);
            	JSONArray arr = JSONArray.parseArray(str);
            	for (Object object : arr) {
					JSONObject o  = (JSONObject) object;
					for (String k : o.keySet()) {
						Object value = o.get(k);
						if(value instanceof JSONObject){
							 node.add(jsonToElement(o.getJSONObject(k), k));
						}else{
							 Element e = node.addElement(k);
							 e.setText(o.getString(k));		

						}
					}
				}
            }
            else if(child instanceof JSONArray){
            	Iterator<Object> it = ((JSONArray) child).iterator();
            	while(it.hasNext()){            		
            		Object o = it.next();
            		JSONObject obj = null;
            		if(o instanceof JSONObject){
            			obj = (JSONObject) o;
            			node.add(jsonToElement(obj, key));
            		}else if(o instanceof JSONArray){
            			JSONArray ls = (JSONArray) o;
            			for (Object object : ls) {
            				obj = (JSONObject) object;
            				node.add(jsonToElement(obj, key));
						}
            		}
            	}
            }
            
            else if (child instanceof JSONObject) {
                node.add(jsonToElement(json.getJSONObject(key), key));
            }

            else {
                Element element = DocumentHelper.createElement(key);
                element.setText(json.getString(key));
                node.add(element);
            }
        }

        return node;
    }
}
