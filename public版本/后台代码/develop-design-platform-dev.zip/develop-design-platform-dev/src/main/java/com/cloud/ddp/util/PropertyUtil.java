package com.cloud.ddp.util;




import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;



/**
 * 用于读取 .property文件的配置
 */
@Slf4j
public class PropertyUtil {
    public static final String CONFIG_PATH = "./ddp-system-config/ddp.properties";
//    public static final String CONFIG_PATH = "A:\\workspace\\ddp-system-config\\ddp.properties";
    public static final Map<String,Object> propMap = new HashMap<>();

    static {
        try {
            loadConfig();
        } catch (IOException e){
            log.error(e.getMessage());
        }
    }

    /**
     * 加载配置信息
     * @throws IOException
     */
    public static void loadConfig() throws IOException {
        Properties prop = loadProperty(CONFIG_PATH);
        for (Map.Entry<Object, Object> entry : prop.entrySet()) {
            propMap.put((String) entry.getKey(), entry.getValue());
        }
    }

    public static Properties loadProperty(String filePath)throws IOException{
        Properties prop;
        InputStream is = null;
        try {
            log.info("user dir : " + System.getProperty("user.dir"));
            log.info("user home : " + System.getProperty("user.home"));
            log.info("Configuration file path : " + filePath);
            prop = new Properties();
            File file = new File(filePath);
            if(!file.exists()){
                throw new IOException("Can not find the configuration property file !");
            }
            is = new FileInputStream(file);
            prop.load(is);
            return prop;
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException(e.getMessage());
        }finally {
            if(is != null){
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new IOException(e.getMessage());
                }
            }
        }
    }

    public static Object getProperty(String key) throws Exception {
        if(propMap.isEmpty()){
            loadConfig();
        }
        if(!propMap.containsKey(key)){
            throw new Exception("配置项 : ".concat(key).concat(" 不存在"));
        }
        return propMap.get(key);
    }

    public static int setProperty(String key,String value)throws IOException{
        Properties prop = loadProperty(CONFIG_PATH);
        OutputStream os = null;
        try {
            File file = new File(CONFIG_PATH);
            file.delete();
            prop.setProperty(key,value);
            os = new FileOutputStream(CONFIG_PATH);
            Enumeration<?> enumeration = prop.propertyNames();
            while(enumeration.hasMoreElements()){
                String k = (String)enumeration.nextElement();
                String v = prop.getProperty(k);
                String s = k + "=" + v + "\n";
                os.write(s.getBytes());
            }
            os.flush();
            return 0;
        }catch (IOException e){
            e.printStackTrace();
            throw new IOException(e.getMessage());
        }finally {
            if(os != null){
                os.close();
            }
        }
    }
}
