package com.cloud.ddp.util;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;


import org.apache.commons.lang3.StringUtils;

public class ResultWrapper{

	public static String response(Object data,int code,String message){
        JSONObject json = new JSONObject();
        json.put("code",code);
        json.put("message",message);
        json.put("data",data);
        return JSONObject.toJSONString(json,SerializerFeature.WriteMapNullValue);
    }

    public static String error(){
        return response("",1,"请求异常");
    }

    public static String error(String message){
        return response("",1,message);
    }

    public static String ok(Object data){
        if(data == null){
            return noData();
        }
        return response(data,0,"请求成功");
    }

    public static String ok(Object data,String message){
        if(data == null){
            return noData();
        }
        return response(data,0,message);
    }

    public static String ok(String message){
        return response("",0,message);
    }

    public static String ok(){
        return response("",0,"操作成功");
    }

    public static String noData(String message){
        String m = "未查询到数据";
        if(StringUtils.isNotBlank(message)){
            m = message;
        }
        return response("",2,m);
    }

    public static String noData(){
        return response("",2,"未查询到数据");
    }
}
