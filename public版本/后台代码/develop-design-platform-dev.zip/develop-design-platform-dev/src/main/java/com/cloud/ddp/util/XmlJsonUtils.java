package com.cloud.ddp.util;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.constants.ConfigConstants;

/**
 * package com.cloud.ddp.util;
 * 描述：xml转json 工具类
 * @author wenlu
 * @date 2020年3月11日下午3:30:36
 */
public class XmlJsonUtils {
	
	
	 /**
     * xml转json
     * @param xmlStr
     * @return
     * @throws DocumentException
     */
    public static JSONObject xml2Json(String xmlStr){
        JSONObject json = new JSONObject();
		try {
			Document doc= DocumentHelper.parseText(xmlStr);
			json = new JSONObject();
			
			// root对象只能有一个
			String root = doc.getRootElement().getName();
			JSONObject element = new JSONObject();
			json.put(root, element);
			
			dom4j2Json(doc.getRootElement(), element);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return json;
    }
    
    
    
    /**
     * xml转json
     * @param element
     * @param json
     */
    public static void dom4j2Json(Element element,JSONObject json){
        //如果是属性
    	JSONObject attrObj = new JSONObject();
        for(Object o:element.attributes()){
            Attribute attr=(Attribute)o;
            if(StringUtils.isNotEmpty(attr.getValue())){
            	attrObj.put(attr.getName(), attr.getValue());
            }
            json.put(ConfigConstants.PROPERTIES_TAG, attrObj);
        }
        List<Element> chdEl=element.elements();
        if(chdEl.isEmpty()&&StringUtils.isNotEmpty(element.getText())){//如果没有子元素,只有一个值
            json.put(element.getName(), element.getText());
        }

        
        for(Element e:chdEl){//有子元素
            if(!e.elements().isEmpty()){//子元素也有子元素
                JSONObject chdjson=new JSONObject();
                dom4j2Json(e,chdjson);
                Object o=json.get(e.getName());
                if(o!=null){
                    JSONArray jsona=null;
                    if(o instanceof JSONObject){//如果此元素已存在,则转为jsonArray
                        JSONObject jsono=(JSONObject)o;
                        json.remove(e.getName());
                        jsona=new JSONArray();
                        jsona.add(jsono);
                        jsona.add(chdjson);
                    }
                    if(o instanceof JSONArray){
                        jsona=(JSONArray)o;
                        jsona.add(chdjson);
                    }
                    json.put(e.getName(), jsona);
                }else{
                    if(!chdjson.isEmpty()){
                        json.put(e.getName(), chdjson);
                    }
                }


            }else{//子元素没有子元素
            	
            	JSONObject subElement = new JSONObject();
            	
            	 //如果元素已经存在，则转换为JSONArray
            	 Object obj=json.get(e.getName());
            	 JSONArray jsona=null;
                if(obj != null && obj instanceof JSONObject){
                	JSONObject jsono=(JSONObject)obj;
                	json.remove(e.getName());
                	jsona=new JSONArray();
                	jsona.add(jsono);
                	json.put(e.getName(), jsona);
                }
            	
               
                for(Object o:e.attributes()){
                    Attribute attr=(Attribute)o;
                    if(StringUtils.isNotEmpty(attr.getValue())){
                    	subElement.put(attr.getName(), attr.getValue());
                    }
                }
                Object nodeElement = "";
                if(subElement!=null && subElement.size()>0){
                	 nodeElement = new JSONObject();
                	 ((JSONObject) nodeElement).put(ConfigConstants.PROPERTIES_TAG, subElement);
                }
               
                if(obj == null){
                	json.put(e.getName(), nodeElement);
                }else{
                	jsona.add(nodeElement);
                }
                               
                if(!e.getText().isEmpty()){
                    json.put(e.getName(), e.getText());
                }
            }
        }
    }

}

