package com.cloud.ddp.vo;



import lombok.Data;


@Data
public class BaseObject{

	private String primaryId;
	
	private String name;
			

}