package com.cloud.ddp.operation;

import com.cloud.ddp.constants.IncrementConstants;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

@Slf4j
public class IncrementOperationTests {

    @Test
    public void testGetIncrementIndexByKeyWithoutWriteBackToFile(){
        String tableIdString = null;
        try {
            tableIdString = IncrementOperation.getIncrementIndexByKeyWithoutWriteBackToFile("1", IncrementConstants.TABLE_INCREMENT_INDEX_KEY);
            IncrementOperation.updateIncrementIndexByKey("1",IncrementConstants.TABLE_INCREMENT_INDEX_KEY,tableIdString);
        } catch (Exception e) {
            e.printStackTrace();
        }
        log.info("New table id is : " + tableIdString);
    }
}
