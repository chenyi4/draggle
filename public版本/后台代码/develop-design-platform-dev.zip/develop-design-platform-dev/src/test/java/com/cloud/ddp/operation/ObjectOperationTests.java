package com.cloud.ddp.operation;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

@Slf4j
public class ObjectOperationTests {

    @Test
    public void testAddObject(){
        String object = "{\"object-id\":\"1\",\"object-name\":\"物料\",\"object-type\":\"1\",\"page-key\":\"material\",\"code-rule\":\"BM002\",\"level\":\"2\"}";
        String result = ObjectOperation.addOrUpdateObject("baseData",object);
        log.info(result);
    }

    @Test
    public void testUpdatePageKeyByGroupNameAndObjectId(){
        String result = ObjectOperation.updatePageKeyByGroupNameAndObjectId("baseData","1","material2");
        log.info(result);
    }

    @Test
    public void testGetAllObjects(){
        String result = ObjectOperation.getAllObjects();
        log.info(result);
    }

    @Test
    public void testGetGroupList(){
        String result = ObjectOperation.getGroupList();
        log.info(result);
    }

    @Test
    public void testGetObjectTypeList(){
        String result = ObjectOperation.getObjectTypeList();
        log.info(result);
    }
}
