package com.cloud.ddp.operation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

@Slf4j
public class ProjectOperationTests {

    @Test
    public void testCreateProject() throws Exception {
        String json = "{\"project-name\":\"项目333\"}";
        ProjectOperation.createProject(json);
    }


    @Test
    public void testJSONObject(){
        String json = "{\"project-name\":\"项目333\"}";
        JSONObject jsonObject = JSONObject.parseObject(json);
        Object obj = jsonObject;//jsonObject.get("project-name");
        if(obj instanceof JSONObject){
            log.info("instance of JSONObject");
        }
        if(obj instanceof JSONArray){
            log.info("instance of JSONArray");
        }
        if(obj instanceof Object){
            log.info("instance of Object");
        }
    }
}
