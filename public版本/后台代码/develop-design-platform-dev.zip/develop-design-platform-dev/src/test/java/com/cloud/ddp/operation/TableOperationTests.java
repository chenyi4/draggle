package com.cloud.ddp.operation;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.cloud.ddp.util.JSONUtils;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

@Slf4j
public class TableOperationTests {

    @Test
    public void testFindTableByTableId() throws Exception {
        String result = TableOperation.findTableByTableId("1");
        log.info(result);
    }

    @Test
    public void testGetTableList() throws Exception {
        String result = TableOperation.getAllTableList();
        log.info(result);
    }

    @Test
    public void testConvertToLowerCaseAndAddHyphen(){
        String result = TableOperation.getAllTableList();
        JSONObject json = JSONObject.parseObject(result);
        JSONArray array = json.getJSONArray("data");
        JSONArray convertedArray = (JSONArray) JSONUtils.convertKeyToLowerCaseAndAddHyphen(array);
        log.info(JSONObject.toJSONString(convertedArray));
    }

    @Test
    public void testInsertTablesByPageKey() throws Exception {
        String result = TableOperation.getAllTableList();
        JSONObject json = JSONObject.parseObject(result);
        JSONArray array = json.getJSONArray("data");
        JSONObject table = array.getJSONObject(0);
        table.put("table-name","form20");
//        table.put("table-id","");
        JSONArray jsonArray = new JSONArray();
        jsonArray.add(table);
        jsonArray = (JSONArray)JSONUtils.convertKeyToCamelStyle(jsonArray);
        String res = TableOperation.addOrUpdateTablesByPageKey(null,null,"baseData",JSONArray.toJSONString(jsonArray));
        log.info(res);
    }

    @Test
    public void testGetTableListByPageKey() throws Exception {
//        String result = TableOperation.getTableListByPageKey("engineering");
//        log.info(result);
    }
}
