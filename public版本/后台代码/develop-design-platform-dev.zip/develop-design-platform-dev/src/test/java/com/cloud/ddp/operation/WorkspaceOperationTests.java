package com.cloud.ddp.operation;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

@Slf4j
public class WorkspaceOperationTests {

    @Test
    public void testCreateWorkspace() throws Exception {
        WorkspaceOperation.createWorkspace(null);
    }
}
