package com.cloud.ddp.plugin;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

@Slf4j
public class FileDetectorTests {

    @Test
    public void testDetectFile() throws IOException {
        List<String> list = FileDetector.detectFile("create-project","page-key");
        for(String s : list){
            log.info(s);
        }
    }
}
