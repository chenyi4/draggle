package com.cloud.ddp.system;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.io.IOException;

@Slf4j
public class SystemConfigManagementTests {
    @Test
    public void testSetWorkingPath(){
        try {
            SystemConfigManagement.setWorkspacePath("A:/workspace/ddp-system-config/data");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testGetWorkspacePath() throws Exception {
        String path = SystemConfigManagement.getWorkspacePath();
        log.info(path);
    }
}
