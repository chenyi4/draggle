package com.cloud.ddp.util;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Test;

import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
public class FileUtilTests {

    @Test
    public void testReadJsonFile(){
        try {
            log.info("Current path : " + System.getProperty("user.dir"));
            String jsonData = FileUtil.readJsonFile("src\\main\\resources\\meta\\bizconfig\\property_collection.json");
            System.out.println(jsonData);
        } catch (IOException e) {
            log.error("读取文件异常\n"+ ExceptionUtils.getStackTrace(e));
        }
    }

    public void testAtomic(){
        AtomicInteger number = new AtomicInteger(0);
    }
}
