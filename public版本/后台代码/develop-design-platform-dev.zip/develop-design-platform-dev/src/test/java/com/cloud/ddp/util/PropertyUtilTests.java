package com.cloud.ddp.util;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.junit.Test;

import java.io.File;

@Slf4j
public class PropertyUtilTests {
    @Test
    public void testLoadConfig(){
        try {
            log.info("Current path : " + System.getProperty("user.dir"));
            String filePath = (String)PropertyUtil.getProperty("system-workspace");
            log.info("system config path is : "+filePath);
            File file = new File(filePath);
            log.info("File existence : "+file.exists());
            log.info("Is directory : " + file.isDirectory());
        } catch (Exception e) {
            log.error("读取文件异常\n"+ ExceptionUtils.getStackTrace(e));
        }
    }
}
