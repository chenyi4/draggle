from fabric.api import *
from fabric.contrib.console import confirm
from fabric.utils import abort
from fabric.colors import *

import os, sys, stat
import subprocess
import io
import shutil
import time


env.hosts = ['139.217.236.17']
env.port = 22
env.user = 'huyuan'
env.password = 'HuYuan123321'

JAVA = '/usr/local/jre/bin/java'

def deploy_ddp():
    front_end_code_path = 'A:/workspace/develop-design-platform-base'
    back_end_code_path = 'A:/workspace/develop-design-platform'
    # update front end code and package
    os.chdir(front_end_code_path)
    command_frontend_package = 'git pull origin master && npm run build'
    os.system(command_frontend_package)

    # update back end code and package
    os.chdir(back_end_code_path)
    command_backend_package = 'git pull origin dev && mvn clean package -DskipTests=true'
    os.system(command_backend_package)

    run('process_id=`ps aux | grep develop-design-platform.jar | grep -v grep | awk \'{print $2}\'` && if [ $process_id ]; then kill -9 $process_id ; fi')
    os.chdir(back_end_code_path+'\\target')
    put('develop-design-platform.jar', '/opt/app/ddp/')
    run('cd /opt/app/ddp/ && (nohup ' + JAVA + ' -XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8 -Dserver.port=8090 -jar /opt/app/ddp/develop-design-platform.jar >> /opt/app/ddp/logs/ddp.log 2>&1 &) && sleep 1')


    os.chdir(front_end_code_path+'\\dist')
    run('cd /opt/app/ddp-frontend && rm -rf *')
    put('*', '/opt/app/ddp-frontend/')

