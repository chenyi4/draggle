from fabric.api import *
from fabric.contrib.console import confirm
from fabric.utils import abort
from fabric.colors import *

import os, sys, stat
import subprocess
import io
import shutil
import time

''' 
env.hosts = ['139.217.236.17']
env.port = 22
env.user = 'huyuan'
env.password = 'HuYuan123321'
'''


# 源代码路径
REPO_PATH = '/opt/app/codeGenerate/MES_Standard_main'
REMOTE_PATH = "/opt/app"

# 打包阶段对应的配置文件环境
ACTIVE_PROFILE = '-Pprod'


WORK_DIR = '/opt/app'
JAVA = '/usr/local/java/bin/java'

MVN = '/usr/local/apache-maven-3.6.3/bin/mvn'

JAVA_OPTS = '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'

MODULES = {
    'config-center': {
        'name': 'config-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'data-center': {
        'name': 'data-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'file-center': {
        'name': 'file-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'gateway-zuul': {
        'name': 'gateway-zuul',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'log-center': {
        'name': 'log-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-backend': {
        'name': 'manage-backend',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-baseData': {
        'name': 'manage-baseData',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-engineering': {
        'name': 'manage-engineering',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-production': {
        'name': 'manage-production',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-quality': {
        'name': 'manage-quality',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'monitor-center': {
        'name': 'monitor-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'notification-center': {
        'name': 'notification-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'oauth-center': {
        'name': 'oauth-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'register-center': {
        'name': 'register-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'user-center': {
        'name': 'user-center',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    },
    'mes-device': {
        'name': 'mes-device',
        'java-opts': '-Xmx312m -Xms312m -Xmn200m -Xss256k -XX:SurvivorRatio=8'
    }

}

module_list = [
    'register-center',
    'config-center',
    'gateway-zuul',
    'oauth-center',
    'user-center',
    'data-center',
    'file-center',
    'log-center',
    'monitor-center',
    'notification-center',
    'manage-backend'
    # 'manage-baseData', 
    # 'manage-engineering', 
    # 'manage-production',
    # 'manage-quality',
    # 'mes-device'
]


package_command = MVN + ' clean package -DskipTests=true ' + ACTIVE_PROFILE

def run_command(command):
    print(os.system(command))

def package_service(source_code_dir, package_command, module_name):
    os.chdir(source_code_dir+'/'+module_name)
    print('Package %s service\n'%module_name)
    run_command(package_command)
    print('Package %s service completed\n'%module_name)

def stop_process(module_name):
    run_command('process_id=`ps aux | grep '+ module_name +'.jar | grep -v grep | awk \'{print $2}\'` && if [ $process_id ]; then kill -9 $process_id ; fi')

def start_process(module_name):
    if(MODULES[module_name]  is not None and MODULES[module_name]['java-opts'] is not None):
        run_command('cd ' + WORK_DIR + ' && (nohup ' + JAVA + ' ' + MODULES[module_name]['java-opts'] + ' -jar /opt/app/' + module_name + '.jar >> /opt/app/logs/'+ module_name +'.log 2>&1 &) && sleep 1')
    else:
        run_command('cd ' + WORK_DIR + ' && (nohup ' + JAVA + ' ' + JAVA_OPTS + ' -jar /opt/app/' + module_name + '.jar >> /opt/app/logs/'+ module_name +'.log 2>&1 &) && sleep 1')

def move_jar_to_workspace(module_name):
    run_command('mv '+ REPO_PATH+'/'+module_name+'/target/' + module_name +'.jar /opt/app/')

def deploy_service(module_name):
    stop_process(module_name)
    move_jar_to_workspace(module_name)
    start_process(module_name)


def restart_service(module_name):
    stop_process(module_name)
    start_process(module_name)

def upload_xml():
    os.chdir(REPO_PATH)
    run_command('mv xml/* /opt/app/')

def reinstall_dependencies():
    INSTALL_COMMAND = MVN + ' clean install -DskipTests=true'
    os.chdir(REPO_PATH+'/api-model')
    run_command(INSTALL_COMMAND)
    os.chdir(REPO_PATH+'/commons')
    run_command(INSTALL_COMMAND)
    os.chdir(REPO_PATH+'/log-starter')
    run_command(INSTALL_COMMAND)


def deploy_common_service():
    for module in module_list:
        package_service(REPO_PATH, package_command, module)
    for module in module_list:
        deploy_service(module)
        time.sleep(30)


''' 按参数列表重启某个服务(基础服务和自定义服务都可)
'''
def restart_list(*mlist):
    for module in mlist:
        restart_service(module)


''' 按参数列表停止某个服务(基础服务和自定义服务都可)
'''
def stop_list(*mlist):
    for module in mlist:
        stop_process(module)


''' 按参数列表只部署自定义服务
'''
def deploy_custom_service(*mlist):
    for module in mlist:
        package_service(REPO_PATH, package_command, module)
    for module in mlist:
        deploy_service(module)
        time.sleep(30)


''' 1, 重新编译api-model commons log-starter 等依赖模块，并安装到本地maven仓库
    2, 将代码目录中的xml文件拷贝至工作目录
    3, 部署基础服务
    4, 按参数列表部署自定义服务
'''
def deploy_all(*mlist):
    reinstall_dependencies()
    upload_xml()
    deploy_common_service()
    for module in mlist:
        package_service(REPO_PATH, package_command, module)
    for module in mlist:
        deploy_service(module)
        time.sleep(30)