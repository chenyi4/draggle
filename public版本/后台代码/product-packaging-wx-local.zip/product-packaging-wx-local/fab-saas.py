from fabric.api import *
from fabric.contrib.console import confirm
from fabric.utils import abort
from fabric.colors import *

import os, sys, stat
import subprocess
import io
import shutil
import time
 
env.hosts = ['52.130.82.82']
env.port = 22
env.user = 'huyuan'
env.password = 'huyuan123321@'


# 源代码路径
REPO_PATH = 'A:\\deploy-workspace\\mes-saas'
REMOTE_PATH = "/opt/app"

# 打包阶段对应的配置文件环境
ACTIVE_PROFILE = '-Psaas'


WORK_DIR = '/opt/app'
JAVA = '/usr/local/jdk/bin/java'

MVN = 'A:\\software\\maven\\apache-maven-3.6.2-saas\\bin\\mvn'

MODULES = {
    'config-center': {
        'name': 'config-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'data-center': {
        'name': 'data-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'file-center': {
        'name': 'file-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'gateway-zuul': {
        'name': 'gateway-zuul',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'log-center': {
        'name': 'log-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-backend': {
        'name': 'manage-backend',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-baseData': {
        'name': 'manage-baseData',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-engineering': {
        'name': 'manage-engineering',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-production': {
        'name': 'manage-production',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-quality': {
        'name': 'manage-quality',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-report': {
        'name': 'manage-report',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'monitor-center': {
        'name': 'monitor-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'notification-center': {
        'name': 'notification-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'oauth-center': {
        'name': 'oauth-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'register-center': {
        'name': 'register-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'user-center': {
        'name': 'user-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'mes-device': {
        'name': 'mes-device',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-backend-mobile': {
        'name': 'manage-backend-mobile',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    }

}

module_list = [
    'register-center',
    'config-center',
    'gateway-zuul',
    'oauth-center',
    'user-center',
    'data-center',
    'file-center',
    'log-center',
    'manage-backend',
    'manage-backend-mobile', 
    'manage-baseData', 
    'manage-engineering', 
    'manage-production',
    'manage-quality',
    'manage-report',
    'monitor-center',
    'notification-center',
    'mes-device',
    'xml'
]


package_command = MVN + ' clean package -DskipTests=true ' + ACTIVE_PROFILE

def run_command(command):
    # p = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # output = p.stdout.read().decode('gbk')
    # print(output)
    print(os.system(command))

def package_service(source_code_dir, package_command, module_name):
    os.chdir(source_code_dir+'\\'+module_name)
    print('Package %s service\n'%module_name)
    run_command(package_command)
    print('Package %s service completed\n'%module_name)


def upload_jar(module_name):
    os.chdir(REPO_PATH+'\\'+module_name+'\\target')
    put(module_name + '.jar', REMOTE_PATH + '/jar')

def stop_process(module_name):
    run('process_id=`ps aux | grep '+ MODULES[module_name]['name'] +'.jar | grep -v grep | awk \'{print $2}\'` && if [ $process_id ]; then kill -9 $process_id ; fi')

def deploy_service(module_name):
    stop_process(module_name)
    run('mv /opt/app/jar/' + MODULES[module_name]['name'] +'.jar /opt/app/')
    run('cd ' + WORK_DIR + ' && (nohup ' + JAVA + ' ' + MODULES[module_name]['java-opts'] + ' -jar /opt/app/' + MODULES[module_name]['name'] + '.jar >> /opt/app/logs/'+ MODULES[module_name]['name'] +'.log 2>&1 &) && sleep 1')

def reinstall_dependencies():
    INSTALL_COMMAND = MVN + ' clean install -DskipTests=true'
    os.chdir(REPO_PATH+'\\api-model')
    run_command(INSTALL_COMMAND)
    os.chdir(REPO_PATH+'\\commons')
    run_command(INSTALL_COMMAND)
    os.chdir(REPO_PATH+'\\log-starter')
    run_command(INSTALL_COMMAND)
    os.chdir(REPO_PATH+'\\data-center')
    run_command(INSTALL_COMMAND)

def upload_xml():
    os.chdir(REPO_PATH)
    put('xml/*', '/opt/xml/')

def merge_pull_request():
    os.chdir(REPO_PATH)
    run_command('git checkout root-saas && git pull http://10.12.65.26:8081/gitbucket/git/root/MES_Standard_main.git saas --no-edit && git checkout saas && git merge --no-ff --no-edit root-saas && git push origin saas')

 
def deploy_all():
    merge_pull_request()
    for module in module_list:
        package_service(module)


def deploy_list(*mlist):
    # merge_pull_request()
    reinstall_dependencies()
    for module in mlist:
        package_service(REPO_PATH, package_command, module)
    for module in mlist:
        upload_jar(module)
    upload_xml()
    for module in mlist:
        deploy_service(module)
        time.sleep(30)
    


def restart_service(module_name):
    stop_process(module_name)
    run('cd ' + WORK_DIR + ' && (nohup ' + JAVA + ' ' + MODULES[module_name]['java-opts'] + ' -jar /opt/app/' + MODULES[module_name]['name'] + '.jar >> /opt/app/logs/'+ MODULES[module_name]['name'] +'.log 2>&1 &) && sleep 1')


def restart_list(*mlist):
    for module in mlist:
        restart_service(module)
        time.sleep(30)


xml_module_list = [
    'user-center',
    'data-center',
    'manage-backend', 
    'manage-baseData'
]


def restart_xml_related():
    for module in xml_module_list:
        restart_service(module)