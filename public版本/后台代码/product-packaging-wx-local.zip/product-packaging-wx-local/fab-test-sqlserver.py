from fabric.api import *
from fabric.contrib.console import confirm
from fabric.utils import abort
from fabric.colors import *

import os, sys, stat
import subprocess
import io
import shutil
import time
 
env.hosts = ['10.12.65.25']
env.port = 20022
env.user = 'root'
env.password = 'pactera@123'


# 源代码路径
REPO_PATH = 'A:\\deploy-workspace\\sqlserver-test-branch'
REMOTE_PATH = "/opt/app"

# 打包阶段对应的配置文件环境

ACTIVE_PROFILE = 'test-sqlserver'

WORK_DIR = '/opt/app'
JAVA = '/usr/local/jre/bin/java'

MVN = 'A:\\software\\maven\\apache-maven-3.6.2\\bin\\mvn'

WHITE_SPACE = ' '

CONFIG_PARAMS = '-Dspring.cloud.config.uri=http://localhost:3301 -Dspring.cloud.config.profile=' + ACTIVE_PROFILE

EMPTY_CONFIG_PARAMS = ''

JAVA_OPTS_KEY = 'java-opts'

JAVA_CONFIG_PARAMS_KEY = 'java-config-params'

MODULES = {
    'config-center': {
        'name': 'config-center',
        'java-opts': '-XX:MetaspaceSize=64m -XX:MaxMetaspaceSize=64m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': EMPTY_CONFIG_PARAMS
    },
    'data-center': {
        'name': 'data-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'file-center': {
        'name': 'file-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'gateway-zuul': {
        'name': 'gateway-zuul',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'log-center': {
        'name': 'log-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'manage-backend': {
        'name': 'manage-backend',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'manage-baseData': {
        'name': 'manage-baseData',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'manage-engineering': {
        'name': 'manage-engineering',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'manage-production': {
        'name': 'manage-production',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'manage-quality': {
        'name': 'manage-quality',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'manage-report': {
        'name': 'manage-report',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'monitor-center': {
        'name': 'monitor-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'notification-center': {
        'name': 'notification-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'oauth-center': {
        'name': 'oauth-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'register-center': {
        'name': 'register-center',
        'java-opts': '-XX:MetaspaceSize=64m -XX:MaxMetaspaceSize=64m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': EMPTY_CONFIG_PARAMS
    },
    'user-center': {
        'name': 'user-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'mes-device': {
        'name': 'mes-device',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    },
    'manage-backend-mobile': {
        'name': 'manage-backend-mobile',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx256m -Xms200m -Xmn200m -Xss256k -XX:SurvivorRatio=8',
        'java-config-params': CONFIG_PARAMS
    }

}

module_list = [
    'register-center',
    'config-center',
    'gateway-zuul',
    'user-center',
    'oauth-center',
    'data-center',
    'file-center',
    'log-center',
    'monitor-center',
    'notification-center',
    'manage-backend',
    'manage-baseData',
    'manage-engineering',
    'manage-production',
    'manage-quality',
    'mes-device'
]


package_command = MVN + ' clean package -DskipTests=true'  #+ ACTIVE_PROFILE

def run_command(command):
    # p = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # output = p.stdout.read().decode('gbk')
    # print(output)
    print(os.system(command))

def package_service(source_code_dir, package_command, module_name):
    os.chdir(source_code_dir+'\\'+module_name)
    print('Package %s service\n'%module_name)
    run_command(package_command)
    print('Package %s service completed\n'%module_name)


def upload_jar(module_name):
    os.chdir(REPO_PATH+'\\'+module_name+'\\target')
    put(module_name + '.jar', REMOTE_PATH + '/jar')

def stop_process(module_name):
    stop_process_command = 'process_id=`ps aux | grep '+ MODULES[module_name]['name'] +'.jar | grep -v grep | awk \'{print $2}\'` && if [ $process_id ]; then kill -9 $process_id ; fi'
    print('\n Stop process %s , and the stop process commands are : \n %s'%(module_name ,stop_process_command))
    run(stop_process_command)

def copy_jar_to_workspace(module_name):
    run('mv /opt/app/jar/' + MODULES[module_name]['name'] +'.jar /opt/app/')

def start_jar(module_name):
    start_jar_command = 'cd ' + WORK_DIR + ' && (nohup' + WHITE_SPACE + JAVA + WHITE_SPACE + MODULES[module_name][JAVA_OPTS_KEY] + WHITE_SPACE + MODULES[module_name][JAVA_CONFIG_PARAMS_KEY] + WHITE_SPACE +'-jar /opt/app/' + MODULES[module_name]['name'] + '.jar >> /opt/app/logs/'+ MODULES[module_name]['name'] +'.log 2>&1 &) && sleep 1'
    print('\n Start application %s , and the start commands are : \n %s'%(module_name ,start_jar_command))
    run(start_jar_command)

def deploy_service(module_name):
    print('\n Deploy application %s'%(module_name))
    stop_process(module_name)
    copy_jar_to_workspace(module_name)
    start_jar(module_name)

def reinstall_dependencies():
    INSTALL_COMMAND = MVN + ' clean install -DskipTests=true'
    os.chdir(REPO_PATH+'\\api-model')
    run_command(INSTALL_COMMAND)
    os.chdir(REPO_PATH+'\\commons')
    run_command(INSTALL_COMMAND)
    os.chdir(REPO_PATH+'\\log-starter')
    run_command(INSTALL_COMMAND)

def upload_xml():
    os.chdir(REPO_PATH)
    put('xml/*', '/opt/xml/')

def merge_pull_request():
    os.chdir(REPO_PATH)
    run_command('git pull origin multi-db-compatible --no-ff --no-edit')

 
def deploy_all():
    merge_pull_request()
    reinstall_dependencies()
    for module in module_list:
        package_service(REPO_PATH, package_command, module)
    for module in module_list:
        upload_jar(module)
    upload_xml()
    for module in module_list:
        deploy_service(module)
        time.sleep(30)


def deploy_list(*mlist):
    merge_pull_request()
    # reinstall_dependencies()
    for module in mlist:
        package_service(REPO_PATH, package_command, module)
    for module in mlist:
        upload_jar(module)
    # upload_xml()
    for module in mlist:
        deploy_service(module)
        time.sleep(30)
    


def restart_service(module_name):
    stop_process(module_name)
    start_jar(module_name)

def restart_list(*mlist):
    for module in mlist:
        restart_service(module)
        time.sleep(30)

def stop_list(*mlist):
    for module in mlist:
        stop_process(module)


def stop_all():
    for module in module_list:
        stop_process(module)


xml_module_list = [
    'user-center',
    'data-center',
    'manage-backend', 
    'manage-baseData'
]


def restart_xml_related():
    for module in xml_module_list:
        restart_service(module)