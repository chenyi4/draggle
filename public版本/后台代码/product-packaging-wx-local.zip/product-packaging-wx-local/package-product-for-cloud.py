"""Package product

This script is used for packaging the MES standard product only !

Leonard Wang @pactera
"""
import os, sys, stat
import subprocess
import io
import shutil

    
def run_command(command):
    p = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output = p.stdout.read().decode('gbk')
    print(output)

def install_private_dependency(source_code_dir, install_command, module_name):
    os.chdir(source_code_dir+'\\'+module_name)
    # 将打包用的 package-pom.xml复制并覆盖原pom.xml
    # shutil.copy(".\\pom\\package-pom.xml", ".\\pom.xml")
    # if os.path.exists('.\\pom\\allatori.xml'):
    #     shutil.copy(".\\pom\\allatori.xml", ".\\lib\\allatori.xml")
    print('Install %s module to local maven repository\n'%module_name)
    run_command(install_command)
    print('Install %s module completed\n'%module_name)

def package_service(source_code_dir, package_command, module_name):
    os.chdir(source_code_dir+'\\'+module_name)
    print('Package %s service\n'%module_name)
    run_command(package_command)
    print('Package %s service completed\n'%module_name)


def copy_service_jar(src, dst, module_name):
    print('Copy service jar of module %s start ... \n'%module_name)
    service_path = TARGET_WORK_DIR
    jar_path = src + '\\' + module_name + '\\target\\' + module_name + '.jar'
    # if not os.path.exists(service_path):
    #     os.mkdir(service_path, stat.S_IRWXO)
    shutil.copy(jar_path, service_path)
    print('Copy service jar of module %s completed \n'%module_name)




# 源代码路径
REPO_PATH = 'D:\\workspace-leo\\MES_Standard_SAAS'

# 目标工作路径
TARGET_WORK_DIR = 'D:\\product-package-for-cloud\\saas'

# 打包阶段对应的配置文件环境
ACTIVE_PROFILE = '-Pprod'

VERSION = '2.0'


MODULES = {
    'api-model': 'api-model',
    'commons': 'commons',
    'log-starter': 'log-starter',
    'config-center': 'config-center',
    'data-center': 'data-center',
    'file-center': 'file-center',
    'gateway-zuul': 'gateway-zuul',
    'log-center': 'log-center',
    'manage-aps': 'manage-aps',
    'manage-backend': 'manage-backend',
    'manage-backend-mobile': 'manage-backend-mobile',
    'manage-baseData': 'manage-baseData',
    'manage-engineering': 'manage-engineering',
    'manage-production': 'manage-production',
    'manage-quality': 'manage-quality',
    'mes-device': 'mes-device',
    'monitor-center': 'monitor-center',
    'notification-center': 'notification-center',
    'oauth-center': 'oauth-center',
    'register-center': 'register-center',
    'user-center': 'user-center',
    'xml': 'xml'
}


# 切换到项目代码路径
os.chdir(REPO_PATH)

# 首先安装cloud-service的pom.xml到本地maven仓库
'''
print('Install cloud-service pom.xml to local maven repository\n')
cmd = 'mvn install:install-file -Dfile=pom.xml -DgroupId=com.cloud -DartifactId=cloud-service -Dversion=%s -Dpackaging=pom'%VERSION
p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
output = p.stdout.read().decode('gbk')
print(output)
print('Install cloud-service pom.xml completed\n')

# 需要打包成私有依赖的模块
install_module_list = [
    'api-model', 
    'commons', 
    'log-starter'
]

install_command = 'mvn clean install -DskipTests=true'
print('Package and install private dependencies ... \n')
for module in install_module_list:
    install_private_dependency(REPO_PATH, install_command, MODULES[module])
print('Package and install private dependencies completed \n')
'''
package_module_list = [
    'data-center',
    'file-center',
    'gateway-zuul',
    'log-center',
    'monitor-center',
    'notification-center',
    'oauth-center',
    'register-center',
    'user-center',
    'manage-backend', 
    'manage-baseData', 
    'manage-engineering', 
    'manage-production',
    'manage-quality',
    'mes-device',
    'config-center'
]

package_command = 'mvn clean package -DskipTests=true ' + ACTIVE_PROFILE
print(package_command)
print('Package service jar ... \n')
for module in package_module_list:
    package_service(REPO_PATH, package_command, MODULES[module])
    copy_service_jar(REPO_PATH, '', MODULES[module])
print('Package service jar completed \n')


shutil.copytree(REPO_PATH +'\\xml', TARGET_WORK_DIR + '\\xml')
