"""Package product

This script is used for packaging the MES standard product, including packaging service jars 
and private dependency jars and remove some source code of some modules which will be delivered to the customers.

Leonard Wang @pactera
"""
import os, sys, stat
import subprocess
import io
import shutil

def remove_directory_incursivelly(dir_path):
    if not os.path.exists(dir_path):
        print('Path ' + dir_path + 'does not exist. ')
        return
    
    # 如果是文件，直接删除并返回
    if os.path.isfile(dir_path):
        os.remove(dir_path)
        return

    dir_list = os.listdir(dir_path)
    if dir_list:
        for f in dir_list:
            file_path = dir_path + '\\' + str(f)
            # print('file path : ' + file_path)
            # if not os.path.isdir(file_path):
            #     os.remove(file_path)
            # else:
            remove_directory_incursivelly(file_path)

    if os.path.exists(dir_path):
        os.rmdir(dir_path)
    else:
        print('Path ' + dir_path + 'does not exist. ')
    
def run_command(command):
    os.system(command)
    # p = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # output = p.stdout.read().decode('gbk')
    # print(output)

def install_private_dependency(source_code_dir, install_command, module_name):
    os.chdir(source_code_dir+'\\'+module_name)
    # 将打包用的 package-pom.xml复制并覆盖原pom.xml
    shutil.copy(".\\pom\\package-pom.xml", ".\\pom.xml")
    if os.path.exists('.\\pom\\allatori.xml'):
        shutil.copy(".\\pom\\allatori.xml", ".\\lib\\allatori.xml")
    print('Install %s module to local maven repository\n'%module_name)
    run_command(install_command)
    print('Install %s module completed\n'%module_name)

def package_service(source_code_dir, package_command, module_name):
    os.chdir(source_code_dir+'\\'+module_name)
    # 将打包用的 package-pom.xml复制并覆盖原pom.xml
    shutil.copy(".\\pom\\package-pom.xml", ".\\pom.xml")
    print('Package %s service\n'%module_name)
    run_command(package_command)
    print('Package %s service completed\n'%module_name)

def copy_dependency(src, dst, module_name, jar_name):
    print('Copy dependency and pom of module %s start ...\n'%module_name)
    dependency_path = dst + '\\' + DEPENDENCY_NAME
    pom_path = src + '\\' + module_name + '\\pom.xml'
    jar_path = src + '\\' + module_name + '\\target\\' + jar_name
    if not os.path.exists(dependency_path):
        os.mkdir(dependency_path, stat.S_IRWXO)
    module_dependency_path = dependency_path + '\\' + module_name
    os.mkdir(module_dependency_path, stat.S_IRWXO)
    shutil.copy(pom_path, module_dependency_path)
    shutil.copy(jar_path, module_dependency_path)
    print('Copy dependency and pom of module %s completed \n'%module_name)

def copy_service_jar(src, dst, module_name):
    print('Copy service jar of module %s start ... \n'%module_name)
    service_path = SERVICE_PATH
    jar_path = src + '\\' + module_name + '\\target\\' + module_name + '.jar'
    if not os.path.exists(service_path):
        os.mkdir(service_path, stat.S_IRWXO)
    shutil.copy(jar_path, service_path)
    print('Copy service jar of module %s completed \n'%module_name)



# 代码版本号
VERSION = '1.0'

# 源代码路径
REPO_PATH = 'D:\\mes-product-package\\MES_Standard_Release_v1.0'

MAVEN_REPO_PATH = 'D:\\mes-product-package\\repo'
#MAVEN_REPO_PATH = 'D:\\package\\workspace\\repository'

MAVEN = 'D:\\mes-product-package\\apache-maven-3.6.2\\bin\\mvn'

# 目标工作路径
TARGET_WORK_DIR = 'D:\\package'

# TARGET_WORK_DIR = 'C:\\workspace\\random-frequent-package'

# 打包阶段对应的配置文件环境
ACTIVE_PROFILE = ''

# 发布包项目代码文件夹名称
PROJECT_NAME = 'MES_Standard_Product_Release_v' + VERSION

WORK_DIR = TARGET_WORK_DIR + '\\MES_' + VERSION

CODE_PATH = WORK_DIR + '\\mes_code_' + VERSION

# 复制代码目标路径
TARGET_PROJECT_PATH = CODE_PATH + '\\' + PROJECT_NAME

MES_PATH = WORK_DIR + '\\mes_jar_' + VERSION + '\\mes'

# mes_jar_{version} path
LIB_NAME = MES_PATH + '\\jar_' + VERSION

LIB_PATH = LIB_NAME

SERVICE_PATH = LIB_NAME

DEPENDENCY_NAME = 'lib'

MODULES = {
    'api-model': 'api-model',
    'commons': 'commons',
    'config-center': 'config-center',
    'data-center': 'data-center',
    'file-center': 'file-center',
    'gateway-zuul': 'gateway-zuul',
    'log-center': 'log-center',
    'log-starter': 'log-starter',
    'manage-aps': 'manage-aps',
    'manage-backend': 'manage-backend',
    'manage-baseData': 'manage-baseData',
    'manage-engineering': 'manage-engineering',
    'manage-production': 'manage-production',
    'manage-quality': 'manage-quality',
    'mes-device': 'mes-device',
    'monitor-center': 'monitor-center',
    'notification-center': 'notification-center',
    'oauth-center': 'oauth-center',
    'register-center': 'register-center',
    'user-center': 'user-center',
    'xml': 'xml',
	'script': 'script'
}

DEPENDENCY_JAR_NAME = {
    'api-model': 'api-model.jar', 
    'commons': 'commons.jar', 
    'log-starter': 'log-starter.jar', 
    'manage-backend': 'manage-backend-base.jar', 
    'manage-baseData': 'manage-baseData-base.jar', 
    'manage-engineering': 'manage-engineering-base.jar', 
    'manage-production': 'manage-production-base.jar',
    'manage-quality': 'manage-quality-base.jar',
    'monitor-center': 'monitor-center-base.jar'
}

# 创建工作区目录
print('Recreate working directory ... \n')
if os.path.exists(WORK_DIR):
    remove_directory_incursivelly(WORK_DIR)
    os.makedirs(WORK_DIR, stat.S_IRWXO)
else:
    os.makedirs(WORK_DIR, stat.S_IRWXO)
print('Recreate working directory completed\n')


# 复制源代码到
print('Copy source code project to work directory\n')
print(TARGET_PROJECT_PATH)
if os.path.exists(TARGET_PROJECT_PATH):
   remove_directory_incursivelly(TARGET_PROJECT_PATH)
shutil.copytree(src = REPO_PATH, dst = TARGET_PROJECT_PATH, ignore = shutil.ignore_patterns(".git"))
print('Copy source code project completed\n')

# 切换到复制好的项目代码路径
os.chdir(TARGET_PROJECT_PATH)

# 首先安装cloud-service的pom.xml到本地maven仓库
print('Install cloud-service pom.xml to local maven repository\n')
cmd = MAVEN + ' install:install-file -Dfile=pom.xml -DgroupId=com.cloud -DartifactId=cloud-service -Dversion=%s -Dpackaging=pom'%VERSION
p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
output = p.stdout.read().decode('gbk')
print(output)
print('Install cloud-service pom.xml completed\n')


# # 创建依赖包、服务包目录

print('Recreate dependency and service directory ... \n')
if os.path.exists(LIB_PATH):
    remove_directory_incursivelly(LIB_PATH)
    os.makedirs(LIB_PATH, stat.S_IRWXO)
else:
    os.makedirs(LIB_PATH, stat.S_IRWXO)
print('Recreate dependency and service directory completed\n')

# 需要打包成私有依赖的模块
install_module_list = [
    'api-model', 
    'commons', 
    'log-starter', 
    'manage-backend', 
    'manage-baseData', 
    'manage-engineering', 
    'manage-production',
    'manage-quality',
    'monitor-center'
]

install_command = MAVEN + ' clean install -DskipTests=true'
print('Package and install private dependencies ... \n')
for module in install_module_list:
    install_private_dependency(TARGET_PROJECT_PATH, install_command, MODULES[module])
    # copy_dependency(TARGET_PROJECT_PATH, LIB_PATH, MODULES[module], DEPENDENCY_JAR_NAME[module])
print('Package and install private dependencies completed \n')

# 服务打包模块
package_module_list = [
    'data-center',
    'file-center',
    'gateway-zuul',
    'log-center',
    'notification-center',
    'oauth-center',
    'register-center',
    'user-center'
]

package_command = MAVEN + ' clean package -DskipTests=true ' + ACTIVE_PROFILE
print('Package service jar ... \n')
for module in package_module_list:
    package_service(TARGET_PROJECT_PATH, package_command, MODULES[module])
    copy_service_jar(TARGET_PROJECT_PATH, LIB_PATH, MODULES[module])
print('Package service jar completed \n')


# 将product-pom.xml复制到各模块根路径，并重命名为pom.xml，此处全部是要开放给客户的源代码模块
change_pom_module_list = [
    'api-model', 
    'config-center',
    'manage-backend', 
    'manage-baseData', 
    'manage-engineering', 
    'manage-production',
    'manage-quality',
    'mes-device',
    'monitor-center'
]
print('Replace pom.xml with product-pom.xml and remove unnecessary directories and files ... \n')
for module in change_pom_module_list:
    module_path = TARGET_PROJECT_PATH+'\\'+MODULES[module]
    # dir
    lib_path = module_path + '\\lib'
    pom_path = module_path + '\\pom'
    target_path = module_path + '\\target'
    settings_path = module_path + '\\.settings'
    logs_path = module_path + '\\logs'
    
    #file
    iml_path = module_path + '\\' + MODULES[module] + '.iml'
    classpath_path = module_path + '\\.classpath'
    project_path = module_path + '\\.project'
    gitignore_path = module_path + '\\.gitignore'
    readme = module_path + '\\README.md'

    os.chdir(module_path)
    # 将打包用的 package-pom.xml复制并覆盖原pom.xml
    shutil.copy(".\\pom\\product-pom.xml", ".\\pom.xml")
    if os.path.exists(lib_path):
        remove_directory_incursivelly(lib_path)
    
    if os.path.exists(pom_path):
        remove_directory_incursivelly(pom_path)
    
    if os.path.exists(target_path):
        remove_directory_incursivelly(target_path)

    if os.path.exists(settings_path):
        remove_directory_incursivelly(settings_path)

    if os.path.exists(logs_path):
        remove_directory_incursivelly(logs_path)

    if os.path.exists(iml_path):
        os.remove(iml_path)             

    if os.path.exists(classpath_path):
        os.remove(classpath_path)
    
    if os.path.exists(project_path):
        os.remove(project_path)

    if os.path.exists(gitignore_path):
        os.remove(gitignore_path)

    if os.path.exists(readme):
        os.remove(readme)



# 删除源代码根目录中多余的文件夹和文件
print('Remove some unnecessary directories in the project root directory\n')
idea_path = TARGET_PROJECT_PATH + "\\.idea"
settings_path = TARGET_PROJECT_PATH + "\\.settings"
project_path = TARGET_PROJECT_PATH + "\\.project"
iml_path = TARGET_PROJECT_PATH + "\\cloud-service.iml"
gitignore_path = TARGET_PROJECT_PATH + '\\.gitignore'
readme = TARGET_PROJECT_PATH + '\\README.md'
# svn_path = TARGET_PROJECT_PATH + "\\.svn"

if os.path.exists(settings_path):
    remove_directory_incursivelly(settings_path)

if os.path.exists(idea_path):
    remove_directory_incursivelly(idea_path)

if os.path.exists(project_path):
    os.remove(project_path)

if os.path.exists(iml_path):
    os.remove(iml_path)

if os.path.exists(gitignore_path):
    os.remove(gitignore_path)

if os.path.exists(readme):
    os.remove(readme)


# 从要交付给客户的模块的源代码中删除对应的已经打包成私有依赖的部分代码
delete_source_code_module_map = {
    'manage-backend': [
        'com\\cloud\\backend\\common\\controller',
        'com\\cloud\\backend\\config',
        'com\\cloud\\backend\\constant',
        'com\\cloud\\backend\\consumer',
        'com\\cloud\\backend\\core',
        'com\\cloud\\backend\\exception',
        'com\\cloud\\backend\\feign\\hidefeign',
        'com\\cloud\\backend\\model',
        'com\\cloud\\backend\\utils',
        'com\\cloud\\backend\\initialize',
        'com\\cloud\\backend\\getMsgFromXmls',
        'com\\cloud\\backend\\service\\hideImpl'        
    ], 
    'manage-baseData': [
        'com\\cloud\\baseData\\common\\controller',
        'com\\cloud\\baseData\\config',
        'com\\cloud\\baseData\\constant',
        'com\\cloud\\baseData\\consumer',
        'com\\cloud\\baseData\\core',
        'com\\cloud\\baseData\\exception',
        'com\\cloud\\baseData\\feign\\hidefeign',
        'com\\cloud\\baseData\\initialize',
        'com\\cloud\\baseData\\service\\hideImpl'
    ], 
    'manage-engineering': [
        'com\\cloud\\engineering\\common\\controller',
        'com\\cloud\\engineering\\config',
        'com\\cloud\\engineering\\constant',
        'com\\cloud\\engineering\\consumer',
        'com\\cloud\\engineering\\core',
        'com\\cloud\\engineering\\exception',
        'com\\cloud\\engineering\\feign\\hidefeign',
        'com\\cloud\\engineering\\test',
        'com\\cloud\\engineering\\initialize',
        'com\\cloud\\engineering\\service\\hideImpl'
    ], 
    'manage-production': [
        'com\\cloud\\production\\common\\controller',
        'com\\cloud\\production\\config',
        'com\\cloud\\production\\constant',
        'com\\cloud\\production\\consumer',
        'com\\cloud\\production\\core',
        'com\\cloud\\production\\feign\\hidefeign',
        'com\\cloud\\production\\initialize',
        'com\\cloud\\production\\service\\hideImpl'
    ],
    'manage-quality': [
        'com\\cloud\\quality\\common\\controller',
        'com\\cloud\\quality\\config',
        'com\\cloud\\quality\\constant',
        'com\\cloud\\quality\\consumer',
        'com\\cloud\\quality\\core',
        'com\\cloud\\quality\\feign\\hidefeign',
        'com\\cloud\\quality\\initialize',
        'com\\cloud\\quality\\service\\hideImpl'
    ],
    'monitor-center': [
        'com/admin/cloud/monitor/config',
        'com/admin/cloud/monitor/encoder',
        'com/admin/cloud/monitor/initialize',
        'com/admin/cloud/monitor/job',
        'com/admin/cloud/monitor/util',
        'com/admin/cloud/monitor/dao/I18nInfoDao.java',
        'com/admin/cloud/monitor/service/I18nInfoService.java',
        'com/admin/cloud/monitor/service/impl/I18nInfoServiceImpl.java'
    ]
}


for module in delete_source_code_module_map.keys():
    for package_path in delete_source_code_module_map[module]:
        delete_path = TARGET_PROJECT_PATH + '\\' + MODULES[module] + '\\src\\main\\java\\' + package_path
        print('Deleted package path : '+ delete_path)
        remove_directory_incursivelly(delete_path)


# 从源码目录复制xml文件夹到服务jar包同级路径下
shutil.copytree(str(TARGET_PROJECT_PATH + '\\xml'), str(LIB_PATH + '\\xml'))

shutil.copytree(str(TARGET_PROJECT_PATH + '\\xml'), str(MES_PATH + '\\xml'))

if os.path.exists(str(TARGET_PROJECT_PATH + '\\script')):
    shutil.copytree(str(TARGET_PROJECT_PATH + '\\script'), str(LIB_PATH + '\\script'))

shutil.copytree(MAVEN_REPO_PATH + '\\com\\cloud' , LIB_PATH + '\\lib\\com\\cloud')


print('Replace pom.xml with product-pom.xml and remove unnecessary directories and files completed \n')


# 将不需要交付的模块代码删除
remove_module_list = [
    'commons', 
    'log-starter',

    'data-center',
    'file-center',
    'gateway-zuul',
    'log-center',
    'notification-center',
    'oauth-center',
    'register-center',
    'user-center',
    'script',
    'manage-aps'
]

print('Remove some specific module directories \n')
os.chdir(TARGET_PROJECT_PATH)
for module in remove_module_list:
    module_path = TARGET_PROJECT_PATH + '\\' + MODULES[module]
    if os.path.exists(module_path):
        remove_directory_incursivelly(module_path)
		
os.chdir(TARGET_PROJECT_PATH)
if os.path.exists('pom.xml'):
	os.remove('pom.xml')

os.rename('product-pom.xml', 'pom.xml')
