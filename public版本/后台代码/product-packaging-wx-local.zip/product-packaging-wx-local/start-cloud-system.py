"""Package product

This script is used for packaging the MES standard product only !

Leonard Wang @pactera
"""
import os, sys, stat
import subprocess
import io
import shutil
import time
    
def run_command(command):
    p = subprocess.Popen(command, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output = p.stdout.read().decode('utf8')
    print(output)






WORK_DIR = '/opt/app'

JAVA = '/usr/local/jre/bin/java'

MODULES = {
    'config-center': {
        'name': 'config-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'data-center': {
        'name': 'data-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'file-center': {
        'name': 'file-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'gateway-zuul': {
        'name': 'gateway-zuul',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'log-center': {
        'name': 'log-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-backend': {
        'name': 'manage-backend',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-baseData': {
        'name': 'manage-baseData',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-engineering': {
        'name': 'manage-engineering',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-production': {
        'name': 'manage-production',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'manage-quality': {
        'name': 'manage-quality',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'monitor-center': {
        'name': 'monitor-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'notification-center': {
        'name': 'notification-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'oauth-center': {
        'name': 'oauth-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'register-center': {
        'name': 'register-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx512m -Xms400m -Xmn400m -Xss256k -XX:SurvivorRatio=8'
    },
    'user-center': {
        'name': 'user-center',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    },
    'mes-device': {
        'name': 'mes-device',
        'java-opts': '-XX:MetaspaceSize=128m -XX:MaxMetaspaceSize=128m -Xmx768m -Xms600m -Xmn600m -Xss256k -XX:SurvivorRatio=8'
    }

}



os.chdir(WORK_DIR)



package_module_list = [
    'register-center',
    'config-center',
    'gateway-zuul',
    'oauth-center',
    'user-center',
    'data-center',
    'file-center',
    'log-center',
    'manage-backend', 
    'manage-baseData', 
    'manage-engineering', 
    'manage-production',
    'manage-quality',
    'monitor-center',
    'notification-center',
    'mes-device'
]

package_module_list = [
'data-center',
'manage-backend',
     'mes-device'
]

print('Start service jar ... \n')
for module in package_module_list:
    command_stop = 'kill -9 `ps aux | grep '+MODULES[module]['name']+'.jar | grep -v grep | awk \'{print $2}\'`'
    print(command_stop)
    run_command(command_stop)
    print(os.path)
    command = 'nohup ' + JAVA + ' ' + MODULES[module]['java-opts'] + ' -jar ' + MODULES[module]['name'] + '.jar >> logs/'+ MODULES[module]['name'] +'.log 2>&1 &'
    print(command)
    run_command(command)
    time.sleep(30)
print('Package service jar completed \n')

